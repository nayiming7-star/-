/* ============================================================
   把生活变成一个世界 · 主程序 app.js
   纯 Canvas 程序化生成，零外部素材、零网络请求
   由 life-world.html 单文件版原样拆出（内容未改一字）
   ============================================================ */

"use strict";
/* ============================================================
   Life as a World · 2D 像素世界原型
   纯 Canvas 程序化生成，无外部素材依赖
   ============================================================ */

/* ---------------- 0. 工具 ---------------- */
window.addEventListener('error',e=>{
  let b=document.getElementById('errbar');
  if(!b){b=document.createElement('div');b.id='errbar';
    b.style.cssText='position:absolute;left:0;right:0;top:0;z-index:999;background:#b3261e;color:#fff;font:12px monospace;padding:8px 12px;white-space:pre-wrap;word-break:break-all';
    document.getElementById('phone').appendChild(b);}
  b.textContent=(b.textContent?b.textContent+'\n':'')+'ERR: '+(e.message||e)+' @'+(e.lineno||'')+':'+(e.colno||'');
});

const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const lerp=(a,b,t)=>a+(b-a)*t;
function mulberry32(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function hash2(x,y,s){let h=Math.imul(x|0,374761393)+Math.imul(y|0,668265263)+Math.imul(s|0,971);h=Math.imul(h^(h>>>13),1274126177);return((h^(h>>>16))>>>0)/4294967296;}
function vnoise(x,y,s){
  const xi=Math.floor(x), yi=Math.floor(y), xf=x-xi, yf=y-yi;
  const u=xf*xf*(3-2*xf), v=yf*yf*(3-2*yf);
  const a=hash2(xi,yi,s), b=hash2(xi+1,yi,s), c=hash2(xi,yi+1,s), d=hash2(xi+1,yi+1,s);
  return (a*(1-u)+b*u)*(1-v)+(c*(1-u)+d*u)*v;
}
const hex2rgb=h=>[parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)];const rgbs=c=>'rgb('+(c[0]|0)+','+(c[1]|0)+','+(c[2]|0)+')';
const rgba=(c,a)=>'rgba('+(c[0]|0)+','+(c[1]|0)+','+(c[2]|0)+','+a+')';
const sh=(c,f,add)=>[clamp(c[0]*f+(add||0),0,255),clamp(c[1]*f+(add||0),0,255),clamp(c[2]*f+(add||0),0,255)];
const mix=(a,b,t)=>[lerp(a[0],b[0],t),lerp(a[1],b[1],t),lerp(a[2],b[2],t)];
function C(w,h){const c=document.createElement('canvas');c.width=Math.max(1,w|0);c.height=Math.max(1,h|0);return c;}
const GC=c=>c.getContext('2d',{willReadFrequently:true});
function P(g,x,y,w,h,col){g.fillStyle=col;g.fillRect(x|0,y|0,Math.max(1,w|0),Math.max(1,h|0));}
function outline(cvc,str){
  const g=GC(cvc),w=cvc.width,h=cvc.height,id=g.getImageData(0,0,w,h),d=id.data,src=new Uint8ClampedArray(d);
  const oc=hex2rgb(str||'#0a0916');
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const i=(y*w+x)*4; if(src[i+3]>12) continue;
    let t=false;
    if(x>0&&src[i-4+3]>128)t=true; if(!t&&x<w-1&&src[i+4+3]>128)t=true;
    if(!t&&y>0&&src[i-w*4+3]>128)t=true; if(!t&&y<h-1&&src[i+w*4+3]>128)t=true;
    if(t){d[i]=oc[0];d[i+1]=oc[1];d[i+2]=oc[2];d[i+3]=215;}
  }
  g.putImageData(id,0,0); return cvc;
}
const canvasURL=(w,h,draw)=>{const c=C(w,h),g=GC(c);draw(g,w,h);return c;};

/* ---------------- 1. 世界配置 ---------------- */
const PX=3;                       // 1 艺术像素 = 3 CSS 像素（zoom=1 时）
let WW=340, WH=460;               // 世界尺寸（艺术像素）—— 随自建岛数量自动扩张
let WOX=0, WOY=0;                 // 世界左上角在世界坐标系里的位置（可为负）
/* 内置五岛（自建岛数量不限，见 ISLAND_THEMES / nextCustomSlot） */
let ISLANDS=[
  {id:'harbor',   name:'温暖港湾', emoji:'🏡', tag:'珍贵的陪伴', desc:'朋友、家庭、值得纪念的时刻',
   color:'#ffb26b', x:170,y:232,r:44, seed:11, grass:[92,172,110], core:[112,190,128], deco:'flower'},
  {id:'knowledge',name:'知识岛',   emoji:'📚', tag:'学习与成长', desc:'课程、比赛、项目、学习经历',
   color:'#6fb4ff', x:170,y:76, r:34, seed:23, grass:[88,166,148], core:[106,184,166], deco:'stone'},
  {id:'memory',   name:'回忆森林', emoji:'🌳', tag:'过去的生活', desc:'照片、重要时刻、个人故事',
   color:'#6fdcae', x:52, y:212,r:33, seed:37, grass:[60,140,96],  core:[76,158,110],  deco:'mushroom'},
  {id:'creation', name:'创作岛',   emoji:'🎨', tag:'兴趣与创作', desc:'绘画、音乐、摄影、设计作品',
   color:'#ff9ad5', x:288,y:212,r:33, seed:53, grass:[118,164,112],core:[142,182,126], deco:'tuft'},
  {id:'future',   name:'未来之岛', emoji:'🚀', tag:'未来的目标', desc:'梦想、计划、想完成的事情',
   color:'#b79cff', x:170,y:384,r:36, seed:71, grass:[104,124,176],core:[124,144,196], deco:'crystal'},
  {id:'music',    name:'爱乐之城', emoji:'🎵', tag:'音乐的栖息地', desc:'导入你喜欢的音乐，让旋律在岛上流淌',
   color:'#ffd166', x:296,y:62,r:30, seed:89, grass:[96,90,176],core:[126,118,200], deco:'note'},
];
let ISL={};
const SEA_DEEP=[11,15,36], SEA_SHALF=[22,36,76];

/* 自建岛可选主题（视觉与配置成套） */
const ISLAND_THEMES={
  garden:{name:'花园', color:'#9ce86f', grass:[104,176,112], core:[126,196,132],
    build:[{spr:'cottage2',dx:0,dy:-6,sc:1,r:12},{spr:'easel',dx:15,dy:12,sc:1,r:7},{spr:'lamp',dx:-15,dy:12,sc:1,r:4}],
    trees:['treePink','treeA','bush'], treeCount:9, decoList:['flw1','flw2','flw3','tuft'], decoCount:20,
    glow:'rgba(156,232,111,.28)'},
  valley:{name:'山谷', color:'#7fd4c4', grass:[86,158,150], core:[104,180,170],
    build:[{spr:'tower',dx:0,dy:-8,sc:1,r:13},{spr:'books',dx:-16,dy:12,sc:1,r:6},{spr:'lampB',dx:10,dy:14,sc:1,r:4}],
    trees:['pine','treeC','treeB'], treeCount:12, decoList:['rock','bush','tuft'], decoCount:14,
    glow:'rgba(127,212,196,.28)'},
  market:{name:'灯市', color:'#ffcf6b', grass:[124,166,110], core:[150,186,124],
    build:[{spr:'cottage1',dx:-12,dy:-14,sc:1,r:13},{spr:'cottage2',dx:13,dy:-6,sc:1,r:11},{spr:'lamp',dx:0,dy:14,sc:1,r:4},{spr:'dock',dx:18,dy:26,sc:1,r:12}],
    trees:['treeA','treeB'], treeCount:8, decoList:['bush','tuft','flw1'], decoCount:16,
    glow:'rgba(255,207,107,.30)'},
  star:{name:'星光台', color:'#c2b3ff', grass:[104,124,176], core:[126,146,198],
    build:[{spr:'dome',dx:0,dy:10,sc:1,r:11},{spr:'spire',dx:-14,dy:-6,sc:1,r:6},{spr:'ring',dx:12,dy:-18,sc:1,r:6}],
    trees:['treeFut','pineFut'], treeCount:8, decoList:['rockFut','tuft'], decoCount:12,
    glow:'rgba(194,179,255,.30)'},
  grove:{name:'幽林', color:'#6fdcae', grass:[60,140,96], core:[76,158,110],
    build:[{spr:'hollow',dx:0,dy:0,sc:1,r:15},{spr:'string',dx:0,dy:-26,sc:1,r:2},{spr:'lamp',dx:-16,dy:14,sc:1,r:4}],
    trees:['treeMemory','treeMemory2','pine'], treeCount:16, decoList:['mush','mushB','bushD','tuft'], decoCount:16,
    glow:'rgba(111,220,174,.28)'}
};
/* 自建岛落点：先用手工排好的近景位，之后按同心环无限向外扩展 */
const CUSTOM_SLOTS=[
  {x:226,y:176,r:27},{x:114,y:176,r:27},{x:226,y:288,r:27},{x:114,y:288,r:27},
  {x:170,y:150,r:26},{x:60, y:140,r:24},{x:280,y:330,r:24}
];
/* 判断某个落点会不会和已有岛屿挤在一起 */
function islandOverlap(x,y,r,pad){
  const need=r*1.36+(pad||0);            // 1.36 = 海岸线最大外扩(1.29) + 一点余量
  for(const i of ISLANDS){
    if(Math.hypot(x-i.x,y-i.y) < need + i.r*1.36) return true;
  }
  return false;
}
/* 不限数量的落点生成：住满一圈就往外长一圈 */
function nextCustomSlot(){
  const used=ISLANDS.filter(i=>i.custom).length;
  if(used<CUSTOM_SLOTS.length){
    const s=CUSTOM_SLOTS[used];
    if(!islandOverlap(s.x,s.y,s.r,6)) return {x:s.x,y:s.y,r:s.r};
  }
  const H=ISL.harbor||ISLANDS[0];
  for(let ring=0;ring<80;ring++){
    const rad=218+ring*78;
    const count=10+ring*2;
    for(let j=0;j<count;j++){
      const a=(j/count)*6.2832 + ring*0.41 + (used%3)*0.16;
      const x=H.x+Math.cos(a)*rad*1.05, y=H.y+Math.sin(a)*rad*0.98;
      const r=24+(ring+j)%3;
      if(!islandOverlap(x,y,r,12)) return {x,y,r};
    }
  }
  return {x:H.x, y:H.y+4200, r:26};
}

/* 围绕指定岛屿找一个不重叠的落点，优先把新岛落在它旁边。 */
function nextSlotNearIsland(anchorId){
  const anchor=ISL[anchorId]||ISL.harbor||ISLANDS[0];
  if(!anchor) return {x:170,y:232,r:26};
  const used=ISLANDS.filter(i=>i.custom).length;
  const r=24+(used%3);
  const start=(used*0.79)+((String(anchor.id).length%5)*0.23);
  const base=(anchor.r+r)*1.36+36;
  for(let ring=0;ring<30;ring++){
    const dist=base+ring*22;
    const count=12+ring*3;
    for(let j=0;j<count;j++){
      const a=start+(j/count)*6.2832+ring*0.31;
      const x=anchor.x+Math.cos(a)*dist*1.10;
      const y=anchor.y+Math.sin(a)*dist*0.94;
      if(!islandOverlap(x,y,r,12)) return {x,y,r};
    }
  }
  return nextCustomSlot();
}

function rebuildISL(){ ISL=Object.fromEntries(ISLANDS.map(i=>[i.id,i])); }
/* 世界边界 = 所有岛屿（含外圈深海晕）的外接矩形，会随自建岛向外扩张。
   余量必须大于「近岛变亮 → 淡出到深海贴图」的完整距离（约 2.75r），
   否则淡出还没走完就到了贴图边缘，会看到一条直边。 */
function computeWorldBounds(){
  let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
  for(const i of ISLANDS){
    const m=i.r*3.40+14;
    if(i.x-m<x0)x0=i.x-m;
    if(i.x+m>x1)x1=i.x+m;
    if(i.y-m<y0)y0=i.y-m;
    if(i.y+m>y1)y1=i.y+m;
  }
  if(x0>x1){x0=0;y0=0;x1=340;y1=460;}
  WOX=Math.floor(x0); WOY=Math.floor(y0);
  WW=Math.max(180,Math.ceil(x1)-WOX);
  WH=Math.max(180,Math.ceil(y1)-WOY);
}
/* 海岸线：每个岛一个角度 LUT，做出有机形状 */
function rebuildCoastLUT(){
  for(const i of ISLANDS){
    const lut=new Float32Array(360);
    for(let a=0;a<360;a++){
      const r=a*Math.PI/180;
      lut[a]=i.r*(1+0.15*Math.sin(3*r+i.seed)+0.09*Math.sin(5*r+i.seed*1.7)+0.05*Math.sin(9*r+i.seed*2.3));
    }
    i.lut=lut;
  }
}
rebuildISL(); rebuildCoastLUT(); computeWorldBounds();
function radiusAt(i,ang){let d=ang*57.29578;d%=360;if(d<0)d+=360;return i.lut[d|0];}
/* 每座岛的「影响范围」：超过这个距离就完全交给背景海面贴图。
   深海晕的淡出必须在这条线之前走完，所以淡出距离用「直线距离 + 固定半径」算，
   不能用随角度起伏的海岸线半径——否则某些方向晕还没淡完就到了边界，会露出硬边。 */
const HALO_K=2.55, HALO_B=16, HALO_FADE=2.45;
function islandLimit(r){ return r*HALO_K+HALO_B; }

/* 归一化距离：n<1 在岛上，越大越远；d = 到最近那座岛的直线距离 */
function normAt(x,y){
  let best=1e9,bd=1e9,bi=null;
  for(let k=0;k<ISLANDS.length;k++){
    const i=ISLANDS[k], dx=x-i.x, dy=y-i.y, lim=islandLimit(i.r);
    if(dx>lim||dx<-lim||dy>lim||dy<-lim) continue;
    const d=Math.sqrt(dx*dx+dy*dy);
    const t=d/radiusAt(i,Math.atan2(dy,dx));
    if(t<best){best=t;bd=d;bi=i;}
  }
  return [best,bi,bd];
}
/* 地形分带 */
function terrAt(x,y){
  const [t,i,d]=normAt(x,y);
  if(t<0.78) return {t:'core',i:i,n:t,d:d};
  if(t<0.92) return {t:'grass',i:i,n:t,d:d};
  if(t<1.0)  return {t:'sand', i:i,n:t,d:d};
  if(t<1.055)return {t:'foam', i:i,n:t,d:d};
  if(t<1.45) return {t:'shallow',i:i,n:t,d:d};
  return {t:'deep',i:i,n:t,d:d};
}
const isWater=r=>r.t==='shallow'||r.t==='deep';

/* 桥梁路线（中心 → 每一座岛） */
const BRIDGES=[];
/* 桥 = 最小生成树式的「连到最近的已有岛」：
   内置四岛仍全部直连港湾（保持原来的中心辐射观感），
   自建岛则就近接驳——岛多了也不会在港湾堆出一把扇子。 */
function rebuildBridges(){
  BRIDGES.length=0;
  const linked=[ISL.harbor];
  for(const i of ISLANDS){
    if(i===ISL.harbor) continue;
    let best=null, bd=1e9;
    const preferred=(i.near&&ISL[i.near]&&ISL[i.near]!==i)?ISL[i.near]:null;
    if(preferred&&linked.includes(preferred)){ best=preferred; bd=Math.hypot(i.x-best.x,i.y-best.y); }
    if(!best){
      for(const j of linked){ const d=Math.hypot(i.x-j.x,i.y-j.y); if(d<bd){bd=d;best=j;} }
    }
    const dx=i.x-best.x, dy=i.y-best.y, L=Math.hypot(dx,dy)||1, ux=dx/L, uy=dy/L;
    BRIDGES.push({a:[best.x+ux*best.r, best.y+uy*best.r], b:[i.x-ux*i.r, i.y-uy*i.r], ux,uy, target:i});
    linked.push(i);
  }
}
rebuildBridges();
function distToBridge(x,y){
  let m=1e9;
  for(const br of BRIDGES){
    const vx=br.b[0]-br.a[0], vy=br.b[1]-br.a[1];
    let t=((x-br.a[0])*vx+(y-br.a[1])*vy)/(vx*vx+vy*vy); t=clamp(t,0,1);
    const d=Math.hypot(x-(br.a[0]+vx*t), y-(br.a[1]+vy*t));
    if(d<m)m=d;
  }
  return m;
}

/* ---------------- 2. 深海贴图（周期无缝平铺，世界因此没有边界） ---------------- */
const OCEAN_P=512;                  // 纹理周期（艺术像素），整数周期保证平铺无缝
let oceanCv=null, oceanData=null, oceanPat=null;
function buildOcean(){
  const P=OCEAN_P, c=C(P,P), g=GC(c), img=g.createImageData(P,P), d=img.data;
  const TA=Math.PI*2, sinT=[], cosT=[];
  for(let k=0;k<=5;k++){
    const s=new Float32Array(P), co=new Float32Array(P);
    for(let i=0;i<P;i++){ s[i]=Math.sin(TA*k*i/P); co[i]=Math.cos(TA*k*i/P); }
    sinT[k]=s; cosT[k]=co;
  }
  for(let y=0;y<P;y++){
    const c1=cosT[1][y], s2=sinT[2][y], c3=cosT[3][y], s5=sinT[5][y];
    for(let x=0;x<P;x++){
      // 星云用整数频率的正弦叠加 → 横竖方向都以 P 为周期，拼起来看不到缝
      const nb=0.5
        +0.20*sinT[2][x]*c1
        +0.17*cosT[1][x]*c3
        +0.12*sinT[3][x]*s2
        +0.09*cosT[2][x]*s5;
      const t=clamp((nb-0.50)*1.9,0,1);
      let col=mix(SEA_DEEP,[46,40,94],t*0.56);
      const gr=(hash2(x,y,7)-0.5)*0.055+(hash2(x>>1,y>>1,23)-0.5)*0.034;
      col=sh(col,1+gr);
      const o=(y*P+x)*4;
      d[o]=col[0];d[o+1]=col[1];d[o+2]=col[2];d[o+3]=255;
    }
  }
  g.putImageData(img,0,0);
  oceanCv=c; oceanData=d;
  try{ oceanPat=ctx.createPattern(c,'repeat'); }catch(e){ oceanPat=null; }
}
/* 取深海贴图在某个世界坐标上的颜色（整数对齐），用来把地形和深海焊在一起 */
function oceanTexel(wx,wy){
  const P=OCEAN_P;
  const x=(((wx|0)%P)+P)%P, y=(((wy|0)%P)+P)%P, o=(y*P+x)*4;
  return [oceanData[o],oceanData[o+1],oceanData[o+2]];
}

/* ---------------- 2b. 地形贴图 ----------------
   只在每座岛的影响范围内烘焙，范围之外一个像素都不画（保持全透明）——
   外海完全由上一步那张无缝贴图铺出来，所以「世界边界」这个概念在画面上不存在。
   顺便把耗时从「整张画布」降到「所有岛的范围之和」，自建岛再多也不会卡。 */
let terrainCv=null;
function buildTerrain(){
  const c=C(WW,WH), g=GC(c), img=g.createImageData(WW,WH), d=img.data;
  const seen=new Uint8Array(WW*WH);
  const EDGE_F=34;                                   // 贴图最外圈强制渐隐（保险丝）
  for(const isl of ISLANDS){
    const m=islandLimit(isl.r)+2;
    const bx0=Math.max(0,Math.floor(isl.x-m-WOX)), bx1=Math.min(WW-1,Math.ceil(isl.x+m-WOX));
    const by0=Math.max(0,Math.floor(isl.y-m-WOY)), by1=Math.min(WH-1,Math.ceil(isl.y+m-WOY));
    for(let cy=by0;cy<=by1;cy++)for(let cx=bx0;cx<=bx1;cx++){
    const idx=cy*WW+cx; if(seen[idx]) continue; seen[idx]=1;
    const r=terrAt(cx+WOX+0.5,cy+WOY+0.5), i=r.i, n=r.n;
    let col, alpha=255;
    // 2 像素块 + 6 像素斑块：做出像素风的块状质感
    const bx=cx>>1, by=cy>>1;
    const grain=(hash2(bx,by,7)-0.5)*0.10;
    const patch=vnoise(cx/6.5,cy/6.5,(i?i.seed:1)*3+1);
    if(r.t==='deep'&&!i) continue;                     // 保险：理论上进不来
    if(r.t==='deep'){
      // 近岛偏亮 → 越远越贴近深海贴图本身 → 到 2.45r 处完全淡出，接缝为 0
      const dp=clamp((r.d-1.60*i.r)/((HALO_FADE-1.60)*i.r),0,1);
      col=mix(SEA_SHALF,oceanTexel(cx+WOX,cy+WOY),Math.pow(dp,0.80));
      col=sh(col,1+grain*0.9+(patch-0.5)*0.12);
      alpha=Math.round(255*clamp(1-(dp-0.72)/0.28,0,1));
      const edge=Math.min(cx,cy,WW-1-cx,WH-1-cy);
      if(edge<EDGE_F) alpha=Math.round(alpha*clamp(edge/EDGE_F,0,1));
    }else if(r.t==='shallow'){
      const k=clamp((n-1.055)/(1.45-1.055),0,1);
      let base=mix(mix(SEA_SHALF,hex2rgb(i.color),0.24),SEA_SHALF,Math.pow(k,0.85)*0.94);
      col=sh(base,1+grain*0.9+(patch-0.5)*0.12);
    }else if(r.t==='foam'){
      col=mix(hex2rgb(i.color),SEA_SHALF,0.40); col=sh(col,1.15+grain*0.6);
    }else if(r.t==='sand'){
      col=sh(mix([216,184,132],hex2rgb(i.color),0.12),1+grain+(patch-0.5)*0.14);
    }else{
      const t=n/0.92;
      let base=mix(i.core,i.grass,clamp(t*1.05,0,1));
      if(n>0.80) base=sh(base,1-(n-0.80)*1.5);           // 岛缘压暗
      col=sh(base,0.86+0.30*patch+grain);                // 草地深浅斑块
    }
    const o=(cy*WW+cx)*4;
    d[o]=col[0];d[o+1]=col[1];d[o+2]=col[2];d[o+3]=alpha;
    }
  }
  g.putImageData(img,0,0);
  // 地表细节：草簇 / 沙粒（2 像素块对齐）—— 数量按岛的面积给，大世界不会糊也不会漏
  const R=mulberry32(991);
  for(const isl of ISLANDS){
    const cnt=Math.round(clamp(isl.r*isl.r*1.35,150,1500));
    for(let k=0;k<cnt;k++){
      const x=Math.floor(isl.x-WOX-isl.r*0.86+R()*isl.r*1.72);
      const y=Math.floor(isl.y-WOY-isl.r*0.86+R()*isl.r*1.72);
      if(x<0||y<0||x>=WW||y>=WH) continue;
      const r=terrAt(x+WOX+0.5,y+WOY+0.5);
      if(isWater(r)||!r.i) continue;
      const grass=r.t!=='sand';
      let base=grass?sh(r.i.core,R()<0.45?1.26:0.80):[236,214,168];
      g.fillStyle=rgbs(base);
      g.globalAlpha=grass?(0.26+R()*0.42):(0.16+R()*0.22);
      if(grass&&R()<0.35){ g.fillRect(x,y,1,2); } else { g.fillRect(x,y,1,1); }
    }
  }
  g.globalAlpha=1;
  terrainCv=c; return c;
}

/* ---------------- 3. 桥梁 / 小径层 ---------------- */
let bridgeCv=null;
function buildBridges(){
  const c=C(WW,WH), g=GC(c);
  g.translate(-WOX,-WOY);            // 之后全部用世界坐标绘制
  for(const br of BRIDGES){
    const len=Math.hypot(br.b[0]-br.a[0],br.b[1]-br.a[1]);
    const steps=Math.ceil(len);
    const nx=-br.uy, ny=br.ux;
    for(let s=0;s<=steps;s++){
      const t=s/steps, px=br.a[0]+(br.b[0]-br.a[0])*t, py=br.a[1]+(br.b[1]-br.a[1])*t;
      const hw=3.2+Math.sin(t*Math.PI)*1.1;
      for(let o=-hw;o<=hw;o+=1){
        const X=px+nx*o, Y=py+ny*o;
        const edge=Math.abs(o)>hw-1.2;
        P(g,X,Y,1,1,edge?'#5c4028':(s%3===0?'#a37952':'#96703f'));
      }
      if(s%3===0){P(g,px+nx*(hw+1.2),py+ny*(hw+1.2),1,1,'#4a3421');P(g,px-nx*(hw+1.2),py-ny*(hw+1.2),1,1,'#4a3421');}
    }
    // 桥头灯
    for(const end of [br.a,br.b]){
      P(g,end[0]-1,end[1]-2,2,2,'#3b2c1d'); P(g,end[0]-1,end[1]-3,2,2,'#ffd08a');
    }
  }
  // 岛内小径：桥头 → 地标
  for(const i of ISLANDS){
    const lm=i.build&&i.build[0]?i.build[0]:{dx:0,dy:0};
    const tx=i.x+lm.dx, ty=i.y+lm.dy;
    let bx=i.x, by=i.y;
    if(i.id!=='harbor'){
      const dx=i.x-ISL.harbor.x, dy=i.y-ISL.harbor.y, L=Math.hypot(dx,dy);
      bx=i.x-dx/L*i.r*0.95; by=i.y-dy/L*i.r*0.95;
    }else{ bx=i.x; by=i.y+i.r*0.0; }
    const len=Math.hypot(tx-bx,ty-by), steps=Math.ceil(len);
    for(let s=0;s<=steps;s++){
      const t=s/steps, px=bx+(tx-bx)*t, py=by+(ty-by)*t;
      if(terrAt(px,py).t==='deep'||terrAt(px,py).t==='shallow') continue;
      for(let o=-1.6;o<=1.6;o+=1){
        const hh=hash2(px|0,py|0,5);
        P(g,px+o,py+hash2(px|0,o|0,9)-0.5,1,1, hh>0.6?'#c9a878':(hh>0.3?'#bda273':'#b0966a'));
      }
    }
    if(i.id==='harbor'){
      // 中央小广场
      for(let y=-9;y<=9;y++)for(let x=-13;x<=13;x++){
        if((x*x)/(13*13)+(y*y)/(9*9)>1) continue;
        const hh=hash2(x,y,17);
        P(g,i.x+x,i.y+y+8,1,1, hh>0.55?'#cbb8a0':(hh>0.25?'#bda993':'#ad9a86'));
      }
    }
  }
  bridgeCv=c; return c;
}

/* ---------------- 4. 像素精灵工厂 ---------------- */
const SPR={};
function def(name,cv,anchorX,anchorY){SPR[name]={cv,ax:anchorX===undefined?0.5:anchorX,ay:anchorY===undefined?1:anchorY};return cv;}

/* 圆冠树 / 松树：cap 支持「单一基色」或「三档色调」两种写法 */
function makeTree(o){
  const raw=o.cap;
  const cap=(Array.isArray(raw[0]))?raw:[sh(raw,1.16),raw,sh(raw,0.76)];
  const trunk=o.trunk||[92,66,44], trunkD=sh(trunk,0.72);
  const w=o.w,h=o.h,c=C(w,h),g=GC(c);
  const cx=(w-1)/2, baseY=h-6;
  P(g,Math.round(cx)-1,h-6,2,6,rgbs(trunkD));P(g,Math.round(cx),h-6,1,6,rgbs(trunk));
  if(o.shape==='pine'){
    for(let y=0;y<=baseY;y++){
      const p=y/baseY, half=(w/2-0.5)*(0.30+0.70*p)*(1+0.22*Math.sin(p*11));
      for(let x=Math.round(cx-half);x<=Math.round(cx+half);x++){
        if((x+y)%5===0&&p<0.9) continue;
        const lit=(cx-x)/ (w/2);
        P(g,x,y,1,1,rgbs(lit>0.18?cap[0]:lit>-0.28?cap[1]:cap[2]));
      }
    }
  }else{
    const rx=w/2, ry=(baseY+1)/2, cyy=baseY/2;
    for(let y=0;y<=baseY;y++)for(let x=0;x<w;x++){
      const dx=(x-cx)/rx, dy=(y-cyy)/ry, dd=dx*dx+dy*dy;
      if(dd>1) continue;
      const lit=(-dx*0.85-dy*0.75);
      let col=lit>0.22?cap[0]:lit>-0.18?cap[1]:cap[2];
      if(dd>0.70&&((x+y)%2===0)) col=cap[2];
      P(g,x,y,1,1,rgbs(col));
    }
  }
  return c;
}
/* 房屋（通用） */
function makeHouse(o){
  const w=o.w,h=o.h,rh=o.rh||Math.round(h*0.42);
  const wall=o.wall, roof=o.roof, roofD=sh(roof,0.78), wallD=sh(wall,0.8);
  const c=C(w,h),g=GC(c);
  for(let y=rh;y<h;y++)for(let x=0;x<w;x++){
    const side=(x-cx_(w))/ (w/2);
    P(g,x,y,1,1,rgbs(side>0.35?wallD:wall));
  }
  for(let y=0;y<rh;y++){
    const half=(w/2)*(y+1)/rh;
    for(let x=Math.round((w-1)/2-half);x<=Math.round((w-1)/2+half);x++){
      P(g,x,y,1,1,rgbs(y<rh*0.45?sh(roof,1.12):(x>(w-1)/2?roofD:roof)));
    }
  }
  if(o.win){const wc=hex2rgb(o.win);
    P(g,2,rh+3,3,3,rgbs(wc));P(g,w-5,rh+3,3,3,rgbs(wc));}
  if(o.door!==false){P(g,Math.round((w-3)/2),h-6,3,6,'#5b4029');P(g,Math.round((w-1)/2),h-4,1,1,'#e0c08a');}
  return outline(c,o.ol||'#0d0b18');
}
function cx_(w){return (w-1)/2;}

function buildSprites(){
  const g0=(o)=>makeTree(o);
  def('treeA',g0({w:13,h:17,cap:[92,178,110],seed:1}));
  def('treeB',g0({w:12,h:15,cap:[70,152,98],seed:2}));
  def('treeC',g0({w:15,h:19,cap:[108,190,124],seed:3}));
  def('treeMemory',g0({w:14,h:19,cap:[46,116,86],seed:4}));
  def('treeMemory2',g0({w:12,h:16,cap:[38,100,76],seed:5}));
  def('pine',g0({w:12,h:21,cap:[44,110,88],shape:'pine',trunk:[80,58,40],seed:6}));
  def('pineFut',g0({w:11,h:20,cap:[92,86,168],shape:'pine',trunk:[64,54,96],seed:7}));
  def('treeFut',g0({w:12,h:17,cap:[126,110,206],seed:8}));
  def('treePink',g0({w:13,h:17,cap:[228,140,190],seed:9}));

  // 灌木 / 花 / 石 / 草
  const bush=(col)=>{const c=C(9,8),g=GC(c);for(let y=0;y<8;y++)for(let x=0;x<9;x++){const dx=(x-4)/4.4,dy=(y-3.2)/3.4;if(dx*dx+dy*dy>1)continue;P(g,x,y,1,1,rgbs((x-4)+(y-3)<-1?sh(col,1.18):col));}return outline(c,'#0d1a12');};
  def('bush',bush([64,132,92]));
  def('bushD',bush([44,104,74]));
  const flower=(a,b)=>{const c=C(5,5),g=GC(c);P(g,2,3,1,2,'#3d7a4e');P(g,1,1,1,1,rgbs(a));P(g,3,1,1,1,rgbs(a));P(g,2,0,1,1,rgbs(a));P(g,2,2,1,1,rgbs(b));return c;};
  def('flw1',flower(hex2rgb('#ffd9e8'),hex2rgb('#ffe9a8')));
  def('flw2',flower(hex2rgb('#ffe9a8'),hex2rgb('#ffb36b')));
  def('flw3',flower(hex2rgb('#c9b6ff'),hex2rgb('#e8e2ff')));
  const rock=(col)=>{const c=C(8,7),g=GC(c);const s=[[2,4,4,3],[1,3,2,2],[3,2,3,2],[5,3,2,2],[2,1,2,2]];
    s.forEach(r=>P(g,r[0],r[1],r[2],r[3],rgbs(col)));P(g,2,3,3,2,rgbs(sh(col,1.2)));return outline(c,'#0b0d18');};
  def('rock',rock([120,124,140])); def('rockFut',rock([132,120,180]));
  const tuft=(col)=>{const c=C(5,5),g=GC(c);P(g,1,3,1,2,rgbs(col));P(g,3,3,1,2,rgbs(sh(col,0.85)));P(g,2,2,1,3,rgbs(sh(col,1.15)));return c;};
  def('tuft',tuft([70,140,96]));
  const mush=(cap,stem)=>{const c=C(8,9),g=GC(c);
    for(let y=2;y<5;y++)for(let x=1;x<7;x++){if(((x-3.5)/3.2)**2+((y-3.5)/2)**2>1)continue;P(g,x,y,1,1,rgbs((x<3.5)?sh(cap,1.2):cap));}
    P(g,3,5,2,3,rgbs(stem));P(g,2,7,4,1,rgbs(sh(stem,0.85)));P(g,2,3,1,1,rgbs(sh(cap,1.5)));P(g,5,4,1,1,rgbs(sh(cap,1.5)));
    return outline(c,'#0d0b1a');};
  def('mush',mush([196,110,150],[236,226,206]));
  def('mushB',mush([150,120,220],[228,222,255]));

  // 灯
  const lamp=(glass,glow)=>{const c=C(7,16),g=GC(c);
    P(g,3,5,1,11,'#3a3140');P(g,2,4,3,3,rgbs(glass));P(g,3,3,1,1,rgbs(sh(glow,1.2)));
    P(g,1,15,5,1,'#2b2431');return outline(c,'#0b0a14');};
  def('lamp',lamp(hex2rgb('#ffcf8a'),hex2rgb('#fff0c8')));
  def('lampB',lamp(hex2rgb('#9fd8ff'),hex2rgb('#e6f5ff')));

  // 温暖港湾：灯塔 / 码头 / 小船 / 小屋
  (function(){
    const c=C(17,36),g=GC(c);
    for(let y=6;y<34;y++)for(let x=4;x<13;x++){
      const band=(y>>1)%3===0;
      P(g,x,y,1,1,rgbs(band?[228,224,232]:[196,88,80]));
    }
    P(g,4,6,9,2,rgbs([120,80,70]));
    for(let y=2;y<7;y++){const half=(7-y);for(let x=8-half;x<=8+half;x++)P(g,x,y,1,1,rgbs([70,60,72]));}
    P(g,6,3,5,3,rgbs([255,232,150]));P(g,7,2,3,2,rgbs([255,246,200]));
    P(g,2,34,13,2,rgbs([86,72,64]));
    return def('lighthouse',outline(c,'#0b0a14'));
  })();
  (function(){
    const c=C(26,15),g=GC(c);
    // 支柱
    for(let x=1;x<25;x+=5){P(g,x,7,1,8,'#5c4227');}
    // 甲板
    for(let y=0;y<8;y++)for(let x=0;x<26;x++){
      const line=(y===0||y===7||x%5===0);
      P(g,x,y,1,1,rgbs(line?[104,74,44]:(y<3?[176,134,80]:[150,112,66])));
    }
    // 灯柱
    P(g,1,10,1,5,'#4a3626');P(g,25,10,1,5,'#4a3626');
    return def('dock',outline(c,'#0b0a14'));
  })();
  (function(){
    const c=C(16,13),g=GC(c);
    // 船身（船底收窄）
    for(let y=8;y<12;y++){
      const p=(y-8)/3, hw=7.2-p*2.6;
      for(let x=0;x<16;x++){
        const d=Math.abs(x-7.5);
        if(d>hw) continue;
        P(g,x,y,1,1,rgbs(y>10?[74,48,34]:(d>hw-1.6?[172,112,68]:[132,84,52])));
      }
    }
    // 桅杆 + 帆
    P(g,7,1,1,8,'#5c4227');
    for(let y=1;y<9;y++)for(let x=7;x<7+Math.round(y*0.7);x++) P(g,x,y,1,1,rgbs(x<9?[248,244,236]:[224,218,206]));
    P(g,3,8,6,1,'#3f2c20');
    return def('boat',outline(c,'#0b0a14'));
  })();
  def('cottage1',makeHouse({w:18,h:17,wall:[232,206,168],roof:[198,86,66],win:'#ffd98a'}));
  def('cottage2',makeHouse({w:15,h:15,wall:[214,196,178],roof:[86,110,170],win:'#ffe6a8'}));

  // 知识岛：藏书塔 / 书堆 / 讲台
  (function(){
    const c=C(22,38),g=GC(c);
    for(let y=8;y<36;y++)for(let x=5;x<17;x++){
      const s=(x-11)/6;
      P(g,x,y,1,1,rgbs(s>0.45?[92,104,140]:[118,130,170]));
    }
    for(let y=2;y<9;y++){const half=(9-y)*0.9+2;for(let x=Math.round(11-half);x<=Math.round(11+half);x++)P(g,x,y,1,1,rgbs([76,86,124]));}
    P(g,7,12,3,4,'#ffdb8f');P(g,12,12,3,4,'#ffdb8f');P(g,7,22,3,4,'#9fe0ff');P(g,12,22,3,4,'#9fe0ff');
    P(g,9,32,4,4,'#5a4432');P(g,3,36,16,2,'#5f6a8a');
    P(g,10,0,2,3,'#cfe6ff');
    return def('tower',outline(c,'#0b0a14'));
  })();
  (function(){
    const c=C(9,10),g=GC(c);
    P(g,1,7,7,3,rgbs([168,120,74]));
    P(g,1,4,7,3,rgbs([198,152,96]));P(g,2,1,5,3,rgbs([136,96,64]));
    P(g,2,4,1,1,'#e8c48c');P(g,3,1,1,1,'#e8c48c');
    return def('books',outline(c,'#0b0a14'));
  })();
  (function(){
    const c=C(9,12),g=GC(c);
    P(g,3,4,3,8,'#6a5638');P(g,1,9,7,2,'#584428');P(g,1,2,7,2,'#7d6642');
    P(g,2,0,5,2,'#cfe6ff');
    return def('lectern',outline(c,'#0b0a14'));
  })();

  // 回忆森林：空心树 / 灯串
  (function(){
    const c=C(32,40),g=GC(c);
    for(let y=4;y<40;y++){
      const p=(y-4)/36, half=12*Math.pow(p,0.42)+2;
      for(let x=Math.round(16-half);x<=Math.round(16+half);x++){
        if(x<0||x>=32)continue;
        const dx=(x-16)/half;
        const dark=Math.abs(dx)>0.62;
        P(g,x,y,1,1,rgbs(dark?[52,44,40]:[86,68,56]));
      }
    }
    for(let y=12;y<32;y++)for(let x=13;x<20;x++){
      const dx=(x-16.5)/3.2,dy=(y-24)/7;
      if(dx*dx+dy*dy<1)P(g,x,y,1,1,rgbs([26,22,30]));
    }
    P(g,11,16,2,3,'#ffd88a');P(g,19,21,2,3,'#ffd88a');
    for(let k=0;k<26;k++){const a=k/26*6.283,r=13.5;
      const x=Math.round(16+Math.cos(a)*r), y=Math.round(8+Math.sin(a)*r*0.55);
      if(x>=0&&x<32&&y>=0&&y<40){const h=hash2(x,y,3);
      P(g,x,y,1,1,rgbs(h>0.55?[56,150,104]:h>0.28?[72,168,120]:[38,116,84]));}}
    return def('hollow',outline(c,'#0a0a12'));
  })();
  (function(){
    const c=C(20,4),g=GC(c);
    for(let x=0;x<20;x++){P(g,x,1+Math.round(Math.sin(x*0.9)*0.8),1,1,'#4a4032');if(x%4===0)P(g,x,2,1,1,'#ffd88a');}
    return def('string',c,0.5,0.5);
  })();

  // 创作岛：画室 / 画架 / 旗
  (function(){
    const c=C(24,20),g=GC(c);
    for(let y=8;y<19;y++)for(let x=2;x<22;x++)P(g,x,y,1,1,rgbs(x>13?[214,196,182]:[236,220,204]));
    for(let y=3;y<9;y++){const half=(22/2)*(y-2)/7+2;for(let x=Math.round(12-half);x<=Math.round(12+half);x++)P(g,x,y,1,1,rgbs(y<6?[228,120,158]:[198,92,134]));}
    P(g,5,11,4,4,'#8fd8ff');P(g,15,11,4,4,'#ffd98a');P(g,10,14,4,7,'#7a5a3c');
    // 旗
    P(g,6,0,1,4,'#6b5a42');P(g,7,0,4,2,'#ff9ad5');
    P(g,16,0,1,4,'#6b5a42');P(g,17,0,4,2,'#8fd8ff');
    return def('studio',outline(c,'#0b0a14'));
  })();
  (function(){
    const c=C(12,15),g=GC(c);
    P(g,1,3,1,12,'#6b543a');P(g,10,3,2,12,'#6b543a');P(g,1,7,10,1,'#6b543a');
    P(g,3,1,5,7,rgbs([246,242,236]));P(g,4,2,3,2,'#ff9ad5');P(g,5,4,2,2,'#8fd8ff');
    P(g,0,14,12,1,'#4d3d2b');
    return def('easel',outline(c,'#0b0a14'));
  })();

  // 未来之岛：尖塔 / 穹顶 / 火箭 / 光环
  (function(){
    const c=C(14,36),g=GC(c);
    for(let y=0;y<34;y++){
      const half=1.4+ (y/34)*4.2;
      for(let x=Math.round(7-half);x<=Math.round(7+half);x++){
        if(x<0||x>=14)continue;
        const s=(x-7)/half;
        P(g,x,y,1,1,rgbs(s>0.4?[112,98,190]:s<-0.4?[176,164,246]:[144,132,222]));
      }
    }
    P(g,6,4,2,2,'#dff0ff');P(g,5,13,4,2,'#9fe8ff');P(g,5,24,4,2,'#c9b6ff');
    P(g,2,34,11,2,'#4a4470');
    return def('spire',outline(c,'#0b0a14'));
  })();
  (function(){
    const c=C(20,15),g=GC(c);
    for(let y=0;y<15;y++)for(let x=0;x<20;x++){
      const dx=(x-9.5)/9.5,dy=(y-9)/7;
      if(dx*dx+dy*dy>1)continue;
      P(g,x,y,1,1,rgbs(y<6?[176,164,246]:[126,112,196]));
    }
    P(g,8,3,4,5,'#cfeaff');P(g,9,8,2,6,'#3c3660');
    return def('dome',outline(c,'#0b0a14'));
  })();
  (function(){
    const c=C(11,24),g=GC(c);
    for(let y=4;y<22;y++)for(let x=3;x<8;x++)P(g,x,y,1,1,rgbs(x>5?[212,214,232]:[240,242,252]));
    for(let y=0;y<5;y++){const half=y*0.9+0.5;for(let x=Math.round(5.5-half);x<=Math.round(5.5+half);x++)P(g,x,y,1,1,rgbs([236,120,110]));}
    P(g,4,6,2,3,'#7fd8ff');
    for(let y=22;y<24;y++){const half=2.6-(y-22)*1.2;for(let x=Math.round(5.5-half);x<=Math.round(5.5+half);x++)P(g,x,y,1,1,rgbs([255,190,110]));}
    return def('rocket',outline(c,'#0b0a14'));
  })();
  (function(){
    const c=C(20,7),g=GC(c);
    for(let x=1;x<19;x++){const y=3+Math.sin(x*0.55)*2;P(g,x,Math.round(y),1,1,rgbs([176,170,255]));}
    return def('ring',c,0.5,0.5);
  })();

  // 记忆水晶（条目可视化）
  (function(){
    const c=C(9,15),g=GC(c);
    for(let y=0;y<15;y++){
      const half=y<7? y*0.72+0.6 : (14-y)*0.72+0.6;
      for(let x=Math.round(4-half);x<=Math.round(4+half);x++){
        if(x<0||x>=9)continue;
        const s=(x-4)/Math.max(1,half);
        P(g,x,y,1,1,rgbs(s<-0.35?[236,246,255]:s>0.35?[128,150,210]:[190,214,255]));
      }
    }
    return def('crystalBase',c,0.5,0.5);
  })();
  // 海面礁石小岛
  (function(){
    const c=C(20,14),g=GC(c);
    for(let y=3;y<12;y++)for(let x=0;x<20;x++){
      const dx=(x-9.5)/9.5,dy=(y-7.5)/4.5;
      if(dx*dx+dy*dy>1)continue;
      P(g,x,y,1,1,rgbs(y<6?[120,148,124]:[206,180,138]));
    }
    return def('islet',c,0.5,0.9);
  })();

  /* ======= 记录类型可视化：成长树 / 风景 ======= */
  (function(){ // 成长树（目标）：圆冠 + 果实，比环境树更亮
    const c=makeTree({cap:[170,232,142], trunk:[104,74,48], w:17,h:24});
    const g=GC(c);
    P(g,5,7,1,1,'#ffe9a8');P(g,11,9,1,1,'#ffe9a8');P(g,8,5,1,1,'#fff4cf');P(g,13,12,1,1,'#ffe9a8');
    return def('treeGoal',outline(c,'#0d1a10'));
  })();
  (function(){ // 风景：石拱门
    const c=C(20,18),g=GC(c);
    for(let y=4;y<16;y++){P(g,2,y,3,1,rgbs([176,168,152]));P(g,15,y,3,1,rgbs([152,146,132]));}
    for(let y=0;y<6;y++)for(let x=2;x<18;x++){const d=Math.abs(x-9.5)/8;if(y<(1-d*d)*5.6)P(g,x,y,1,1,rgbs(y<3?[200,192,174]:[168,160,144]));}
    P(g,9,7,2,9,'#6f7f6a');
    return def('scnArch',outline(c,'#0c0b16'),0.5,1);
  })();
  (function(){ // 风景：热气球
    const c=C(18,26),g=GC(c);
    for(let y=0;y<15;y++)for(let x=0;x<18;x++){
      const dx=(x-8.5)/8.2, dy=(y-7.5)/7.4;
      if(dx*dx+dy*dy>1)continue;
      const lit=(-dx*0.7-dy*0.6);
      P(g,x,y,1,1,rgbs(lit>0.25?[255,214,140]:lit>-0.2?[232,120,120]:[176,84,110]));
    }
    P(g,6,2,3,1,'#fff0c8');
    P(g,7,15,1,3,'#c9a26a');P(g,10,15,1,3,'#c9a26a');
    for(let y=18;y<23;y++)for(let x=6;x<12;x++)P(g,x,y,1,1,rgbs(y<19?[148,104,64]:[120,82,52]));
    return def('scnBalloon',outline(c,'#0c0b16'),0.5,1);
  })();
  (function(){ // 风景：瀑布
    const c=C(20,22),g=GC(c);
    for(let y=0;y<10;y++)for(let x=0;x<20;x++)P(g,x,y,1,1,rgbs(y<4?[122,138,120]:[100,116,100]));
    for(let y=6;y<20;y++){const half=4.5-y*0.06;for(let x=Math.round(10-half);x<=Math.round(10+half);x++){
      const k=(y*3+x)%5;P(g,x,y,1,1,k===0?'#eaf6ff':k<3?'#9fd6f5':'#6fb2e0');}}
    for(let y=19;y<22;y++)for(let x=3;x<18;x++){if((x+y)%3===0)continue;P(g,x,y,1,1,rgbs([214,232,246]));}
    return def('scnFall',outline(c,'#0c0b16'),0.5,1);
  })();
  (function(){ // 风景：风车
    const c=C(20,24),g=GC(c);
    for(let y=8;y<23;y++){const half=2.6+(y-8)*0.14;for(let x=Math.round(10-half);x<=Math.round(10+half);x++)P(g,x,y,1,1,rgbs(x>10?[222,214,196]:[240,234,218]));}
    P(g,7,6,1,7,'#8a7248');P(g,13,6,1,7,'#8a7248');
    P(g,4,3,13,2,'#c9a25e');P(g,9,1,3,6,'#c9a25e');
    P(g,9,11,2,3,'#7a5a3a');
    return def('scnMill',outline(c,'#0c0b16'),0.5,1);
  })();
  (function(){ // 风景：帐篷营地
    const c=C(18,16),g=GC(c);
    for(let y=0;y<14;y++){const half=(y+1)*0.62;for(let x=Math.round(9-half);x<=Math.round(9+half);x++){
      if(x<0||x>=18)continue;const lit=(9-x)/9;P(g,x,y+2,1,1,rgbs(lit>0.15?[236,142,96]:[206,104,72]));}}
    P(g,8,7,3,7,'#5c3a28');
    P(g,2,12,2,3,'#8a6a44');
    return def('scnTent',outline(c,'#0c0b16'),0.5,1);
  })();
  (function(){ // 风景：观景台
    const c=C(20,20),g=GC(c);
    P(g,4,8,13,2,rgbs([190,164,120]));
    for(let y=10;y<19;y++){P(g,4,y,1,1,'#8a6a44');P(g,16,y,1,1,'#8a6a44');P(g,10,y,1,1,'#8a6a44');}
    P(g,3,4,1,5,'#8a6a44');P(g,17,4,1,5,'#8a6a44');P(g,3,4,15,1,'#a98a5c');
    P(g,9,6,2,2,'#ffd88a');
    return def('scnLook',outline(c,'#0c0b16'),0.5,1);
  })();

  /* ======= 爱乐之城：音乐厅 / 音箱 / 唱片 / 音符装饰 ======= */
  (function(){ // 音乐厅（带金色穹顶与舞台灯光的建筑）
    const c=C(28,30),g=GC(c);
    // 主体
    for(let y=12;y<29;y++)for(let x=4;x<24;x++)P(g,x,y,1,1,rgbs(x>14?[74,62,110]:[92,78,134]));
    // 拱门
    P(g,10,19,8,10,'#2a2240');P(g,12,22,4,7,'#ffd166');P(g,11,25,6,1,'#4a3a66');
    // 穹顶（金色）
    for(let y=2;y<13;y++){const half=(y-1)*0.95;for(let x=Math.round(14-half);x<=Math.round(14+half);x++)P(g,x,y,1,1,rgbs(y<6?[255,235,168]:y<10?[255,209,102]:[196,150,74]));}
    // 顶端音符灯
    P(g,13,0,2,2,'#fff4cf');P(g,14,0,1,3,'#fff4cf');
    // 舞台灯光（两侧）
    P(g,2,16,2,4,'#ffd166');P(g,24,16,2,4,'#ffd166');
    // 基座
    P(g,2,29,24,1,'#3a2f52');
    return def('musicHall',outline(c,'#0b0a14'));
  })();
  (function(){ // 音箱（舞台音箱，带圆形喇叭）
    const c=C(16,18),g=GC(c);
    for(let y=1;y<17;y++)for(let x=1;x<15;x++)P(g,x,y,1,1,rgbs(x>8?[52,44,72]:[70,58,96]));
    P(g,2,3,12,6,'#241d38');P(g,4,5,8,2,'#3a2f52');
    P(g,5,8,6,6,'#120e20');P(g,6,9,4,4,'#8a6fd0');P(g,7,10,2,2,'#c9b6ff');
    P(g,2,17,12,1,'#241d38');
    return def('speaker',outline(c,'#0b0a14'));
  })();
  (function(){ // 唱片（黑胶唱片，带金色中心贴纸）
    const c=C(18,18),g=GC(c);
    for(let y=0;y<18;y++)for(let x=0;x<18;x++){
      const dx=(x-8.5)/8.5,dy=(y-8.5)/8.5,dd=dx*dx+dy*dy;
      if(dd>1)continue;
      const ring=Math.floor(Math.sqrt(dd)*7)%2===0;
      P(g,x,y,1,1,ring?'#241d38':'#120e20');
    }
    P(g,7,7,3,3,'#ffd166');P(g,8,8,1,1,'#fff0c8');
    return def('record',outline(c,'#0b0a14'),0.5,0.5);
  })();
  (function(){ // 音符装饰（小号八分音符，用于草地散落）
    const c=C(8,11),g=GC(c);
    P(g,5,1,1,7,'#c9b6ff');P(g,6,1,2,1,'#e8dfff');
    P(g,6,3,2,1,'#ffd166');P(g,7,4,2,1,'#ffd166');
    for(let y=0;y<3;y++)for(let x=0;x<3;x++){
      if((x===0||x===2)&&(y===0||y===2))continue;
      P(g,2+x,8+y,1,1,'#c9b6ff');
    }
    return def('note',outline(c,'#0b0a14'),0.5,0.9);
  })();
}
/* 旅行可解锁的风景清单（按顺序解锁） */
const SCENERY=['scnArch','scnBalloon','scnFall','scnMill','scnTent','scnLook'];
/* 记忆水晶着色（按岛配色） */
const crystalCache={};
function crystal(color,seed){
  const key=color+'|'+seed; if(crystalCache[key])return crystalCache[key];
  const c=C(11,17),g=GC(c), col=hex2rgb(color);
  for(let y=0;y<13;y++){
    const half=y<6? y*0.85+1 : (12-y)*0.85+1;
    for(let x=Math.round(5-half);x<=Math.round(5+half);x++){
      if(x<0||x>=11)continue;
      const s=(x-5)/Math.max(1,half);
      P(g,x+0,y+2,1,1,rgbs(s<-0.3?[250,252,255]:s>0.3?sh(col,0.55):sh(col,1.25)));
    }
  }
  g.globalAlpha=0.45;P(g,5,2,1,2,'#ffffff');g.globalAlpha=1;
  crystalCache[key]=c;return c;
}
/* 星星（记忆）/ 音符（音乐）着色缓存 */
const markCache={};
function starSprite(color){
  const key='s|'+color; if(markCache[key])return markCache[key];
  const c=C(11,11),g=GC(c),col=hex2rgb(color);
  for(let y=0;y<11;y++)for(let x=0;x<11;x++){
    const d=Math.abs(x-5)+Math.abs(y-5);
    if(d<=3.6) P(g,x,y,1,1, d<1.3?'#ffffff':rgbs(sh(col,d<2.5?1.4:1.02)));
  }
  P(g,5,0,1,1,'#ffffff');P(g,5,10,1,1,'#ffffff');P(g,0,5,1,1,'#ffffff');P(g,10,5,1,1,'#ffffff');
  markCache[key]=c;return c;
}
function noteSprite(color){
  const key='n|'+color; if(markCache[key])return markCache[key];
  const c=C(10,13),g=GC(c),col=hex2rgb(color);
  P(g,6,2,1,8,rgbs(col));
  P(g,7,2,2,1,rgbs(sh(col,1.35)));P(g,8,3,2,1,rgbs(sh(col,1.18)));P(g,8,4,2,1,rgbs(sh(col,1.02)));
  for(let y=0;y<3;y++)for(let x=0;x<3;x++){
    if((x===0||x===2)&&(y===0||y===2))continue;
    P(g,3+x,10+y,1,1,rgbs(col));
  }
  markCache[key]=c;return c;
}
/* 未来之岛 · 道路旁的大星星（放在 markCache/starSprite 之后，避免初始化顺序问题） */
def('bigStar',starSprite('#c9b6ff'),0.5,0.72);
/* 爱乐之城 · 道路旁的大音符（自绘精灵：金色八分音符，醒目且贴合音乐主题） */
(function(){
  const W=26,H=40,c=C(W,H),g=GC(c);
  const col=[255,209,102], hi=[255,235,168], dk=[176,132,60];
  // 符头（椭圆形）
  for(let y=26;y<36;y++)for(let x=8;x<20;x++){
    const dx=(x-13.5)/6.2, dy=(y-31)/4.6;
    if(dx*dx+dy*dy>1)continue;
    const lit=(-dx*0.7-dy*0.5);
    P(g,x,y,1,1,rgbs(lit>0.2?hi:lit>-0.15?col:dk));
  }
  // 符干
  P(g,18,4,3,28,rgbs(col)); P(g,18,4,1,28,rgbs(hi));
  // 符尾（右向小旗）
  P(g,21,5,4,1,rgbs(col)); P(g,22,6,4,1,rgbs(sh(col,0.88))); P(g,23,7,4,1,rgbs(sh(col,0.76)));
  // 底部光环
  for(let x=2;x<24;x++){const y=38+Math.round(Math.sin((x-2)*0.5)*1.2);P(g,x,y,1,1,rgbs([255,240,180]));}
  return def('bigNote',outline(c,'#0b0a14'),0.5,0.92);
})();
/* 知识岛 · 道路旁的大书本：一本摊开的大书（自绘精灵，比小书堆醒目得多） */
(function(){
  const W=42,H=32,c=C(W,H),g=GC(c);
  const page=[247,242,229], pageD=[225,217,200], line=[178,190,210];
  const cover=[56,108,178], coverD=[36,72,128], coverL=[120,176,236];
  const cx=21, y0=9, y1=26;                       // 书脊中线 / 页面上沿 / 下沿
  for(let y=y0;y<=y1;y++){
    const t=(y-y0)/(y1-y0);                       // 0 上 → 1 下
    const len=Math.round(17.5*(0.62+0.38*t));     // 页面往下越宽
    for(let k=0;k<len;k++){
      const outer=(k>len-3);
      const col=outer?coverD:((y-y0)%4===0?pageD:page);
      P(g,cx-3-k,y,1,1,rgbs(col));
      P(g,cx+1+k,y,1,1,rgbs(col));
    }
  }
  P(g,cx-1,y0-1,2,y1-y0+2,rgbs(coverD));          // 书脊
  P(g,2,y1+1,38,3,rgbs(cover));                   // 封面下沿
  P(g,2,y1+1,38,1,rgbs(coverL));
  P(g,1,y0+1,2,y1-y0+1,rgbs(cover));              // 左侧封面边
  P(g,39,y0+1,2,y1-y0+1,rgbs(cover));             // 右侧封面边
  P(g,4,y0-1,15,1,rgbs(coverL)); P(g,23,y0-1,15,1,rgbs(coverL));   // 页面上沿高光
  for(let k=0;k<3;k++){                            // 页面上的字
    const y=y0+3+k*4;
    P(g,6,y,11,1,rgbs(line)); P(g,25,y,11,1,rgbs(line));
  }
  P(g,cx-1,y0-4,3,4,'#ffd86b');                    // 金色书签
  return def('bigBook',outline(c,'#0b0a14'));
})();
/* 新记录的生长动画（0 → 1，带一点回弹） */
function growT(p){
  if(!p||!p.born) return 1;
  const age=Date.now()-p.born;
  if(age<0||age>1500) return 1;
  const t=clamp(age/1000,0,1), e=1-Math.pow(1-t,3);
  return Math.max(0.05, e*(1+0.16*Math.sin(t*Math.PI)));
}

/* ---------------- 5. 场景物件布置 ---------------- */
const PROPS=[];   // {spr,x,y,scale,glow,type,id}
function push(spr,x,y,o){PROPS.push(Object.assign({spr,x,y,sc:1},o||{}));}

/* 道路旁的大地标：每座岛默认就有一个「大物件」站在桥头（道路）旁，
   跟有没有写过记忆无关 —— 知识岛大书本 / 回忆森林大树 / 创作岛大画板 /
   未来之岛大星星 / 温暖港湾大房子 */
const ROAD_LANDMARK={
  harbor:   {spr:'cottage1', sc:2.40, side: 1},
  knowledge:{spr:'bigBook',  sc:1.00, side: 1},
  memory:   {spr:'treeC',    sc:2.50, side:-1},
  creation: {spr:'easel',    sc:3.00, side:-1},
  future:   {spr:'bigStar',  sc:3.30, side: 1},
  music:    {spr:'bigNote',  sc:2.60, side: 1}
};
/* 这座岛的「道路」（桥）落在岛上的位置，以及岛的朝外方向 */
function roadHeadOf(i){
  if(!BRIDGES.length) return null;
  if(i.id==='harbor'){
    const br=BRIDGES.find(b=>Math.hypot(b.a[0]-i.x,b.a[1]-i.y)<=i.r*1.35)||BRIDGES[0];
    if(!br) return null;
    return {x:i.x+br.ux*i.r*0.90, y:i.y+br.uy*i.r*0.90, out:{x:br.ux,y:br.uy}};
  }
  const br=BRIDGES.find(b=>b.target===i);
  if(!br) return null;
  return {x:br.b[0], y:br.b[1], out:{x:-br.ux, y:-br.uy}};   // br.b 在岛缘，朝外 = 背离岛心
}
/* 站在桥头，朝岛内退一点、再往路的一侧挪一挪，找一块站得住的草地 */
function roadSideSpot(i,cfg){
  const h=roadHeadOf(i); if(!h) return null;
  const nx=-h.out.y, ny=h.out.x;                    // 路的侧向
  let firstOk=null;
  for(const back of [6,9,12,16,20,24]){
    for(const off of [cfg.side*10, cfg.side*13, cfg.side*16, cfg.side*19, -cfg.side*10]){
      const x=h.x-h.out.x*back+nx*off, y=h.y-h.out.y*back+ny*off;
      const t=terrAt(x,y);
      if(t.i!==i||(t.t!=='grass'&&t.t!=='core')) continue;
      if(distToBridge(x,y)<=5) continue;
      if(!firstOk) firstOk={x,y};
      let clash=false;
      for(const p of PROPS){ if(p.landmark) continue; if(Math.hypot(p.x-x,p.y-y)<11){clash=true;break;} }
      if(!clash) return {x,y};
    }
  }
  return firstOk;
}
function buildProps(){
  PROPS.length=0;
  for(const i of ISLANDS){
    const R=mulberry32(i.seed*977+3);
    const keep=[];
    // 地标
    const B=i.build;
    B.forEach(b=>{push(b.spr,i.x+b.dx,i.y+b.dy,{sc:b.sc||1}); keep.push([i.x+b.dx,i.y+b.dy,b.r||9]);});
    // 道路旁的大地标（默认就有，不用先写记忆）
    const lcfg=ROAD_LANDMARK[i.id];
    if(lcfg){
      const sp=roadSideSpot(i,lcfg);
      if(sp){ const spcv=SPR[lcfg.spr];
        push(lcfg.spr,sp.x,sp.y,{sc:lcfg.sc,landmark:true,glow:i.color});
        keep.push([sp.x,sp.y,Math.max(9,(spcv?spcv.cv.width*lcfg.sc:10)*0.5+3)]); }
    }
    // 树 & 装饰
    const treeList=i.trees, decoList=i.decoList;
    const tryPlace=(list,count,keepMin,sprSel)=>{
      let tries=0,placed=0;
      while(placed<count&&tries<count*40){
        tries++;
        const a=R()*6.2832, rr=Math.sqrt(R())*i.r*0.94;
        const x=i.x+Math.cos(a)*rr, y=i.y+Math.sin(a)*rr;
        const t=terrAt(x,y);
        if(t.i!==i) continue;
        if(t.t!=='grass'&&t.t!=='core') continue;
        if(distToBridge(x,y)<4.2) continue;
        let ok=true;
        for(const k of keep){if(Math.hypot(x-k[0],y-k[1])<k[2]){ok=false;break;}}
        if(ok) for(const p of PROPS){if(Math.hypot(x-p.x,y-p.y)<keepMin){ok=false;break;}}
        if(!ok) continue;
        const s=sprSel(R);
        push(s,x,y,{sc:0.86+R()*0.34,flip:R()>0.5});
        keep.push([x,y,keepMin*0.85]);
        placed++;
      }
    };
    if(treeList&&treeList.length) tryPlace(treeList,i.treeCount||14,3.2,r=>treeList[(r()*treeList.length)|0]);
    if(decoList&&decoList.length) tryPlace(decoList,i.decoCount||10,1.9,r=>decoList[(r()*decoList.length)|0]);
  }
  // 外海小礁岛：散在世界之外的深海里，缩小视野时海面不会空
  const HB=ISL.harbor||ISLANDS[0];
  let outer=140;
  for(const i of ISLANDS) outer=Math.max(outer, Math.hypot(i.x-HB.x,i.y-HB.y)+i.r);
  for(let k=0;k<30;k++){
    const R=mulberry32(400+k*31);
    for(let tr=0;tr<80;tr++){
      const a=R()*6.2832, rad=outer+18+R()*340;
      const x=HB.x+Math.cos(a)*rad, y=HB.y+Math.sin(a)*rad*0.97;
      if(terrAt(x,y).t!=='deep') continue;
      let ok=true;
      for(const p of PROPS) if(Math.hypot(x-p.x,y-p.y)<16){ok=false;break;}
      if(!ok) continue;
      push('islet',x,y,{sc:0.7+R()*0.6});
      if(R()>0.35) push(R()>0.5?'pine':'treeB',x+2-R()*4,y-1-R()*2,{sc:0.5+R()*0.25});
      break;
    }
  }
  // 记录产生的世界变化（星星/成长树/风景/音符）
  refreshMarkers();
}
const GOLDEN=2.39996323;
/* 用黄金角把同类标记铺开，半径按序号从内到外 */
function markerPos(i,k,n,near,far,phase){
  const a=k*GOLDEN+phase+i.seed*0.7;
  const t=clamp((k+0.5)/Math.max(1,n),0,1);
  const rr=i.r*(near+(far-near)*t);
  return {x:i.x+Math.cos(a)*rr, y:i.y+Math.sin(a)*rr*0.94};
}
/* 等角铺开 + 内外两档半径，做出「一圈一圈」的观感 */
function ringSpot(i,k,near,far,start,step){
  const a=start+k*step+(i.seed%9)*0.11;
  const rr=i.r*((k%2)?far:near);
  return {x:i.x+Math.cos(a)*rr, y:i.y+Math.sin(a)*rr*0.94};
}
/* 把「用户写了什么」映射成「岛上多了什么」 */
function refreshMarkers(){
  for(let k=PROPS.length-1;k>=0;k--) if(PROPS[k].mark) PROPS.splice(k,1);
  ISLANDS.forEach(i=>{
    const ents=(state.regions[i.id]&&state.regions[i.id].entries)||[];
    const by=k=>ents.filter(e=>(e.kind||'memory')===k);
    const stars=by('memory'), goals=by('goal'), trips=by('travel'), notes=by('music'), recalls=by('recall');
    // 记忆 → 一颗星星（绕着岛一圈）
    stars.forEach((e,k)=>{
      const p=markerPos(i,k,Math.min(stars.length,16),0.60,0.86,0.9);
      PROPS.push({mark:'star',x:p.x,y:p.y,color:i.color,phase:k*1.1+i.seed,
        born:e.bornAt||0, lit:!!e.litAt, sc:0.9+((k%3)*0.12),entryId:e.id,islandId:i.id,kind:'memory'});
    });
    // 目标 → 一棵成长树（岛内一圈，只增不减，第 N 条就是第 N 棵）
    goals.forEach((e,k)=>{
      const p=ringSpot(i,k,0.30,0.46,2.1,1.35);
      PROPS.push({mark:'goal',spr:'treeGoal',x:p.x,y:p.y,sc:0.80+Math.min(0.34,k*0.06),
        born:e.bornAt||0, phase:k*1.3+i.seed,entryId:e.id,islandId:i.id,kind:'goal'});
    });
    // 旅行 → 解锁一处新风景（按顺序，每次解锁下一个）
    trips.forEach((e,k)=>{
      const p=ringSpot(i,k,0.52,0.63,-0.9,1.45);
      PROPS.push({mark:'scn',spr:SCENERY[k%SCENERY.length],x:p.x,y:p.y,sc:0.88+((k%2)*0.1),
        born:e.bornAt||0, phase:k*0.9+i.seed,entryId:e.id,islandId:i.id,kind:'travel'});
    });
    // 音乐 → 只留少量悬浮音符。数量多时用一枚「旋律匣」聚合成入口，
    // 每条音乐仍完整保存在列表里，进入岛屿后可从详情中逐条播放。
    const noteVisualLimit=7;
    const visibleNotes=notes.slice(0,noteVisualLimit);
    visibleNotes.forEach((e,k)=>{
      const p=ringSpot(i,k,0.84,0.96,-0.35,1.75);
      PROPS.push({mark:'note',x:p.x,y:p.y,color:i.color,phase:k*1.7+i.seed,
        born:e.bornAt||0, sc:0.95+((k%2)*0.14),entryId:e.id,islandId:i.id,kind:'music'});
    });
    if(notes.length>noteVisualLimit){
      const p=ringSpot(i,noteVisualLimit,0.84,0.96,-0.35,1.75);
      PROPS.push({mark:'melody',x:p.x,y:p.y,color:i.color,phase:i.seed*1.7,
        count:notes.length, openRegion:true, islandId:i.id, kind:'music'});
    }
    recalls.forEach((e,k)=>{const p=ringSpot(i,k,0.69,0.81,2.6,1.62);PROPS.push({mark:'recall',x:p.x,y:p.y,phase:k*1.3+i.seed,born:e.bornAt||0,entryId:e.id,islandId:i.id,kind:'recall'});});
    i.musicCount=notes.length;
    i.starCount=stars.length; i.goalCount=goals.length; i.tripCount=trips.length;
  });
  refreshEcology();
  PROPS.sort((a,b)=>a.y-b.y);
}

/* ---------------- 6. 岛屿地标 & 视觉配置 ---------------- */
function configureIsland(i){
  if(i.custom){
    // 自建岛：整套从主题取
    const th=ISLAND_THEMES[i.theme]||ISLAND_THEMES.garden;
    i.color=i.color||th.color;
    i.build=th.build; i.trees=th.trees; i.treeCount=th.treeCount;
    i.decoList=th.decoList; i.decoCount=th.decoCount; i.glow=th.glow;
    return;
  }
  if(i.build) return;   // 内置岛只配置一次
  if(i.id==='harbor'){
    i.build=[{spr:'lighthouse',dx:-24,dy:-22,sc:1.0,r:11},{spr:'cottage1',dx:14,dy:-20,sc:1,r:13},
             {spr:'cottage2',dx:-6,dy:-28,sc:1,r:11},{spr:'dock',dx:20,dy:30,sc:1.05,r:12},
             {spr:'boat',dx:34,dy:40,sc:1,r:10},{spr:'boat',dx:-30,dy:36,sc:1,r:10},
             {spr:'lamp',dx:-14,dy:8,sc:1,r:4},{spr:'lamp',dx:10,dy:12,sc:1,r:4},{spr:'lamp',dx:0,dy:-6,sc:1,r:4}];
    i.trees=['treeA','treeB','treeC']; i.treeCount=16;
    i.decoList=['flw1','flw2','bush','tuft']; i.decoCount=22;
    i.glow='rgba(255,178,107,.30)';
  }else if(i.id==='knowledge'){
    i.build=[{spr:'tower',dx:0,dy:-8,sc:1,r:13},{spr:'books',dx:-16,dy:12,sc:1,r:6},
             {spr:'lectern',dx:15,dy:10,sc:1,r:6},{spr:'lampB',dx:-8,dy:18,sc:1,r:4},{spr:'lampB',dx:9,dy:-22,sc:1,r:4}];
    i.trees=['treeA','treeB','pine']; i.treeCount=7;
    i.decoList=['rock','tuft','bush']; i.decoCount=14;
    i.glow='rgba(111,180,255,.30)';
  }else if(i.id==='memory'){
    i.build=[{spr:'hollow',dx:0,dy:2,sc:1,r:15},{spr:'string',dx:0,dy:-24,sc:1,r:2},{spr:'lamp',dx:-18,dy:16,sc:1,r:4}];
    i.trees=['treeMemory','treeMemory2','pine']; i.treeCount=20;
    i.decoList=['mush','mushB','bushD','tuft']; i.decoCount=16;
    i.glow='rgba(111,220,174,.28)';
  }else if(i.id==='creation'){
    i.build=[{spr:'studio',dx:0,dy:-6,sc:1,r:14},{spr:'easel',dx:-16,dy:14,sc:1,r:7},
             {spr:'easel',dx:17,dy:12,sc:1,r:7},{spr:'cottage2',dx:12,dy:-18,sc:1,r:11}];
    i.trees=['treePink','treeA','bush']; i.treeCount=8;
    i.decoList=['flw1','flw3','bush','tuft']; i.decoCount=16;
    i.glow='rgba(255,154,213,.28)';
  }else if(i.id==='music'){
    i.build=[{spr:'musicHall',dx:0,dy:-6,sc:1,r:16},{spr:'speaker',dx:-18,dy:12,sc:1,r:7},
             {spr:'speaker',dx:18,dy:14,sc:1,r:7},{spr:'record',dx:12,dy:-22,sc:1,r:9}];
    i.trees=['treePink','treeA','bush']; i.treeCount=8;
    i.decoList=['flw3','tuft','note']; i.decoCount=9;
    i.glow='rgba(255,209,102,.32)';
  }else{
    i.build=[{spr:'spire',dx:-13,dy:-6,sc:1,r:6},{spr:'spire',dx:11,dy:0,sc:0.8,r:6},
             {spr:'dome',dx:0,dy:14,sc:1,r:11},{spr:'rocket',dx:-2,dy:-20,sc:1,r:7},
             {spr:'ring',dx:2,dy:-30,sc:1,r:6}];
    i.trees=['treeFut','pineFut']; i.treeCount=8;
    i.decoList=['rockFut','tuft']; i.decoCount=12;
    i.glow='rgba(183,156,255,.30)';
  }
}

/* ---------------- 7. 状态与存储 ---------------- */
const KEY='lifeWorld.v1';
const KEY_UID='lifeWorld.uid';       // 记住上次登录的 uid（账号自己的世界）
let state={name:'我的世界', regions:{}, created:Date.now()};
const DEFAULT_DESC=Object.fromEntries(ISLANDS.map(i=>[i.id,{tag:i.tag,desc:i.desc}]));

function loadState(){
  try{
    const raw=localStorage.getItem(KEY);
    if(raw){const s=JSON.parse(raw); if(s&&s.regions){state=s; return true;}}
  }catch(e){}
  return false;
}
/* 大音频缓存在 IndexedDB 里；写进 localStorage 时只保留条目信息，避免撑爆浏览器本地存储 */
function storageSnapshot(src){
  let out;
  try{ out=JSON.parse(JSON.stringify(src)); }catch(e){ return src; }
  Object.values(out.regions||{}).forEach(region=>{
    if(!region||!Array.isArray(region.entries))return;
    region.entries.forEach(entry=>{
      if(entry&&entry.audioStore==='idb'&&entry.audioBlobId) delete entry.audio;
    });
  });
  return out;
}
function worldHasStoredAudio(){
  const regions=state.regions||{};
  for(const id in regions){
    const ents=regions[id]&&regions[id].entries;
    if(!Array.isArray(ents))continue;
    for(const e of ents){ if(e&&e.audioStore==='idb'&&e.audioBlobId) return true; }
  }
  return false;
}
function saveState(){
  state.updatedAt=new Date().toISOString();
  const payload=worldHasStoredAudio()?storageSnapshot(state):state;
  try{ localStorage.setItem(KEY,JSON.stringify(payload)); }
  catch(e){
    try{ localStorage.setItem(KEY,JSON.stringify(storageSnapshot(state))); }
    catch(e2){ toast('本地存储空间不足：请删掉一些图片或较大的音乐后重试'); return false; }
  }
  // 登录后将最新世界同步到公共空间，好友刷新时会直接读取这一版（含音频）。
  try{ if(Cloud&&Cloud.ready&&!Cloud.guest) Cloud.pushWorld(state); }catch(e){}
  return true;
}
function ensureRegion(id){
  if(!state.regions[id]) state.regions[id]={custom:null,entries:[]};
  return state.regions[id];
}
function regionName(i){const r=state.regions[i.id];return (r&&r.custom)||i.name;}
function regionTag(i){const r=state.regions[i.id];return (r&&r.customTag)||i.tag;}
function totalEntries(){return ISLANDS.reduce((s,i)=>s+((state.regions[i.id]&&state.regions[i.id].entries.length)||0),0);}

/* ---- 自建岛屿 ---- */
function applyCustomIslands(){
  const list=(state.islands||[]);
  list.forEach((c,k)=>{
    if(ISL[c.id]||ISLANDS.some(x=>x.id===c.id)) return;
    const th=ISLAND_THEMES[c.theme]||ISLAND_THEMES.garden;
    ISLANDS.push({id:c.id,name:c.name,emoji:c.emoji,tag:c.tag||'我创造的区域',
      desc:c.desc||'我自己加进世界的一块地方', color:c.color||th.color, theme:c.theme,
      x:c.x,y:c.y,r:c.r||27, seed:c.seed||(120+k*17), near:c.near||null, custom:true, grass:th.grass, core:th.core});
  });
}
function addIsland(name,emoji,themeKey,desc,nearId){
  const used=ISLANDS.filter(i=>i.custom).length;
  const anchor=(nearId&&ISL[nearId])?ISL[nearId]:null;
  const slot=anchor?nextSlotNearIsland(anchor.id):nextCustomSlot(); // 数量不限：优先落在指定岛旁，住满后自动往外长
  const id='c'+Math.random().toString(36).slice(2,8);
  const th=ISLAND_THEMES[themeKey]||ISLAND_THEMES.garden;
  const isl={id,name:(name||'').trim()||('新的岛屿 '+(used+1)), emoji:emoji||'🌊',
    tag:(desc||'').trim()||'我创造的区域', desc:(desc||'').trim()||'我自己加进世界的一块地方',
    color:th.color, theme:themeKey, x:slot.x, y:slot.y, r:slot.r, seed:100+used*13,
    near:anchor?anchor.id:null, custom:true, grass:th.grass, core:th.core};
  ISLANDS.push(isl);
  if(!state.islands) state.islands=[];
  state.islands.push({id,name:isl.name,emoji:isl.emoji,tag:isl.tag,desc:isl.desc,
    color:isl.color,theme:themeKey,x:isl.x,y:isl.y,r:isl.r,seed:isl.seed,near:isl.near});
  ensureRegion(id);
  if(!saveState()) return null;
  if(batchAdd) return id;                 // 批量导入时先不重建，最后统一来一次
  rebuildWorld(); buildChips(); refreshHeader();
  return id;
}
let batchAdd=false;                        // 批量加岛时合并重建（N 次加岛只重建一次）
function removeIsland(id){
  const idx=ISLANDS.findIndex(i=>i.id===id);
  if(idx<0||!ISLANDS[idx].custom) return;
  ISLANDS.splice(idx,1);
  if(state.islands) state.islands=state.islands.filter(c=>c.id!==id);
  const gone=(state.regions[id]&&state.regions[id].entries)||[];
  gone.forEach(e=>{ if(e&&e.audioStore==='idb'&&e.audioBlobId){ try{AudioStore.del(e.audioBlobId);}catch(err){} } });
  delete state.regions[id];
  saveState(); rebuildWorld(); buildChips(); refreshHeader();
}
/* 地形 / 桥梁 / 氛围 / 装饰 全量重建（加岛或删岛后调用） */
function rebuildWorld(){
  rebuildISL(); rebuildCoastLUT(); computeWorldBounds(); rebuildBridges();
  ISLANDS.forEach(configureIsland);
  buildTerrain(); buildBridges(); buildFXLayers(); buildProps();   // 深海贴图与世界大小无关，只建一次
  miniDirty=true;                                 // 小地图缩略风景跟着世界一起更新
  recalcFit();                                    // 世界变大了，缩放范围跟着更新
}

/* 生成示例配图（离线可用，无外链） */
function seedImage(title,a,b,c){
  const cv=canvasURL(480,320,(g,w,h)=>{
    const grd=g.createLinearGradient(0,0,w,h);
    grd.addColorStop(0,a);grd.addColorStop(0.55,b);grd.addColorStop(1,c);
    g.fillStyle=grd;g.fillRect(0,0,w,h);
    g.globalAlpha=0.22;
    for(let k=0;k<7;k++){
      g.beginPath();
      g.arc(40+((k*137)%420), 60+((k*211)%230), 40+((k*53)%90), 0, 6.2832);
      g.fillStyle=k%2?'#ffffff':'#000018';g.fill();
    }
    g.globalAlpha=1;
    g.fillStyle='rgba(10,10,24,.28)';g.fillRect(0,h-70,w,70);
    g.fillStyle='#ffffff';g.font='600 26px sans-serif';g.textBaseline='bottom';
    g.fillText(title,24,h-24);
    g.fillStyle='rgba(255,255,255,.7)';g.font='13px sans-serif';
    g.fillText('示例配图 · 可删除后换成你的照片',24,h-56);
  });
  return cv.toDataURL('image/jpeg',0.72);
}
function seedData(){
  state={name:'我的世界', created:Date.now(), islands:[], regions:{}};
  const now=Date.now(), D=86400000;
  const add=(id,title,text,days,colors,kind)=>{
    const e={id:'e'+Math.random().toString(36).slice(2,9),title,text,
      kind:kind||'memory', target:null, bornAt:0,
      date:new Date(now-days*D).toISOString(),
      images:colors?[seedImage(title.split('·')[0].trim(),colors[0],colors[1],colors[2])]:[]};
    ensureRegion(id).entries.push(e);
    return e;
  };
  // 记忆 → 星星
  const marathon=add('knowledge','第 37 届编程马拉松','三天几乎没合眼。凌晨四点，我们第一次把整条链路跑通，屏幕上的灯光比窗外的城市还亮。\n\n原来"做出来"这四个字，是有重量的。',6,['#2b3a86','#4f6bd8','#8fd8ff'],'memory');
  add('memory','外婆家的夏天','院子里的石榴树比我高两倍。她总是把西瓜泡在井水里，切开的时候，整个夏天都凉了。',240,['#7a4a2a','#c98a4a','#f6d9a0'],'memory');
  add('memory','搬家那天的照片','纸箱堆到天花板，猫在唯一没打包的椅子上睡着了。那一刻突然觉得，家不是房子，是这些东西被搬来搬去的痕迹。',120,['#3a2c4a','#6a5590','#c9a8e8'],'memory');
  add('harbor','和你们的那顿火锅','四个人，两口锅，聊到店打烊。有人说"以后每年都要这样"，我们都知道可能做不到，但还是点头了。',9,['#7a2f2f','#d96a3a','#ffcf8a'],'memory');
  add('harbor','爸爸的第一条语音','他学会了用语音。第一条是 47 秒，前面 30 秒在测试"喂喂喂，听得到吗"。',45,null,'memory');
  // 目标 → 岛上长出一棵成长树（只增不减）
  add('knowledge','读完《设计数据密集型应用》','第 12 章讲分布式一致性，来回读了三遍。第一次觉得"正确性"也是一个可以被设计出来的东西。',28,null,'goal');
  add('future','2027 年，我想做一个自己的产品','不是为了融资，不是为了榜单。只是想让某个人在某个深夜用到它的时候，觉得"啊，有人懂我"。',3,['#241a52','#5a45b8','#b79cff'],'goal');
  add('future','学会自由潜水','想在没有声音的地方待一会儿。目标：一口气下潜 20 米。',60,null,'goal');
  // 旅行 → 解锁一处新风景
  add('memory','大理的雨季','雨下了一整个下午，客栈的屋檐在滴水。哪也没去，就坐着看雨，居然一点都不着急。',90,['#4a6a8a','#7aa8c9','#cfe8f5'],'travel');
  add('creation','海边写生','画到一半潮水涨上来，颜料盒差点被冲走。最后画面上全是风。',40,['#2a6a8a','#5fa8c9','#ffd9a0'],'travel');
  add('future','一个人去看一次极光','查了三年航班，终于订下去特罗姆瑟的票。',150,['#123a4a','#2a7a8a','#9fe8d0'],'travel');
  // 音乐 → 音符与韵律
  add('creation','凌晨三点的合成器','用四个锯齿波做了个很低的和弦，加上一点点失谐，房间就变成了另一个地方。',15,['#3a1a4a','#a03a8a','#ff9ad5'],'music');
  // 回顾 → 重新点亮往事的那颗星
  const rcl=add('knowledge','回头看那三天','比赛结束半年了。现在再看，那些崩溃和重来都变得很轻——原来最难的不是写不出来，是不肯停。',1,null,'recall');
  rcl.target=marathon.id; marathon.litAt=now-2000;
  saveState();
}

/* ---------------- 8. 相机与输入 ---------------- */
const cvs=document.getElementById('world'), ctx=cvs.getContext('2d');
let VW=0,VH=0,DPR=1,fitZoom=0.4,minZoom=0.4,maxZoom=3.4;
const cam={x:ISL.harbor.x,y:ISL.harbor.y,zoom:1,tx:ISL.harbor.x,ty:ISL.harbor.y,tz:1,mvx:0,mvy:0};
let wantFit=false;
function worldCenter(){ return [WOX+WW/2, WOY+WH/2]; }
/* 世界尺寸变化后重算缩放范围（不碰画布大小） */
function recalcFit(){
  fitZoom=Math.min(VW/(WW*PX), VH/(WH*PX));
  minZoom=fitZoom*0.58; maxZoom=3.2;      // 可以再拉远一点，沉进夜海里（外海是无缝的，不会露边）
  cam.tz=clamp(cam.tz,minZoom,maxZoom);
  cam.zoom=clamp(cam.zoom,minZoom,maxZoom);
  clampCam(); syncMiniSize();
}
function resize(){
  const r=cvs.getBoundingClientRect();
  VW=r.width;VH=r.height;
  DPR=pickDPR();                          // 账号版：按可用像素总量给 devicePixelRatio 设上限
  cvs.width=Math.round(VW*DPR);cvs.height=Math.round(VH*DPR);
  ctx.imageSmoothingEnabled=false;
  recalcFit();
  if(wantFit){ const wc=worldCenter(); cam.zoom=cam.tz=fitZoom; cam.x=cam.tx=wc[0]; cam.y=cam.ty=wc[1]; }
  clampCam();
  syncMiniSize();
}
/* 把坐标夹在「不会把世界推出视野」的范围里 */
function clampXY(x,y,z){
  const hw=VW/(2*PX*z), hh=VH/(2*PX*z), pad=18;
  const minX=WOX-pad+Math.min(hw,WW/2), maxX=WOX+WW+pad-Math.min(hw,WW/2);
  const minY=WOY-pad+Math.min(hh,WH/2), maxY=WOY+WH+pad-Math.min(hh,WH/2);
  return [clamp(x,Math.min(minX,maxX),Math.max(minX,maxX)),
          clamp(y,Math.min(minY,maxY),Math.max(minY,maxY))];
}
function clampCam(){
  const p=clampXY(cam.x,cam.y,cam.zoom); cam.x=p[0]; cam.y=p[1];
  const q=clampXY(cam.tx,cam.ty,cam.tz); cam.tx=q[0]; cam.ty=q[1];
}
const S=()=>PX*cam.zoom;
const w2s=(x,y)=>[(x-cam.x)*S()+VW/2,(y-cam.y)*S()+VH/2];
const s2w=(sx,sy)=>[(sx-VW/2)/S()+cam.x,(sy-VH/2)/S()+cam.y];

const ptrs=new Map();
let dragging=false, moved=0, downAt=0, pinchD=0, pinchMid=null, camFollow=false;
let hoverId=null, lastVX=0, lastVY=0, lastMoveT=0;
function setTarget(x,y,z,anim){
  cam.tx=x;cam.ty=y;cam.tz=clamp(z,minZoom,maxZoom);
  cam.mvx=0;cam.mvy=0;
  if(!anim){cam.x=x;cam.y=y;cam.zoom=cam.tz;}
  camFollow=true; clampCam();
}
/* 平滑变焦：只改目标，由渲染循环缓动过去 —— 滚轮/按钮不再一跳一跳 */
function zoomTo(sx,sy,dz){
  const nz=clamp(cam.tz+dz,minZoom,maxZoom);
  const wx=(sx-VW/2)/(PX*cam.tz)+cam.tx, wy=(sy-VH/2)/(PX*cam.tz)+cam.ty;
  cam.tz=nz;
  cam.tx=wx-(sx-VW/2)/(PX*nz);
  cam.ty=wy-(sy-VH/2)/(PX*nz);
  camFollow=true; clampCam();
}
cvs.addEventListener('pointerdown',e=>{
  cvs.setPointerCapture(e.pointerId);
  ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(ptrs.size===1){
    dragging=true;moved=0;downAt=performance.now();camFollow=false;
    cam.mvx=0;cam.mvy=0;lastVX=0;lastVY=0;lastMoveT=downAt;
    if(gameMode)beginJoystick(e);
  }
  if(ptrs.size===2){
    resetJoystick();
    const [a,b]=[...ptrs.values()];
    pinchD=Math.hypot(a.x-b.x,a.y-b.y);
    pinchMid={x:(a.x+b.x)/2,y:(a.y+b.y)/2};
  }
});
cvs.addEventListener('pointermove',e=>{
  const p=ptrs.get(e.pointerId);
  if(!p){                                   // 悬停反馈（鼠标）
    if(e.pointerType==='mouse'){
      const id=islandAtScreen(e.clientX,e.clientY);
      if(id!==hoverId){ hoverId=id; cvs.style.cursor=id?'pointer':'grab'; }
    }
    return;
  }
  const dx=e.clientX-p.x, dy=e.clientY-p.y;
  p.x=e.clientX;p.y=e.clientY;
  if(gameMode){
    if(joystickPointer===e.pointerId)updateJoystick(e);
    moved+=Math.abs(dx)+Math.abs(dy);
  }
  else if(ptrs.size===1&&dragging){
    moved+=Math.abs(dx)+Math.abs(dy);
    cam.x-=dx/S(); cam.y-=dy/S(); cam.tx=cam.x;cam.ty=cam.y;clampCam();
    const now=performance.now(), dtm=Math.max(1,now-lastMoveT);
    lastVX=lerp(lastVX,dx/dtm*1000,0.5); lastVY=lerp(lastVY,dy/dtm*1000,0.5);
    lastMoveT=now;
  }else if(ptrs.size===2){
    const [a,b]=[...ptrs.values()];
    const d=Math.hypot(a.x-b.x,a.y-b.y);
    const mid={x:(a.x+b.x)/2,y:(a.y+b.y)/2};
    if(pinchD>4){
      const nz=clamp(cam.zoom*(d/pinchD),minZoom,maxZoom);
      zoomAt(mid.x,mid.y,nz-cam.zoom);
    }
    cam.x-=(mid.x-pinchMid.x)/S(); cam.y-=(mid.y-pinchMid.y)/S();
    cam.tx=cam.x;cam.ty=cam.y;
    pinchD=d;pinchMid=mid;clampCam();
  }
});
function endPtr(e){
  const isJoystickPointer=joystickPointer===e.pointerId;
  const joystickWasUsed=isJoystickPointer&&joystickMoved;
  if(isJoystickPointer)resetJoystick();
  ptrs.delete(e.pointerId);
  if(ptrs.size<2){pinchD=0;pinchMid=null;}
  if(ptrs.size===0){
    if(dragging){
      const quickTap=moved<8&&performance.now()-downAt<600&&e.type!=='pointercancel';
      if(gameMode){
        if(quickTap&&!joystickWasUsed)handleTap(e.clientX,e.clientY);
      }else if(quickTap){
        handleTap(e.clientX,e.clientY);
      }else if(moved>=8&&Math.hypot(lastVX,lastVY)>110){   // 松手后继续滑一段
        cam.mvx=-lastVX*0.9; cam.mvy=-lastVY*0.9;
      }
    }
    dragging=false; lastVX=0; lastVY=0;
  }
}
cvs.addEventListener('pointerup',endPtr);
cvs.addEventListener('pointercancel',endPtr);
cvs.addEventListener('pointerleave',()=>{ if(!dragging){hoverId=null;} });
cvs.addEventListener('wheel',e=>{
  e.preventDefault();
  if(gameMode){gameZoom=clamp(gameZoom*Math.exp(-e.deltaY*0.0015),0.65,1.8);return;}
  const rect=cvs.getBoundingClientRect();
  const f=Math.exp(-e.deltaY*(e.ctrlKey?0.010:0.0017));
  zoomTo(e.clientX-rect.left,e.clientY-rect.top,cam.tz*(f-1));
},{passive:false});
cvs.addEventListener('dblclick',e=>{
  const rect=cvs.getBoundingClientRect();
  const id=islandAtScreen(e.clientX,e.clientY);
  if(id) focusIsland(ISL[id],true);
  else zoomTo(e.clientX-rect.left,e.clientY-rect.top,cam.tz*0.42);
});
function zoomAt(sx,sy,dz){
  const [wx,wy]=s2w(sx,sy);
  cam.zoom=clamp(cam.zoom+dz,minZoom,maxZoom);
  cam.x=wx-(sx-VW/2)/S(); cam.y=wy-(sy-VH/2)/S();
  cam.tx=cam.x;cam.ty=cam.y;cam.tz=cam.zoom;clampCam();
}
/* 屏幕坐标 → 命中哪座岛 */
function islandAtScreen(cx,cy){
  const rect=cvs.getBoundingClientRect();
  const [wx,wy]=s2w(cx-rect.left,cy-rect.top);
  let best=null,bd=1e9;
  for(const i of ISLANDS){
    const d=Math.hypot(wx-i.x,wy-i.y);
    const hitR=Math.max(i.r*1.18, 48/S());
    if(d<hitR&&d<bd){bd=d;best=i;}
  }
  return best?best.id:null;
}
/* 世界地图上"道路旁的大地标"也能点：点它 = 打开这座岛的记忆 */
function worldLandmarkAt(wx,wy){
  let best=null,bd=1e9;
  for(const p of PROPS){
    if(!p.landmark) continue;
    const spr=SPR[p.spr]; if(!spr) continue;
    const w=spr.cv.width*p.sc, h=spr.cv.height*p.sc;
    const x0=p.x-w*spr.ax, y0=p.y-h*spr.ay;
    if(wx<x0-4||wx>x0+w+4||wy<y0-4||wy>p.y+5) continue;
    const d=Math.hypot(wx-p.x,wy-p.y);
    if(d<bd){bd=d;best=p;}
  }
  if(!best) return null;
  for(const i of ISLANDS) if(Math.hypot(best.x-i.x,best.y-i.y)<i.r+14) return i.id;
  return null;
}
/* 主世界里的记录标记可直接点击；音乐音符优先进入播放。 */
function worldEntryMarkerAt(wx,wy){
  let best=null,bd=1e9;
  for(const p of PROPS){
    if(!p.entryId&&!p.openRegion) continue;
    const hit=(p.openRegion?34:p.kind==='music'?30:24)*(p.sc||1);
    const d=Math.hypot(wx-p.x,wy-p.y);
    if(d<hit&&d<bd){bd=d;best=p;}
  }
  return best;
}
function handleTap(cx,cy){
  if(gameMode){handleAdventureTap(cx,cy);return;}
  const rect=cvs.getBoundingClientRect();
  const [wx,wy]=s2w(cx-rect.left,cy-rect.top);
  const mark=worldEntryMarkerAt(wx,wy);
  if(mark){
    if(mark.openRegion&&mark.islandId){ openRegion(mark.islandId); return; }
    const found=findEntry(mark.entryId);
    if(found){
      if((found.entry.kind||'memory')==='music') Music.play(found.entry);
      else openDetail(found.island.id,mark.entryId);
      return;
    }
  }
  const lk=worldLandmarkAt(wx,wy);
  if(lk){ openRegion(lk); return; }
  const id=islandAtScreen(cx,cy);
  if(id) openRegion(id);
}

/* ---------------- 9. 渲染 ---------------- */
let stars=[],shimmers=[],motes=[],clouds=[],birds=[],gulls=[],meteors=[],butterflies=[],fish=[],notes=[],dolphins=[];
function buildFXLayers(){
  const R=mulberry32(2026);
  const M=520;                                  // 向世界之外多铺一圈，缩小视野时画面不会「断掉」
  const X0=WOX-M, Y0=WOY-M, RW=WW+M*2, RH=WH+M*2;
  const nStar=Math.min(1300,Math.round(RW*RH/900));
  stars=[];shimmers=[];
  for(let k=0;k<nStar;k++){
    const x=X0+R()*RW, y=Y0+R()*RH;
    const rr=terrAt(x,y);
    if(rr.t!=='deep'||rr.n<2.6) continue;       // 只落在真正露出来的深海（被地形盖住的地方不放）
    stars.push({x,y,r:R()<0.14?1.4:0.8,a:0.25+R()*0.6,ph:R()*6.28,sp:0.5+R()*1.4});
  }
  for(let k=0;k<520;k++){
    const x=X0+R()*RW, y=Y0+R()*RH;
    const t=terrAt(x,y).t;
    if(t!=='shallow'&&t!=='deep') continue;
    shimmers.push({x,y,ph:R()*6.28,sp:0.6+R()*1.2,ln:2+R()*7});
  }
  motes=[];
  for(let k=0;k<160;k++){
    motes.push({x:X0+R()*RW,y:Y0+R()*RH,ph:R()*6.28,sp:2+R()*4,amp:1.5+R()*3,r:0.7+R()*0.9,c:R()});
  }
  clouds=[];
  for(let k=0;k<28;k++){
    clouds.push({x:X0+R()*RW,y:Y0+R()*RH,r:34+R()*54,a:0.026+R()*0.038,sp:0.35+R()*0.7,c:R()});
  }
  /* 飞鸟群：成队在海面上空盘旋/迁徙，程序化「八」字振翅 */
  birds=[];
  const nFlock=7;
  for(let f=0;f<nFlock;f++){
    const n=4+((R()*5)|0);              // 每队 4~8 只
    const baseX=X0+R()*RW, baseY=Y0+R()*RH*0.55;
    const dir=R()<0.5?1:-1;             // 迁徙方向
    const sp=18+R()*26;                 // 飞行速度（世界单位/秒）
    const amp=90+R()*140;               // 盘旋幅度
    const ph=R()*6.28;
    for(let b=0;b<n;b++){
      birds.push({baseX,baseY,dir,sp,amp,ph,idx:b,gap:34+R()*16,wing:R()*6.28,wingSp:7+R()*4});
    }
  }
  /* 海鸥：在海面/港湾上空盘旋，白色大鸟，比飞鸟醒目 */
  gulls=[];
  const nGull=5;
  for(let f=0;f<nGull;f++){
    const n=2+((R()*3)|0);              // 每群 2~4 只
    const cx=X0+R()*RW, cy=Y0+R()*RH*0.42;
    const orbit=R()*90+60;              // 盘旋半径
    const sp=R()*0.5+0.3;               // 角速度
    const ph=R()*6.28;
    for(let b=0;b<n;b++){
      gulls.push({cx,cy,orbit,sp,ph,idx:b,wing:R()*6.28,wingSp:5+R()*3});
    }
  }
  /* 流星：周期性从夜空划过，带拖尾 */
  meteors=[];
  for(let k=0;k<5;k++){
    meteors.push({x:X0+R()*RW,y:Y0+R()*RH*0.35,vx:-(120+R()*160),vy:40+R()*70,life:0,max:2.2+R()*1.6,delay:R()*9});
  }
  /* 蝴蝶：在岛屿草地/花丛上空翩翩飞舞，彩色 */
  butterflies=[];
  for(let k=0;k<36;k++){
    const isl=k<6&&(ISL.music||ISLANDS.find(x=>x.id==='music'))?(ISL.music||ISLANDS.find(x=>x.id==='music')):(ISLANDS[(R()*ISLANDS.length)|0]||ISLANDS[0]);
    const ang=R()*6.28, rr2=isl.r*(0.3+R()*0.5);
    butterflies.push({
      ix:isl.x+Math.cos(ang)*rr2, iy:isl.y+Math.sin(ang)*rr2,
      ph:R()*6.28, amp:10+R()*22, sp:0.5+R()*0.8,
      hue:R()*360, size:2+R()*2.4
    });
  }
  /* 跃水的鱼：偶尔从海面跃起，带一圈水花 */
  fish=[];
  for(let k=0;k<18;k++){
    fish.push({x:X0+R()*RW, y:Y0+R()*RH, ph:R()*6.28, period:5+R()*9, size:2+R()*2.5, dir:R()<0.5?1:-1});
  }
  /* 漂浮魔幻音符：在世界各处缓缓飘浮、若隐若现，营造音乐氛围 */
  notes=[];
  const noteGlyphs=['♪','♫','♩','♬'];
  for(let k=0;k<8;k++){
    const isl=ISLANDS[(R()*ISLANDS.length)|0]||ISLANDS[0];
    const ang=R()*6.28, rr2=isl.r*(k<6?(0.55+R()*0.85):(0.5+R()*1.3));
    notes.push({
      x:isl.x+Math.cos(ang)*rr2, y:isl.y+Math.sin(ang)*rr2,
      ph:R()*6.28, amp:6+R()*16, sp:0.4+R()*0.6,
      glyph:noteGlyphs[(R()*noteGlyphs.length)|0],
      hue:R()<0.5?270:320,           // 紫色/品红系，呼应魔法氛围
      size:8+R()*8
    });
  }
  /* 海豚：在世界之外的虚空深海里跃出水面，弧线跳跃 + 水花 */
  dolphins=[];
  for(let k=0;k<8;k++){
    dolphins.push({
      x:X0+R()*RW, y:Y0+R()*RH, ph:R()*6.28, period:7+R()*11,
      size:5+R()*5, dir:R()<0.5?1:-1, hue:R()<0.5?195:210
    });
  }
}
let T=0, pauseRender=false;
/* ===== 自适应画质（合并自账号版）：按刷新率隔帧绘制 + 按实测绘制耗时自动升降画质 ===== */
const IS_TOUCH=(('ontouchstart' in window)||navigator.maxTouchPoints>0);
const QLEVEL=[
  {maxPx:1.35e6, dprCap:1.15},
  {maxPx:2.30e6, dprCap:1.50},
  {maxPx:3.30e6, dprCap:2.00}
];
const Q={level:IS_TOUCH?1:2};
Object.assign(Q,QLEVEL[Q.level]);
const DPR_FLOOR=[0.75,0.9,1.0];
function pickDPR(){
  const raw=window.devicePixelRatio||1;
  const byArea=Math.sqrt(Q.maxPx/Math.max(1,VW*VH));
  return Math.max(DPR_FLOOR[Q.level],Math.min(raw,Q.dprCap,byArea));
}
let resizePending=false;
function scheduleResize(){
  if(resizePending) return; resizePending=true;
  requestAnimationFrame(()=>{ resizePending=false; resize(); });
}
function setQuality(lv,apply){
  lv=Math.round(clamp(lv,0,2));
  if(lv===Q.level) return;
  Q.level=lv; Object.assign(Q,QLEVEL[lv]);
  if(apply&&typeof resize==='function') resize();
}
/* 探测刷新率 → 决定隔几帧画一次（120Hz 只画 1/2~1/3） */
let hzDone=false, hzSamples=[], frameCount=0, frameSkip=1;
function noteRefresh(now){
  if(hzDone) return;
  hzSamples.push(now-(noteRefresh._t||now)); noteRefresh._t=now;
  if(hzSamples.length>=50){
    const s=hzSamples.slice(5).sort((a,b)=>a-b);
    const hz=1000/(s[(s.length*0.12)|0]||16.7);
    frameSkip = hz>95 ? (IS_TOUCH?3:2) : (hz>75 ? 2 : 1);
    hzDone=true;
  }
}
/* 绘制耗时 EMA 驱动画质调节：真画不动才降，稳定很久才升 */
let paintEMA=9, adaptAt=0, downgrades=0, paintFrames=0;
function adaptQuality(now,cost){
  paintEMA=paintEMA*0.86+cost*0.14;
  if(now<adaptAt) return;
  if(paintEMA>23&&Q.level>0){ setQuality(Q.level-1,true); adaptAt=now+5000; downgrades++; }
  else if(paintEMA<7.5&&Q.level<2&&downgrades>0){ setQuality(Q.level+1,true); adaptAt=now+9000; }
}
/* 渲染循环外面包一层：隔帧 + 耗时采样（内部逻辑一行没动） */
function draw(now){
  if(pauseRender) return;
  noteRefresh(now);
  if(frameSkip>1){ frameCount++; if((frameCount%frameSkip)!==0){ requestAnimationFrame(draw); return; } }
  paintFrames++;
  const _pc0=performance.now();
  drawCore(now);
  adaptQuality(now, performance.now()-_pc0);
}
function drawCore(now){
  if(pauseRender) return;
  const dt=Math.min(0.05,(now-(drawCore._t||now))/1000); drawCore._t=now;
  T+=dt*0.5;
  stepBursts(dt); stepFX(dt);
  if(gameMode){drawAdventureFrame(dt);requestAnimationFrame(draw);return;}
  // 松手后的惯性滑动（拖拽不再「一松就死」）
  if(Math.abs(cam.mvx)>6||Math.abs(cam.mvy)>6){
    cam.x+=cam.mvx*dt/S(); cam.y+=cam.mvy*dt/S();
    cam.tx=cam.x; cam.ty=cam.y;
    const dec=Math.pow(0.05,dt); cam.mvx*=dec; cam.mvy*=dec;
    clampCam();
  }else if(cam.mvx||cam.mvy){ cam.mvx=0; cam.mvy=0; }
  // 相机缓动
  const k=1-Math.pow(0.0009,dt);
  cam.x=lerp(cam.x,cam.tx,k); cam.y=lerp(cam.y,cam.ty,k); cam.zoom=lerp(cam.zoom,cam.tz,k);
  clampCam();

  ctx.setTransform(DPR,0,0,DPR,0,0);
  ctx.imageSmoothingEnabled=false;
  if(atlasCv){
    ctx.fillStyle='#37543f';ctx.fillRect(0,0,VW,VH);
    const k=Math.min(VW/atlasCv.width,VH/atlasCv.height);
    ctx.drawImage(atlasCv,0,0,atlasCv.width*k,atlasCv.height*k);
    requestAnimationFrame(draw); return;
  }
  ctx.fillStyle='rgb(11,15,36)'; ctx.fillRect(0,0,VW,VH);
  const s=S();
  ctx.save();
  ctx.translate(VW/2,VH/2); ctx.scale(s,s); ctx.translate(-cam.x,-cam.y);

  const hw=VW/(2*s), hh=VH/(2*s);
  const vx0=cam.x-hw, vx1=cam.x+hw, vy0=cam.y-hh, vy1=cam.y+hh;

  // 深海：整屏用无缝平铺的深海贴图铺满（世界之外不再是另一块底色 → 没有边界）
  if(oceanPat){
    ctx.fillStyle=oceanPat;
    ctx.fillRect(vx0,vy0,vx1-vx0,vy1-vy0);
  }

  // 太空星尘（深水区）
  ctx.globalCompositeOperation='lighter';
  for(const st of stars){
    if(st.x<vx0-4||st.x>vx1+4||st.y<vy0-4||st.y>vy1+4) continue;
    const a=st.a*(0.45+0.55*Math.sin(T*st.sp+st.ph));
    ctx.fillStyle='rgba(190,205,255,'+(a*0.9).toFixed(3)+')';
    ctx.fillRect(st.x-st.r/2,st.y-st.r/2,st.r,st.r);
  }
  ctx.globalCompositeOperation='source-over';

  // 世界级柔光轨道：让整张地图像一座悬浮在深海里的完整世界。
  drawWorldOrbits();

  // 岛屿氛围光晕
  ctx.globalCompositeOperation='lighter';
  for(const i of ISLANDS){
    if(i.x+i.r<vx0-40||i.x-i.r>vx1+40||i.y+i.r<vy0-40||i.y-i.r>vy1+40) continue;
    const pulse=1+0.05*Math.sin(T*0.9+i.seed);
    const g_=ctx.createRadialGradient(i.x,i.y,i.r*0.6,i.x,i.y,i.r*1.9*pulse);
    g_.addColorStop(0,i.glow); g_.addColorStop(0.55,hexA(i.color,0.10)); g_.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=g_;
    ctx.beginPath();ctx.arc(i.x,i.y,i.r*1.9*pulse,0,6.2832);ctx.fill();
  }
  ctx.globalCompositeOperation='source-over';

  // 动态海岸泡沫：沿岛缘流动的细碎浪花，让岛屿「活」起来
  ctx.globalCompositeOperation='lighter';
  for(const i of ISLANDS){
    if(i.x+i.r<vx0-60||i.x-i.r>vx1+60||i.y+i.r<vy0-60||i.y-i.r>vy1+60) continue;
    const nfoam=Math.min(26,Math.max(10,Math.round(i.r*0.32)));
    for(let k=0;k<nfoam;k++){
      const ang=k/nfoam*6.2832 + i.seed*0.7;
      const rad=radiusAt(i,ang*57.29578)*(1.0+0.018*Math.sin(T*0.7+k*2.1+i.seed));
      const fx=i.x+Math.cos(ang)*rad, fy=i.y+Math.sin(ang)*rad;
      const tw=T*1.1+k*0.6+i.seed*3;
      const al=0.10+0.22*Math.abs(Math.sin(tw));
      if(al<=0.01) continue;
      ctx.fillStyle='rgba(200,235,255,'+al.toFixed(3)+')';
      ctx.fillRect(fx-1.2,fy-0.5,2.4+Math.sin(tw)*1.2,1);
    }
  }
  // 岛屿涟漪：从岛心向外一圈圈扩散的水波
  ctx.lineWidth=1.1;
  for(const i of ISLANDS){
    if(i.x+i.r<vx0-80||i.x-i.r>vx1+80||i.y+i.r<vy0-80||i.y-i.r>vy1+80) continue;
    const nr=Math.min(3,1+Math.round(i.r*0.05));
    for(let k=0;k<nr;k++){
      const pr=((T*0.22 + k/nr + i.seed*0.13)%1);
      ctx.beginPath();
      ctx.arc(i.x,i.y,i.r*(1.15+pr*0.9),0,6.2832);
      ctx.strokeStyle=hexA(i.color,(1-pr)*0.22);
      ctx.stroke();
    }
  }
  ctx.globalCompositeOperation='source-over';

  // 动态瀑布：部分岛屿边缘倾泻而下的水流（按 seed 决定角度），底部带水花
  for(const i of ISLANDS){
    if(i.x+i.r<vx0-80||i.x-i.r>vx1+80||i.y+i.r<vy0-80||i.y-i.r>vy1+80) continue;
    const hasFall=(i.seed*7)%1<0.5 || (i.custom&&i.r<30);
    if(!hasFall) continue;
    const fang=i.seed*6.28;                              // 瀑布所在角度
    const topR=i.r*0.62;                                 // 瀑顶（岛内高地）
    const topX=i.x+Math.cos(fang)*topR, topY=i.y+Math.sin(fang)*topR;
    const edgeR=radiusAt(i,fang*57.29578);               // 岛缘
    const botX=i.x+Math.cos(fang)*edgeR, botY=i.y+Math.sin(fang)*edgeR;
    const flow=Math.sin(T*2.2+i.seed*5);                 // 水流脉动
    ctx.globalCompositeOperation='lighter';
    for(let s=0;s<5;s++){
      const tt=s/5;
      const px=topX+(botX-topX)*tt, py=topY+(botY-topY)*tt;
      const wob=Math.sin(T*3+tt*8+i.seed)*1.6;
      const al=0.28+0.20*Math.sin(T*2.2+s+i.seed*4);
      ctx.fillStyle='rgba(150,210,255,'+Math.max(0.08,al).toFixed(3)+')';
      ctx.fillRect(px-2+wob,py-3+flow*2,4,7);
    }
    const sp=Math.sin(T*4+i.seed*9);
    for(let s=0;s<6;s++){
      const sx2=botX+(s-2.5)*3.2;
      const sy2=botY+2+Math.abs(Math.sin(T*3+s+i.seed))*3;
      ctx.fillStyle='rgba(200,235,255,'+(0.35+0.25*Math.sin(T*3+s)).toFixed(3)+')';
      ctx.fillRect(sx2,sy2,1.6,1.6);
    }
    ctx.globalCompositeOperation='source-over';
  }

  // 海湾：部分岛屿海岸线凹陷，形成浅水湾（柔和光斑 + 细浪）
  for(const i of ISLANDS){
    if(i.x+i.r<vx0-80||i.x-i.r>vx1+80||i.y+i.r<vy0-80||i.y-i.r>vy1+80) continue;
    const hasBay=(i.seed*11)%1<0.55;
    if(!hasBay) continue;
    const bang=i.seed*3.7+1.5;                           // 海湾角度
    const bx2=i.x+Math.cos(bang)*i.r*0.9, by2=i.y+Math.sin(bang)*i.r*0.9;
    const g3=ctx.createRadialGradient(bx2,by2,2,bx2,by2,i.r*0.5);
    g3.addColorStop(0,'rgba(140,220,255,0.16)');
    g3.addColorStop(1,'rgba(140,220,255,0)');
    ctx.fillStyle=g3;
    ctx.beginPath();ctx.arc(bx2,by2,i.r*0.5,0,6.2832);ctx.fill();
    ctx.globalCompositeOperation='lighter';
    for(let s=0;s<4;s++){
      const pr=((T*0.3+s/4+i.seed)%1);
      const rw=i.r*(0.18+pr*0.3);
      ctx.beginPath();ctx.arc(bx2,by2,rw,0,6.2832);
      ctx.strokeStyle='rgba(170,225,255,'+((1-pr)*0.18).toFixed(3)+')';
      ctx.lineWidth=1;ctx.stroke();
    }
    ctx.globalCompositeOperation='source-over';
  }

  // 星河：横贯夜空的银河带（远景，随世界移动，营造更深的魔法夜空）
  {
    const gx0=vx0-200, gx1=vx1+200;
    const gyBase=vy0-160;
    const band=ctx.createLinearGradient(gx0,gyBase,gx1,gyBase+260);
    band.addColorStop(0,'rgba(120,140,220,0)');
    band.addColorStop(0.5,'rgba(170,190,255,0.14)');
    band.addColorStop(1,'rgba(120,140,220,0)');
    ctx.fillStyle=band;
    ctx.beginPath();
    ctx.moveTo(gx0,gyBase+220);
    ctx.lineTo(gx1,gyBase+60);
    ctx.lineTo(gx1,gyBase+200);
    ctx.lineTo(gx0,gyBase+320);
    ctx.closePath();
    ctx.fill();
    ctx.globalCompositeOperation='lighter';
    for(let k=0;k<60;k++){
      const t=k/60;
      const gxx=gx0+(gx1-gx0)*t;
      const gyy=gyBase+180 - Math.sin(t*3.14)*110;
      const tw2=T*0.5+k;
      const a2=0.10+0.22*Math.abs(Math.sin(tw2));
      if(a2<=0.01) continue;
      ctx.fillStyle='rgba(220,230,255,'+a2.toFixed(3)+')';
      ctx.fillRect(gxx,gyy,(k%3)?1:1.6,(k%3)?1:1.6);
    }
    ctx.globalCompositeOperation='source-over';
  }

  // 地形
  let sx=Math.max(0,Math.floor(vx0-2-WOX)), sy=Math.max(0,Math.floor(vy0-2-WOY));
  let ex=Math.min(WW,Math.ceil(vx1+2-WOX)), ey=Math.min(WH,Math.ceil(vy1+2-WOY));
  if(ex>sx&&ey>sy){
    const dxp=sx+WOX, dyp=sy+WOY;
    ctx.drawImage(terrainCv,sx,sy,ex-sx,ey-sy,dxp,dyp,ex-sx,ey-sy);
    ctx.drawImage(bridgeCv,sx,sy,ex-sx,ey-sy,dxp,dyp,ex-sx,ey-sy);
  }
  // 水面微光
  ctx.globalCompositeOperation='lighter';
  for(const sp of shimmers){
    if(sp.x<vx0-8||sp.x>vx1+8||sp.y<vy0-8||sp.y>vy1+8) continue;
    const a=0.10+0.16*Math.sin(T*sp.sp+sp.ph);
    if(a<=0) continue;
    ctx.fillStyle='rgba(160,200,255,'+a.toFixed(3)+')';
    ctx.fillRect(sp.x,sp.y,sp.ln*(0.6+0.4*Math.sin(T+sp.ph)),1);
  }
  ctx.globalCompositeOperation='source-over';

  // 物件（按 y 排序绘制）
  const uiOpen=document.getElementById('regionSheet').classList.contains('open');
  for(const p of PROPS){
    let px,py,cv,sc;
    /* 爱乐之城的聚合入口：不让每首音乐都挤成一枚漂浮音符。 */
    if(p.mark==='melody'){
      const [scx,scy]=w2s(p.x,p.y);
      if(scx<-50||scx>VW+50||scy<-70||scy>VH+50) continue;
      const pulse=1+0.08*Math.sin(T*1.6+p.phase);
      const rr=15*pulse;
      px=p.x+Math.sin(T*0.8+p.phase)*1.2; py=p.y-13+Math.sin(T*1.5+p.phase)*2.2;
      ctx.globalCompositeOperation='lighter';
      const mg=ctx.createRadialGradient(px,py,1,px,py,rr*2.1);
      mg.addColorStop(0,hexA(p.color,.36)); mg.addColorStop(.38,hexA(p.color,.16)); mg.addColorStop(1,hexA(p.color,0));
      ctx.fillStyle=mg; ctx.beginPath(); ctx.arc(px,py,rr*2.1,0,6.2832); ctx.fill();
      ctx.globalCompositeOperation='source-over';
      roundRect(ctx,px-rr,py-rr,rr*2,rr*2,rr*.42);
      ctx.fillStyle='rgba(18,15,34,.88)'; ctx.fill();
      ctx.strokeStyle=hexA(p.color,.85); ctx.lineWidth=1.25; ctx.stroke();
      ctx.textAlign='center'; ctx.textBaseline='middle';
      ctx.font='700 18px Georgia,serif'; ctx.fillStyle='#fff4c7';
      ctx.fillText('♫',px,py-2);
      ctx.font='700 8px -apple-system,"PingFang SC",sans-serif'; ctx.fillStyle=hexA(p.color,.98);
      ctx.fillText((p.count||0)+' 首',px,py+12);
      continue;
    }
    /* 悬浮类标记：星星（记忆）/ 音符（音乐） */
    if(p.mark==='star'||p.mark==='note'){
      const isNote=p.mark==='note';
      const [scx,scy]=w2s(p.x,p.y);
      if(scx<-40||scx>VW+40||scy<-60||scy>VH+40) continue;
      cv=isNote?noteSprite(p.color):starSprite(p.color);
      const gt=growT(p);
      sc=p.sc*gt;
      const fa=Math.sin(T*(isNote?1.9:1.35)+p.phase)*(isNote?2.8:1.7);
      const drift=Math.sin(T*0.8+p.phase)*1.3;
      px=p.x+drift; py=p.y+fa-(isNote?11:8);
      const w=cv.width*sc, h=cv.height*sc;
      // 光晕
      ctx.globalCompositeOperation='lighter';
      const gr=8*gt+1.6;
      const gg=ctx.createRadialGradient(px,py,1,px,py,gr);
      gg.addColorStop(0,'rgba(255,255,255,'+((isNote?0.20:(p.lit?0.46:0.24))*gt).toFixed(3)+')');
      gg.addColorStop(1,'rgba(255,255,255,0)');
      ctx.fillStyle=gg;ctx.beginPath();ctx.arc(px,py,gr,0,6.2832);ctx.fill();
      ctx.globalCompositeOperation='source-over';
      ctx.drawImage(cv,px-w/2,py-h/2,w,h);
      // 回顾 → 重新点亮：扩散光环
      if(p.lit){
        const pr=(T*0.5+p.phase)%1;
        ctx.beginPath();ctx.arc(px,py,3.5+pr*9,0,6.2832);
        ctx.strokeStyle='rgba(255,246,214,'+((1-pr)*0.7).toFixed(3)+')';ctx.lineWidth=1.1;ctx.stroke();
      }
      continue;
    }
    const spr=SPR[p.spr]; if(!spr) continue;
    cv=spr.cv; sc=p.sc*growT(p);
    const w=cv.width*sc, h=cv.height*sc;
    px=p.x-w*spr.ax; py=p.y-h*spr.ay;
    if(px+w<vx0-8||px>vx1+8||py+h<vy0-8||py>vy1+8) continue;
    // 道路旁的大地标：一圈岛屿色的柔光，让它一眼就能认出来
    if(p.landmark&&p.glow){
      ctx.globalCompositeOperation='lighter';
      const gg=ctx.createRadialGradient(p.x,p.y-h*0.42,1,p.x,p.y-h*0.42,w*0.92);
      gg.addColorStop(0,hexA(p.glow,0.20)); gg.addColorStop(1,hexA(p.glow,0));
      ctx.fillStyle=gg; ctx.beginPath(); ctx.arc(p.x,p.y-h*0.42,w*0.92,0,6.2832); ctx.fill();
      ctx.globalCompositeOperation='source-over';
    }
    // 投影
    ctx.fillStyle='rgba(6,8,20,0.26)';
    ctx.beginPath();
    ctx.ellipse(p.x, p.y-0.5, w*0.36, Math.max(1,w*0.13), 0,0,6.2832);
    ctx.fill();
    // 成长树 / 新风景：长出来时带一点金色光晕
    if(p.mark){
      const gt=growT(p);
      if(gt<1){
        ctx.globalCompositeOperation='lighter';
        const gg=ctx.createRadialGradient(p.x,p.y-h*0.4,1,p.x,p.y-h*0.4,w*0.9);
        gg.addColorStop(0,'rgba(255,240,190,'+(0.30*(1-gt)).toFixed(3)+')');
        gg.addColorStop(1,'rgba(255,240,190,0)');
        ctx.fillStyle=gg;ctx.beginPath();ctx.arc(p.x,p.y-h*0.4,w*0.9,0,6.2832);ctx.fill();
        ctx.globalCompositeOperation='source-over';
      }
    }
    if(p.flip){
      ctx.save();ctx.translate(p.x,0);ctx.scale(-1,1);ctx.drawImage(cv,-w/2,py-p.y,w,h);ctx.restore();
    }else{
      ctx.drawImage(cv,px,py,w,h);
    }
  }
  // 雾气
  ctx.globalCompositeOperation='lighter';
  for(const c of clouds){
    const cx2=c.x+Math.sin(T*0.16+c.c*6)*c.sp*3, cy2=c.y+Math.cos(T*0.2+c.c*5)*1.5;
    if(cx2+c.r<vx0||cx2-c.r>vx1||cy2+c.r<vy0||cy2-c.r>vy1) continue;
    const gg=ctx.createRadialGradient(cx2,cy2,0,cx2,cy2,c.r);
    const cc=c.c>0.55?[150,140,230]:[110,190,220];
    gg.addColorStop(0,'rgba('+cc[0]+','+cc[1]+','+cc[2]+','+c.a.toFixed(3)+')');
    gg.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=gg;ctx.beginPath();ctx.arc(cx2,cy2,c.r,0,6.2832);ctx.fill();
  }
  // 萤火 / 光尘
  for(const m of motes){
    const mx=m.x+Math.sin(T*0.5+m.ph)*m.amp, my=m.y+Math.cos(T*0.42+m.ph*1.3)*m.amp*0.8;
    if(mx<vx0||mx>vx1||my<vy0||my>vy1) continue;
    const a=0.18+0.42*Math.abs(Math.sin(T*m.sp*0.32+m.ph));
    const col=m.c>0.5?'190,255,225':'255,225,170';
    ctx.fillStyle='rgba('+col+','+a.toFixed(3)+')';
    ctx.fillRect(mx,my,m.r,m.r);
  }
  ctx.globalCompositeOperation='source-over';

  // 飞鸟群：程序化「八」字振翅，成队盘旋/迁徙
  ctx.lineCap='round';
  ctx.lineWidth=1.4;
  ctx.fillStyle='rgba(24,28,44,0.9)';
  ctx.strokeStyle='rgba(24,28,44,0.9)';
  for(const b of birds){
    const lead=Math.sin(T*0.6+b.ph)*0.5;
    const bx=b.baseX+Math.sin(T*0.5+b.ph+lead)*b.amp;
    const by=b.baseY+Math.cos(T*0.34+b.ph)*b.amp*0.55+Math.sin(T*0.9+b.ph)*18;
    const bx2=bx - b.gap*b.idx*b.dir;
    const by2=by - b.gap*b.idx*0.18 + Math.sin(T*0.5+b.ph+b.idx)*6;
    if(bx2<vx0-30||bx2>vx1+30||by2<vy0-30||by2>vy1+30) continue;
    const flap=Math.sin(T*b.wingSp+b.wing);
    const ws=6*(0.4+0.6*Math.abs(flap));
    ctx.beginPath();
    ctx.moveTo(bx2-1.5,by2+0.5);
    ctx.quadraticCurveTo(bx2-3-ws*0.9,by2+2-flap*3.5,bx2-2-ws,by2+3-flap*4);
    ctx.moveTo(bx2+1.5,by2+0.5);
    ctx.quadraticCurveTo(bx2+3+ws*0.9,by2+2-flap*3.5,bx2+2+ws,by2+3-flap*4);
    ctx.stroke();
    ctx.fillRect(bx2-1.5,by2-0.5,3,1.6);
  }

  // 海鸥：白色大鸟，在海面/港湾上空盘旋，双翼舒展
  ctx.lineCap='round';
  for(const gl of gulls){
    const ang=T*gl.sp+gl.ph + gl.idx*0.5;
    const gx=gl.cx+Math.cos(ang)*gl.orbit;
    const gy=gl.cy+Math.sin(ang)*gl.orbit*0.4 + Math.sin(T*0.8+gl.ph)*6;
    if(gx<vx0-40||gx>vx1+40||gy<vy0-40||gy>vy1+40) continue;
    const flap=Math.sin(T*gl.wingSp+gl.wing);
    const ws=9*(0.5+0.5*Math.abs(flap));
    ctx.lineWidth=1.8;
    ctx.strokeStyle='rgba(240,246,255,0.92)';
    ctx.beginPath();
    ctx.moveTo(gx,gy);
    ctx.quadraticCurveTo(gx-4-ws*0.7,gy-1-flap*4,gx-ws-3,gy-flap*5);
    ctx.moveTo(gx,gy);
    ctx.quadraticCurveTo(gx+4+ws*0.7,gy-1-flap*4,gx+ws+3,gy-flap*5);
    ctx.stroke();
    ctx.fillStyle='rgba(245,250,255,0.95)';
    ctx.beginPath();ctx.arc(gx,gy,1.8,0,6.2832);ctx.fill();
  }

  // 蝴蝶：在岛屿上空翩翩飞舞，彩色双翅
  for(const bf of butterflies){
    const bx2=bf.ix+Math.sin(T*bf.sp+bf.ph)*bf.amp;
    const by2=bf.iy+Math.cos(T*bf.sp*0.8+bf.ph*1.3)*bf.amp*0.7;
    if(bx2<vx0-20||bx2>vx1+20||by2<vy0-20||by2>vy1+20) continue;
    const flap=Math.sin(T*8+bf.ph);
    const ws=bf.size*(0.3+0.7*Math.abs(flap));
    const hue=bf.hue;
    ctx.globalAlpha=0.9;
    ctx.fillStyle='hsl('+hue+',80%,65%)';
    ctx.save();ctx.translate(bx2,by2);ctx.rotate(-0.3-flap*0.5);
    ctx.beginPath();ctx.ellipse(-ws*0.7,0,ws*0.9,ws*0.55,0,0,6.2832);ctx.fill();
    ctx.restore();
    ctx.save();ctx.translate(bx2,by2);ctx.rotate(0.3+flap*0.5);
    ctx.beginPath();ctx.ellipse(ws*0.7,0,ws*0.9,ws*0.55,0,0,6.2832);ctx.fill();
    ctx.restore();
    ctx.fillStyle='rgba(40,30,40,0.85)';
    ctx.fillRect(bx2-0.5,by2-1.5,1,3);
    ctx.globalAlpha=1;
  }

  // 跃水的鱼：偶尔从海面跃起，带一圈水花
  for(const f2 of fish){
    const cyc=((T*0.5+f2.ph)%f2.period)/f2.period;
    if(cyc>0.45) continue;
    const px=f2.x + Math.sin(T*0.3+f2.ph)*20;
    const h=Math.sin(cyc/0.45*3.1416)*26;
    const py=f2.y - h;
    if(px<vx0-20||px>vx1+20||py<vy0-20||py>vy1+20) continue;
    ctx.globalCompositeOperation='lighter';
    ctx.strokeStyle='rgba(120,200,255,'+(0.5*(1-cyc/0.45)).toFixed(3)+')';
    ctx.lineWidth=1.2;
    ctx.beginPath();ctx.arc(px,f2.y,3+cyc*8,0,6.2832);ctx.stroke();
    ctx.globalCompositeOperation='source-over';
    ctx.fillStyle='rgba(90,160,220,0.95)';
    ctx.beginPath();ctx.ellipse(px,py,f2.size,f2.size*0.5,0,0,6.2832);ctx.fill();
    ctx.fillStyle='rgba(230,245,255,0.9)';
    ctx.beginPath();ctx.moveTo(px+f2.size*f2.dir,py);ctx.lineTo(px+f2.size*f2.dir*1.8,py-2);ctx.lineTo(px+f2.size*f2.dir*1.8,py+2);ctx.closePath();ctx.fill();
  }

  // 漂浮魔幻音符：在世界各处缓缓飘浮、若隐若现
  ctx.textAlign='center';ctx.textBaseline='middle';
  for(const n of notes){
    const nx=n.x+Math.sin(T*n.sp+n.ph)*n.amp;
    const ny=n.y+Math.cos(T*n.sp*0.7+n.ph*1.2)*n.amp*0.8 + Math.sin(T*0.6+n.ph)*4;
    if(nx<vx0-30||nx>vx1+30||ny<vy0-30||ny>vy1+30) continue;
    const a=0.20+0.45*Math.abs(Math.sin(T*0.8+n.ph));
    ctx.globalCompositeOperation='lighter';
    ctx.fillStyle='hsla('+n.hue+',90%,78%,'+a.toFixed(3)+')';
    ctx.font='bold '+n.size+'px Georgia,serif';
    ctx.fillText(n.glyph,nx,ny);
    ctx.globalCompositeOperation='source-over';
  }

  // 海豚：在虚空深海里跃出水面，弧线跳跃 + 水花
  for(const d of dolphins){
    const cyc=((T*0.4+d.ph)%d.period)/d.period;
    const px=d.x + d.dir*Math.sin(T*0.25+d.ph)*40;
    let py, show=false, h=0;
    if(cyc<0.5){                       // 跃出阶段
      show=true;
      h=Math.sin(cyc/0.5*3.1416)*(38+d.size*2);
      py=d.y - h;
    } else if(cyc<0.55){               // 入水前瞬间（刚露头）
      show=true; py=d.y;
    }
    if(!show) continue;
    if(px<vx0-50||px>vx1+50||py<vy0-60||py>vy1+60) continue;
    // 水面涟漪
    ctx.globalCompositeOperation='lighter';
    ctx.strokeStyle='rgba(140,215,255,'+(0.5*(1-h/(38+d.size*2))).toFixed(3)+')';
    ctx.lineWidth=1.4;
    ctx.beginPath();ctx.arc(px,d.y,5+cyc*14,0,6.2832);ctx.stroke();
    ctx.globalCompositeOperation='source-over';
    // 海豚身体（流线型）
    const rot=d.dir*(0.6-h*0.012);
    ctx.save();ctx.translate(px,py);ctx.rotate(rot);
    const L=d.size*2.4;
    const body=ctx.createLinearGradient(-L,0,L,0);
    body.addColorStop(0,'rgba(120,190,235,0.95)');
    body.addColorStop(1,'rgba(190,225,250,0.95)');
    ctx.fillStyle=body;
    ctx.beginPath();
    ctx.moveTo(L,0);                                   // 嘴
    ctx.quadraticCurveTo(L*0.4,-d.size*0.6,-L*0.3,-d.size*0.55);   // 上背
    ctx.quadraticCurveTo(-L*0.9,-d.size*0.1,-L,-d.size*0.2);       // 尾上
    ctx.quadraticCurveTo(-L*1.1,0,-L,-d.size*0.2);                 // 尾鳍
    ctx.quadraticCurveTo(-L*0.9,d.size*0.2,-L*0.3,d.size*0.45);    // 下腹
    ctx.quadraticCurveTo(L*0.3,d.size*0.5,L,0);                    // 回嘴
    ctx.closePath();ctx.fill();
    // 背鳍
    ctx.fillStyle='rgba(90,160,215,0.95)';
    ctx.beginPath();ctx.moveTo(-L*0.1,-d.size*0.5);ctx.lineTo(-L*0.3,-d.size*1.1);ctx.lineTo(-L*0.45,-d.size*0.4);ctx.closePath();ctx.fill();
    ctx.restore();
  }

  // 流星：周期性划过，带渐变拖尾
  for(const m of meteors){
    m.life+=1/60;
    if(m.life>m.max+m.delay){ m.life=0; m.delay=Math.random()*9+2; m.x=WOX+(Math.random()*(WW+400))+400; m.y=WOY+Math.random()*(WH*0.4); }
    if(m.life<m.delay) continue;
    const lt=m.life-m.delay;
    const fx=m.x+m.vx*lt, fy=m.y+m.vy*lt;
    if(fx<vx0-120||fx>vx1+120||fy<vy0-120||fy>vy1+120) continue;
    const tail=52;
    const dx=-m.vx, dy=-m.vy; const dl=Math.hypot(dx,dy)||1;
    const nx=dx/dl, ny=dy/dl;
    const tx2=fx+nx*tail, ty2=fy+ny*tail;
    const fade=Math.min(1,lt*2.2);
    ctx.globalCompositeOperation='lighter';
    const g2=ctx.createLinearGradient(fx,fy,tx2,ty2);
    g2.addColorStop(0,'rgba(255,250,235,'+(0.9*fade).toFixed(3)+')');
    g2.addColorStop(0.35,'rgba(170,200,255,'+(0.5*fade).toFixed(3)+')');
    g2.addColorStop(1,'rgba(120,150,255,0)');
    ctx.strokeStyle=g2; ctx.lineWidth=2.2;
    ctx.beginPath();ctx.moveTo(fx,fy);ctx.lineTo(tx2,ty2);ctx.stroke();
    ctx.fillStyle='rgba(255,255,255,'+(0.95*fade).toFixed(3)+')';
    ctx.beginPath();ctx.arc(fx,fy,1.8,0,6.2832);ctx.fill();
    ctx.globalCompositeOperation='source-over';
  }

  ctx.globalCompositeOperation='source-over';

  // 桥接星座线（远景）
  if(cam.zoom<0.75){
    const al=(0.75-cam.zoom)/0.75*0.5;
    ctx.strokeStyle='rgba(150,170,255,'+al.toFixed(3)+')';
    ctx.lineWidth=0.6/s; ctx.setLineDash([2/s,3/s]);
    for(const br of BRIDGES){
      ctx.beginPath();ctx.moveTo(ISL.harbor.x,ISL.harbor.y);
      ctx.lineTo(br.target.x,br.target.y);ctx.stroke();
    }
    ctx.setLineDash([]);
  }
  // 音乐韵律：有音乐记录的岛，光环随节拍一圈圈扩散
  for(const i of ISLANDS){
    const mc=i.musicCount||0; if(!mc) continue;
    const n=Math.min(mc,4);
    for(let k=0;k<n;k++){
      const pr=((T*0.32+k/n+i.seed*0.07)%1);
      ctx.beginPath();
      ctx.arc(i.x,i.y+2,i.r*(0.34+pr*0.78),0,6.2832);
      ctx.strokeStyle=hexA(i.color,(1-pr)*0.40);
      ctx.lineWidth=2;ctx.stroke();
    }
  }

  // 岛屿专属氛围：每座岛用自己的光、线条和节奏形成辨认度。
  drawIslandBeautification(vx0,vx1,vy0,vy1);

  // 岛屿生态：居民随记忆数量生长（原创生物）
  drawEcology(now,vx0,vx1,vy0,vy1);

  ctx.restore();

  // 屏幕空间：暗角 + 色调
  const vg=ctx.createRadialGradient(VW/2,VH*0.45,Math.min(VW,VH)*0.25,VW/2,VH*0.5,Math.max(VW,VH)*0.78);
  vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(2,3,12,0.62)');
  ctx.fillStyle=vg;ctx.fillRect(0,0,VW,VH);
  const tg=ctx.createLinearGradient(0,0,0,VH);
  tg.addColorStop(0,'rgba(90,80,180,0.10)');tg.addColorStop(0.5,'rgba(0,0,0,0)');tg.addColorStop(1,'rgba(255,170,110,0.06)');
  ctx.fillStyle=tg;ctx.fillRect(0,0,VW,VH);

  // 岛屿标签
  drawBursts();
  drawLabels();
  drawMini();
  drawFX();
  requestAnimationFrame(draw);
}

function drawWorldOrbits(){
  const cx=WOX+WW/2, cy=WOY+WH/2;
  ctx.save(); ctx.globalCompositeOperation='lighter'; ctx.lineWidth=0.8;
  const dots=[
    [WW*0.54,WH*0.47,0.06,'#9ebeff'],
    [WW*0.67,WH*0.57,0.035,'#c8a8ff'],
    [WW*0.76,WH*0.40,0.025,'#ffd48f']
  ];
  dots.forEach((o,k)=>{
    ctx.strokeStyle=hexA(o[3],o[2]+0.018*Math.sin(T*.4+k));
    ctx.setLineDash([2.2,7.5]); ctx.lineDashOffset=-(T*(1.3+k*.45)+k*9);
    ctx.beginPath(); ctx.ellipse(cx,cy+WH*.015,(WW*.48)*(1+k*.11),(WH*.34)*(1+k*.08),(-.16+k*.12),0,6.2832); ctx.stroke();
  });
  ctx.setLineDash([]); ctx.restore();
}
function drawIslandBeautification(vx0,vx1,vy0,vy1){
  for(const i of ISLANDS){
    if(i.x+i.r*2.2<vx0-30||i.x-i.r*2.2>vx1+30||i.y+i.r*2.2<vy0-30||i.y-i.r*2.2>vy1+30) continue;
    const phase=T*0.55+i.seed*0.37, breathe=0.5+0.5*Math.sin(phase);
    ctx.save(); ctx.translate(i.x,i.y); ctx.globalCompositeOperation='lighter';
    if(i.id==='harbor'){
      ctx.strokeStyle=hexA(i.color,0.10+0.055*breathe); ctx.lineWidth=1.1;
      for(let k=0;k<3;k++){ const rr=i.r*(0.72+k*0.16+0.03*Math.sin(phase+k)); ctx.beginPath();ctx.arc(0,0,rr,0,6.2832);ctx.stroke(); }
      ctx.fillStyle=hexA('#ffe6bb',0.15+0.16*breathe);
      for(let k=0;k<7;k++){ const a=-2.7+k*0.9, rr=i.r*(0.66+0.08*(k%2)); ctx.beginPath();ctx.arc(Math.cos(a)*rr,Math.sin(a)*rr,1.1+0.55*(k%2),0,6.2832);ctx.fill(); }
      const beam=ctx.createLinearGradient(0,-i.r*0.65,0,-i.r*1.65); beam.addColorStop(0,hexA(i.color,0.13));beam.addColorStop(1,hexA(i.color,0));
      ctx.fillStyle=beam;ctx.beginPath();ctx.moveTo(-5,-i.r*.58);ctx.lineTo(5,-i.r*.58);ctx.lineTo(22,-i.r*1.72);ctx.lineTo(-22,-i.r*1.72);ctx.closePath();ctx.fill();
    }else if(i.id==='knowledge'){
      ctx.strokeStyle=hexA(i.color,0.11+0.05*breathe);ctx.lineWidth=1;
      for(let k=0;k<3;k++){const ry=i.r*(.48+k*.13),rx=i.r*(.88+k*.08);ctx.beginPath();ctx.ellipse(0,0,rx,ry,(-.28+k*.34)+Math.sin(phase*.2)*.03,0,6.2832);ctx.stroke();}
      ctx.fillStyle='rgba(219,241,255,.34)'; for(let k=0;k<5;k++){const a=phase*.18+k*1.26,rr=i.r*(.58+(k%2)*.13);ctx.fillRect(Math.cos(a)*rr-2,Math.sin(a)*rr-1,4+(k%2)*3,1.4);}
    }else if(i.id==='memory'){
      ctx.strokeStyle=hexA(i.color,0.08+0.04*breathe);ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,0,i.r*.86,0,6.2832);ctx.stroke();
      for(let k=0;k<9;k++){const a=phase*.23+k*2.399,rr=i.r*(.68+.2*((k*7)%5)/5),tw=0.22+0.48*Math.abs(Math.sin(phase*1.3+k*1.7));ctx.fillStyle='rgba(197,255,220,'+tw.toFixed(3)+')';ctx.beginPath();ctx.arc(Math.cos(a)*rr,Math.sin(a)*rr,1.15+(k%3)*.38,0,6.2832);ctx.fill();}
    }else if(i.id==='creation'){
      const cols=['#ff9ad5','#8ee7ff','#ffe38f'];
      for(let k=0;k<3;k++){ctx.strokeStyle=hexA(cols[k],0.13+0.05*breathe);ctx.lineWidth=1.3;ctx.beginPath();ctx.arc(0,0,i.r*(.62+k*.15),phase*(k%2?-.25:.3)+k,phase*(k%2?-.25:.3)+k+2.1);ctx.stroke();}
      for(let k=0;k<8;k++){const a=k*1.73+phase*.22,r0=i.r*(.7+.08*(k%3));ctx.fillStyle=hexA(cols[k%3],.36);ctx.fillRect(Math.cos(a)*r0,Math.sin(a)*r0,2.2,2.2);}
    }else if(i.id==='future'){
      ctx.strokeStyle=hexA(i.color,0.12+0.055*breathe);ctx.lineWidth=1.1;
      for(let k=0;k<2;k++){ctx.beginPath();ctx.ellipse(0,0,i.r*(.92-k*.16),i.r*(.38+k*.16),(k?-.42:.38)+Math.sin(phase*.3)*.04,0,6.2832);ctx.stroke();}
      for(let k=0;k<8;k++){const a=k*1.39-phase*.17,rr=i.r*(.62+.22*((k*3)%4)/3);ctx.fillStyle=k%2?'rgba(229,222,255,.42)':'rgba(178,210,255,.38)';ctx.beginPath();ctx.arc(Math.cos(a)*rr,Math.sin(a)*rr,1.4+(k%2),0,6.2832);ctx.fill();}
    }else if(i.id==='music'){
      ctx.lineCap='round';
      for(let k=0;k<4;k++){ctx.strokeStyle=hexA(k%2?'#ff9ad5':'#ffd166',0.09+0.04*breathe);ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(0,0,i.r*(.58+k*.17),-0.65+k*.22,1.55+k*.32);ctx.stroke();}
      for(let k=0;k<3;k++){const yy=i.r*(.62+k*.15),amp=2.4+1.6*Math.sin(phase+k);ctx.strokeStyle=hexA('#8ee7ff',0.16);ctx.lineWidth=1;ctx.beginPath();for(let x=-i.r*.9;x<=i.r*.9;x+=4){const y=yy+Math.sin(x*.22+phase*1.6+k)*amp;x===-i.r*.9?ctx.moveTo(x,y):ctx.lineTo(x,y);}ctx.stroke();}
    }else{
      ctx.strokeStyle=hexA(i.color,0.12+0.05*breathe);ctx.lineWidth=1.15;
      for(let k=0;k<5;k++){const a=phase*.18+k*1.2566,rr=i.r*(.64+.07*Math.sin(phase+k));ctx.beginPath();ctx.ellipse(Math.cos(a)*rr,Math.sin(a)*rr,i.r*.18,i.r*.07,a,0,6.2832);ctx.stroke();}
    }
    ctx.restore();
  }
}
function drawLabels(){
  ctx.textAlign='center';ctx.textBaseline='middle';
  for(const i of ISLANDS){
    const [sx,sy]=w2s(i.x,i.y);
    const rs=i.r*S();
    if(rs<9) continue;                                  // 岛太小就不标了，免得糊成一片
    const n=((state.regions[i.id]&&state.regions[i.id].entries.length)||0);
    const ly=sy-rs-16;
    if(ly<-40||ly>VH+40||sx<-80||sx>VW+80) continue;
    const y=ly+Math.sin(T*1.2+i.seed)*2;
    // 鼠标悬停：一圈呼吸的虚线
    if(i.id===hoverId){
      ctx.beginPath(); ctx.arc(sx,sy,rs*1.12,0,6.2832);
      ctx.strokeStyle=hexA(i.color,0.5+0.3*Math.sin(T*4));
      ctx.lineWidth=1.8; ctx.setLineDash([5,5]); ctx.lineDashOffset=-T*7;
      ctx.stroke(); ctx.setLineDash([]); ctx.lineDashOffset=0;
    }
    if(cam.zoom>0.58&&rs>26){
      const label=regionTag(i);
      const sum=[];
      if(i.starCount) sum.push('⭐'+i.starCount);
      if(i.goalCount) sum.push('🌱'+i.goalCount);
      if(i.tripCount) sum.push('🏔'+i.tripCount);
      if(i.musicCount) sum.push('🎵'+i.musicCount);
      const sub=n?(sum.join(' ')+' · '+label):('空 · '+label);
      ctx.font='600 11.5px -apple-system,"PingFang SC",sans-serif';
      const tw=ctx.measureText(regionName(i)).width;
      ctx.font='9.5px -apple-system,"PingFang SC",sans-serif';
      const sw=ctx.measureText(sub).width;
      const w=Math.max(tw,sw)+30, h=34;
      roundRect(ctx,sx-w/2,y-h/2,w,h,11);
      ctx.fillStyle='rgba(12,13,26,.78)';ctx.fill();
      ctx.strokeStyle=i.color+'88';ctx.lineWidth=1;ctx.stroke();
      ctx.fillStyle='#fff';ctx.font='600 11.5px -apple-system,"PingFang SC",sans-serif';
      ctx.fillText(regionName(i),sx,y-5);
      ctx.fillStyle='rgba(255,255,255,.62)';ctx.font='9.5px -apple-system,"PingFang SC",sans-serif';
      ctx.fillText(sub,sx,y+7.5);
    }else{
      const w=clamp(rs*0.95,15,30), h=w;
      roundRect(ctx,sx-w/2,y-h/2,w,h,w/2);
      ctx.fillStyle='rgba(12,13,26,.8)';ctx.fill();
      ctx.strokeStyle=i.color+'99';ctx.lineWidth=1.2;ctx.stroke();
      ctx.font=Math.round(clamp(w*0.5,8,15))+'px sans-serif';
      ctx.fillText(i.emoji,sx,y+1);
    }
    // 脉冲环
    const pr=(T*0.35+i.seed*0.2)%1;
    ctx.beginPath();
    ctx.arc(sx,sy-Math.min(1,rs*0.15), Math.max(6,rs*0.55)*(0.6+pr*0.9),0,6.2832);
    ctx.strokeStyle=hexA(i.color,(1-pr)*0.30);
    ctx.lineWidth=1.2;ctx.stroke();
  }
}
function hexA(hex,a){const c=hex2rgb(hex);return'rgba('+c[0]+','+c[1]+','+c[2]+','+a.toFixed(3)+')';}
function roundRect(g,x,y,w,h,r){
  g.beginPath();
  g.moveTo(x+r,y);g.lineTo(x+w-r,y);g.quadraticCurveTo(x+w,y,x+w,y+r);
  g.lineTo(x+w,y+h-r);g.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
  g.lineTo(x+r,y+h);g.quadraticCurveTo(x,y+h,x,y+h-r);
  g.lineTo(x,y+r);g.quadraticCurveTo(x,y,x+r,y);g.closePath();
}

/* ---------------- 10. UI ---------------- */
const $=id=>document.getElementById(id);
let activeRegion=null;
const explorer={x:ISL.harbor.x,y:ISL.harbor.y,target:null,step:0,facing:1,moving:false};
/* 走路星星拖尾粒子 */
const starTrail=[];
/* 表情包：每 5 秒在头顶浮现一个 */
const EMOJIS=['😊','✨','🌟','🎵','💖','😄','🍀','🌙','⭐','💫','🎶','😆'];
const moveKeys=new Set();
const moveAxis={x:0,y:0};
let joystickPointer=null,joystickMoved=false;
const GAME_TILE=24,GAME_COLS=104,GAME_ROWS=70,GAME_W=GAME_TILE*GAME_COLS,GAME_H=GAME_TILE*GAME_ROWS;
let gameMode=false,gameWorld=null,gameZoom=1.05,gameCam={x:0,y:0},gameFadeAt=0;
const GAME_PALETTES={
  harbor:{grass:'#064638',grass2:'#07513d',path:'#76513a',path2:'#946947',sand:'#b58a50',leaf:['#063d35','#075044','#0a5a43'],leafHi:'#08704f',water:'#063e46'},
  knowledge:{grass:'#092544',grass2:'#0c3155',path:'#17659a',path2:'#237db2',sand:'#8dbbd0',leaf:['#153e70','#20568e','#3275aa'],leafHi:'#72b9df',water:'#0b426f'},
  memory:{grass:'#183c35',grass2:'#214b42',path:'#77533b',path2:'#9a6e47',sand:'#bf9460',leaf:['#193f32','#28523a','#38583a'],leafHi:'#b67b43',water:'#124552'},
  creation:{grass:'#542d54',grass2:'#713965',path:'#9b4f83',path2:'#c16ba0',sand:'#e2a9c9',leaf:['#782f75','#a34294','#c85aa7'],leafHi:'#ffd2e9',water:'#3a527f'},
  future:{grass:'#171b48',grass2:'#222660',path:'#56458f',path2:'#7560b3',sand:'#9d8be0',leaf:['#5545a6','#7663c9','#a28beb'],leafHi:'#e6dfff',water:'#0a1239'},
  music:{grass:'#2c2250',grass2:'#3a2d63',path:'#8a5fd0',path2:'#a97fe8',sand:'#c9a9ef',leaf:['#4a2f8a','#6b45b8','#9b6fe0'],leafHi:'#ffd166',water:'#1a1240'}
};
function buildAdventureWorld(island){
  const rnd=mulberry32((Number(island.seed)||51)*3187+91),tiles=new Uint8Array(GAME_COLS*GAME_ROWS);
  // 各岛有独立的道路/水道走向，路网围绕本岛地标组织，不再共用同一条路线。
  const routes={
    harbor:[[0,48],[12,51],[22,44],[30,40],[39,38],[45,34],[54,35],[64,30],[75,34],[87,28],[103,31]],
    knowledge:[[2,57],[12,54],[20,49],[27,43],[35,39],[43,34],[50,31],[59,32],[66,27],[72,21],[81,17],[94,15]],
    memory:[[2,12],[13,17],[20,26],[29,31],[37,38],[45,39],[54,37],[61,31],[70,28],[82,31],[97,42]],
    creation:[[1,59],[14,51],[23,55],[31,46],[39,41],[46,34],[54,29],[63,37],[73,34],[85,22],[101,18]],
    future:[[4,18],[16,24],[25,34],[34,31],[44,34],[53,42],[62,38],[69,28],[79,23],[91,30],[103,23]],
    music:[[2,38],[14,33],[22,40],[30,32],[38,28],[46,33],[54,26],[63,31],[72,24],[84,29],[99,22]]
  };
  const route=routes[island.id]||routes.harbor,routeWidth={harbor:2.5,knowledge:2.8,memory:1.9,creation:2.15,future:1.7,music:2.3}[island.id]||2.3;
  const lake={x:72,y:12,rx:8,ry:5};
  const roadside=(k)=>{const seg=1+(k%(route.length-1)),a=route[seg-1],b=route[seg],dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy)||1,f=.42+.08*(k%3),side=k%2?1:-1,off=2.8+Math.floor(k/(route.length-1))*1.4;return{x:a[0]+dx*f+side*(-dy/len)*off,y:a[1]+dy*f+side*(dx/len)*off};};
  const entries=(state.regions[island.id]&&state.regions[island.id].entries)||[];
  /* ③④ 按时间从早到晚排：最早的一条离桥头最近，新写的自动排在已有物件后面 */
  const ordered=entries.slice().sort((a,b)=>{
    const ta=Date.parse(a.date||'')||0, tb=Date.parse(b.date||'')||0;
    return (ta-tb)||String(a.id||'').localeCompare(String(b.id||''));
  });
  const recordSpots=ordered.map((_,k)=>roadside(k));
  const featureRoutes={harbor:[2,6,9],knowledge:[3,7,10],memory:[2,6,9],creation:[3,7,10],future:[2,6,9],music:[2,6,9]},featureSpots=(featureRoutes[island.id]||[2,6,9]).map(k=>roadside(k+2));
  const nearFeature=(x,y,r=4)=>featureSpots.some(p=>Math.hypot(x-p.x,y-p.y)<r)||recordSpots.some(p=>Math.hypot(x-p.x,y-p.y)<r);
  const distSeg=(x,y,a,b)=>{const vx=b[0]-a[0],vy=b[1]-a[1],t=clamp(((x-a[0])*vx+(y-a[1])*vy)/(vx*vx+vy*vy),0,1);return Math.hypot(x-a[0]-vx*t,y-a[1]-vy*t);};
  for(let y=0;y<GAME_ROWS;y++)for(let x=0;x<GAME_COLS;x++){
    const nx=x+0.5,ny=y+0.5;
    const lakeN=((nx-lake.x)**2/lake.rx**2)+((ny-lake.y)**2/lake.ry**2);
    const ridgeN=((nx-86)**2/19**2)+((ny-14)**2/13**2);
    let t=0;
    if(island.id==='knowledge'){
      const landA=((nx-25)**2/24**2)+((ny-25)**2/23**2)<1;
      const landB=((nx-66)**2/25**2)+((ny-24)**2/18**2)<1;
      const landC=((nx-55)**2/29**2)+((ny-53)**2/17**2)<1;
      const land=landA||landB||landC;
      const river=route.some((p,k)=>k&&distSeg(nx,ny,route[k-1],p)<routeWidth+0.55);
      const riverbank=route.some((p,k)=>k&&distSeg(nx,ny,route[k-1],p)<routeWidth+2.1);
      if(river)t=1;
      else if(land&&riverbank)t=4;
      else if(land){
        let coast=false;
        for(let oy=-1;oy<=1&&!coast;oy++)for(let ox=-1;ox<=1;ox++){
          const ax=nx+ox*2.2,ay=ny+oy*2.2;
          if(!(((ax-25)**2/24**2)+((ay-25)**2/23**2)<1)&&!(((ax-66)**2/25**2)+((ay-24)**2/18**2)<1)&&!(((ax-55)**2/29**2)+((ay-53)**2/17**2)<1)){coast=true;break;}
        }
        t=coast?4:0;
      }else t=2;
    }
    else if(lakeN<1)t=2;
    else if(lakeN<1.22)t=4;
    else if(ridgeN<0.68)t=3;
    else if(ny>63&&nx>52)t=4;
    else if(route.some((p,k)=>k&&distSeg(nx,ny,route[k-1],p)<routeWidth))t=1;
    tiles[y*GAME_COLS+x]=t;
  }
  const terrain=document.createElement('canvas');terrain.width=GAME_W;terrain.height=GAME_H;
  const g=terrain.getContext('2d'),palette=GAME_PALETTES[island.id]||GAME_PALETTES[({garden:'creation',valley:'memory',market:'harbor',star:'future',grove:'memory'}[island.theme])||'harbor'];
  const bases=[palette.grass,palette.path,palette.water,'#292b2b',palette.sand,'#715a3d'];
  for(let y=0;y<GAME_ROWS;y++)for(let x=0;x<GAME_COLS;x++){
    const t=tiles[y*GAME_COLS+x],px=x*GAME_TILE,py=y*GAME_TILE;
    const color=t===0?(rnd()<.48?palette.grass:palette.grass2):t===1?(rnd()<.46?palette.path:palette.path2):bases[t];
    g.fillStyle=color;g.fillRect(px,py,GAME_TILE,GAME_TILE);
    if(t===1&&island.id!=='knowledge'){
      // 地面道路用相邻地块塑造参差的泥土边沿，避免规整的方格切线。
      const dirs=[[0,-1],[1,0],[0,1],[-1,0]];
      dirs.forEach(([dx,dy],side)=>{
        const tx=x+dx,ty=y+dy,near=tx>=0&&ty>=0&&tx<GAME_COLS&&ty<GAME_ROWS&&tiles[ty*GAME_COLS+tx]===1;
        if(!near&&rnd()>.28){
          g.fillStyle=side===0?palette.grass2:palette.grass;
          const bite=2+(rnd()*4|0);
          if(side===0)g.fillRect(px,py, GAME_TILE,bite);
          else if(side===1)g.fillRect(px+GAME_TILE-bite,py,bite,GAME_TILE);
          else if(side===2)g.fillRect(px,py+GAME_TILE-bite,GAME_TILE,bite);
          else g.fillRect(px,py,bite,GAME_TILE);
        }
      });
      g.fillStyle='rgba(231,196,139,.32)';
      for(let pebble=0;pebble<4;pebble++)g.fillRect(px+3+(rnd()*18|0),py+3+(rnd()*18|0),1+(rnd()*2|0),1);
    }
    if(t===2||island.id==='knowledge'&&t===1){g.fillStyle=island.id==='knowledge'?'rgba(119,206,235,.38)':'rgba(62,126,119,.38)';g.fillRect(px+4+(rnd()*13|0),py+5+(rnd()*14|0),5,1);g.fillRect(px+2+(rnd()*16|0),py+17+(rnd()*4|0),3,1);}
    else if(t===3){g.fillStyle='#171a1d';g.fillRect(px,py,GAME_TILE,4);g.fillStyle='#554a43';g.fillRect(px+4,py+6,9,5);g.fillStyle='#353738';g.fillRect(px+14,py+15,6,4);}
    else{for(let n=0;n<(t===0?15:t===4?7:5);n++){g.fillStyle=t===0?(island.id==='knowledge'?(rnd()<.5?'rgba(99,172,211,.24)':'rgba(2,23,53,.28)'):island.id==='creation'?(rnd()<.5?'rgba(246,150,213,.28)':'rgba(42,17,52,.32)'):island.id==='future'?(rnd()<.5?'rgba(174,158,255,.24)':'rgba(5,8,35,.35)'):(rnd()<.5?'rgba(28,119,74,.50)':'rgba(1,37,31,.34)')):'rgba(44,31,27,.32)';g.fillRect(px+(rnd()*22|0),py+(rnd()*22|0),1+rnd()*3|0,1+rnd()*3|0);}}
  }
  const objects=[],solids=[];
  const HITBOX={bookMemory:[58,80],memoryTree:[54,78],largeCanvas:[60,74],largeStar:[56,74],largeHouse:[62,78],
    lighthouse:[42,90],studio:[58,54],easel:[36,50],well:[32,42],hollow:[48,70],dock:[74,42],harborHouse:[46,46],
    earth:[88,70],portal:[36,58],memoryOrb:[28,38],tent:[44,48],cave:[42,44],fire:[28,36],
    musicDisc:[54,60],musicHall:[58,54],bigNote:[52,68],speaker:[30,40],record:[30,34]};
  const add=(type,x,y,s=1,extra={})=>{const hb=HITBOX[type]||[36,48];
    const o={type,x:x*GAME_TILE,y:y*GAME_TILE,s,seed:rnd(),hitW:hb[0]*s,hitH:hb[1]*s,...extra};objects.push(o);if(['tree','bookTree','noteTree','starTree','memoryTree','stump','tent','lighthouse','earth','cave','crate','studio','hollow','harborHouse','largeHouse','largeCanvas','largeStar','musicHall','bigNote'].includes(type))solids.push({x:o.x,y:o.y,r:type==='tree'||type==='bookTree'||type==='noteTree'||type==='starTree'||type==='memoryTree'?10*s:type==='tent'||type==='lighthouse'||type==='earth'||type==='studio'||type==='hollow'||type==='harborHouse'||type==='largeHouse'||type==='largeCanvas'||type==='largeStar'||type==='musicHall'||type==='bigNote'?18*s:6*s});return o;};
  for(let y=2;y<GAME_ROWS-2;y++)for(let x=2;x<GAME_COLS-2;x++){
    const t=tiles[y*GAME_COLS+x];if(t!==0)continue;
    if(nearFeature(x,y,4)||route.some((p,k)=>k&&distSeg(x,y,route[k-1],p)<4))continue;
    const wood=(x<42&&y>3)||(x>48&&(y<29||y>42));
    const groveChance={harbor:0.24,knowledge:0.32,memory:0.27,creation:0.24,future:0.27,music:0.14}[island.id]||0.24;
    if(wood&&rnd()<groveChance){
      const groveType={knowledge:'bookTree',creation:'noteTree',future:'starTree',memory:'memoryTree',music:'noteTree'}[island.id]||'tree';
      add(groveType,x+(rnd()-.5),y+(rnd()-.5),0.78+rnd()*.6,{variant:rnd()});
    }else if(rnd()<0.075){
      const undergrowth={knowledge:'looseBook',creation:'note',future:'star',memory:'mushroom',music:'note'}[island.id]||'bush';
      add(undergrowth,x+(rnd()-.5),y+(rnd()-.5),.55+rnd()*.8,{variant:rnd()});
    }
  }
  // 像俯视角 RPG 地图一样，用独立地物把道路、岸边和空地填充起来。
  for(let n=0;n<760;n++){
    const x=2+rnd()*(GAME_COLS-4),y=2+rnd()*(GAME_ROWS-4),t=tiles[(y|0)*GAME_COLS+(x|0)];
    if(t===2||t===3||nearFeature(x,y,3.5))continue;
    if(t===4)add(island.id==='future'||island.id==='music'?'star':'rock',x,y,.55+rnd()*1.05,{variant:rnd()});
    else if(rnd()<(island.id==='creation' ? 0.72 : island.id==='memory' ? 0.68 : 0.56)){
      const detail={creation:rnd()<.72?'note':'paintPot',future:'star',memory:rnd()<.66?'mushroom':'memoryOrb',knowledge:rnd()<.72?'looseBook':'shell',music:rnd()<.18?'note':'shell'}[island.id]||'flower';
      add(detail,x,y,.55+rnd()*.8,{variant:rnd()});
    }else add(island.id==='future'||island.id==='music'?'star':island.id==='creation'?'paintPot':island.id==='knowledge'?'looseBook':'rock',x,y,.4+rnd()*.75,{variant:rnd()});
  }
  // 去中心化：把岛屿地标放在不同道路旁，岛屿各处都有自己的景观点。
  const site=(n)=>featureSpots[n%featureSpots.length]||roadside(n+1);
  if(island.id==='knowledge'){
    const a=site(0),b=site(1),c=site(2);add('lighthouse',a.x,a.y,1.25);add('bookMemory',b.x,b.y,2.1,{variant:rnd(),islandLink:true});add('well',c.x,c.y,.9);add('bench',a.x+4,a.y+2,.8);
  }else if(island.id==='memory'){
    const a=site(0),b=site(1),c=site(2);add('memoryTree',a.x,a.y,1.9,{variant:rnd(),islandLink:true});add('hollow',b.x,b.y,1.1);add('memoryOrb',c.x,c.y,1.15);add('mushroom',b.x+4,b.y+2,1.1);
  }else if(island.id==='creation'){
    const a=site(0),b=site(1),c=site(2);add('largeCanvas',a.x,a.y,1.7,{variant:rnd(),islandLink:true});add('studio',b.x,b.y,1.05);add('easel',c.x,c.y,1.2);add('paintPot',a.x+4,a.y+2,.8);
  }else if(island.id==='future'){
    const a=site(0),b=site(1),c=site(2);add('earth',a.x,a.y,1.15);add('largeStar',b.x,b.y,1.7,{variant:rnd(),islandLink:true});add('portal',c.x,c.y,.9);for(let k=0;k<18;k++){const q=site(k%3),ang=rnd()*Math.PI*2,rr=3+rnd()*8;add('star',q.x+Math.cos(ang)*rr,q.y+Math.sin(ang)*rr,.55+rnd()*.7,{variant:rnd()});}
  }else if(island.id==='music'){
    const a=site(0),b=site(1),c=site(2);add('bigNote',a.x,a.y,1.9,{variant:rnd(),islandLink:true});add('musicHall',b.x,b.y,1.2);add('record',c.x,c.y,1.0);add('speaker',a.x+4,a.y+2,.9);for(let k=0;k<4;k++){const q=site(k%3),ang=rnd()*Math.PI*2,rr=4+rnd()*7;add('note',q.x+Math.cos(ang)*rr,q.y+Math.sin(ang)*rr,.58+rnd()*.55,{variant:rnd()});}
  }else if(island.id==='harbor'){
    const a=site(0),b=site(1),c=site(2);add('largeHouse',a.x,a.y,1.65,{islandLink:true});add('harborHouse',b.x,b.y,1.05);add('dock',c.x,c.y,.9);add('boat',c.x+4,c.y+2,.85);add('lamp',a.x+4,a.y+2,.8);
  }else{
    const a=site(0),b=site(1),c=site(2);add('tent',a.x,a.y,.95,{islandLink:true});add('fire',a.x+3,a.y+2,.8);add('well',b.x,b.y,.85);add('cave',c.x,c.y,1.0);add('sign',b.x+3,b.y+2,.75);
  }
  /* ① 兜底：保证每座岛都有可点的大物件（点它 = 打开这座岛的记忆） */
  if(!objects.some(o=>o.islandLink)){
    const big=objects.filter(o=>!o.entryId).sort((a,b)=>(b.hitW*b.hitH)-(a.hitW*a.hitH))[0];
    if(big) big.islandLink=true;
  }
  // 新增的每条记录都成为道路旁醒目的主题纪念物，并可点击打开原记忆详情。
  let firstMonument=null;
  ordered.forEach((entry,k)=>{
    const p=recordSpots[k]||roadside(k),x=p.x,y=p.y;
    // 音乐记忆 → 唱片（可点击播放）；普通记忆按岛主题渲染
    const isMusic=(entry.kind||'memory')==='music';
    const type=isMusic?'musicDisc':({knowledge:'bookMemory',memory:'memoryTree',creation:'largeCanvas',future:'largeStar',harbor:'largeHouse'}[island.id]||'largeHouse');
    const scale=isMusic?1.5:({knowledge:2.25,memory:1.78,creation:1.72,future:1.72,harbor:1.72}[island.id]||1.6);
    add(type,x,y,scale,{entryId:entry.id,title:entry.title,kind:entry.kind||'memory',variant:rnd()});
    if(k===0) firstMonument=objects[objects.length-1];       // 最早的一条 = 离桥头最近的那个
  });  objects.sort((a,b)=>a.y-b.y);
  /* ① 进岛落点：站在【最早那条记忆】的大物件旁边；脚下必须是能走的地（不是水也不是实心物件） */
  let startSpot=null;
  const standable=(px,py)=>{
    const tx=Math.floor(px/GAME_TILE),ty=Math.floor(py/GAME_TILE);
    if(tx<1||ty<1||tx>=GAME_COLS-1||ty>=GAME_ROWS-1)return false;
    const tt=tiles[ty*GAME_COLS+tx]; if(tt===2||tt===3)return false;
    return !solids.some(s=>Math.hypot(px-s.x,py-s.y)<s.r);
  };
  if(firstMonument){
    for(const off of [[0,48],[0,60],[0,74],[-50,32],[50,32],[0,-54],[-58,52],[58,52],[0,86]]){
      const px=firstMonument.x+off[0], py=firstMonument.y+off[1];
      if(standable(px,py)){ startSpot={x:px,y:py,entryId:firstMonument.entryId}; break; }
    }
    if(!startSpot) startSpot={x:firstMonument.x,y:firstMonument.y+48,entryId:firstMonument.entryId};
  }
  return {id:island.id,tiles,terrain,objects,solids,palette,entries:entries.length,startSpot};
}
function gameCanWalk(x,y){
  if(!gameWorld)return false;
  const tx=Math.floor(x/GAME_TILE),ty=Math.floor(y/GAME_TILE);
  if(tx<1||ty<1||tx>=GAME_COLS-1||ty>=GAME_ROWS-1)return false;
  const t=gameWorld.tiles[ty*GAME_COLS+tx];if(t===2||t===3)return false;
  return !gameWorld.solids.some(p=>Math.hypot(x-p.x,y-p.y)<p.r);
}
function drawAdventureObject(o){
  const x=Math.round(o.x),y=Math.round(o.y),s=o.s,variant=o.variant||o.seed;
  const px=(x,v)=>Math.round(x+v*s),py=v=>Math.round(y+v*s);
  if(o.type&&o.type.startsWith('record')){
    const icon={recordStar:'⭐',recordGoal:'🌱',recordTravel:'🏔',recordMusic:'🎵',recordRecall:'♥',bookMemory:'📘'}[o.type]||'⭐';
    ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,226,145,.23)';ctx.beginPath();ctx.arc(x,y-15*s,15*s,0,6.2832);ctx.fill();ctx.restore();
    ctx.fillStyle='rgba(9,13,22,.88)';ctx.beginPath();ctx.arc(x,y-15*s,10*s,0,6.2832);ctx.fill();ctx.strokeStyle='#f6df9d';ctx.lineWidth=1.5;ctx.stroke();ctx.font=Math.max(12,17*s)+'px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.shadowColor='#111';ctx.shadowBlur=4;ctx.fillStyle='#fff';ctx.fillText(icon,x,y-15*s);ctx.shadowBlur=0;
    if(o.type==='recordRecall'){ctx.font='7px sans-serif';ctx.fillStyle='#ffe9a6';[[-10,-25],[10,-25],[-10,-5],[10,-5]].forEach(([dx,dy])=>ctx.fillText('✦',x+dx*s,y+dy*s));}
  }else if(o.type==='noteTree'){
    ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(px(x,-19),py(2),39*s,8*s);
    const notes=[[-10,-49],[-1,-62],[8,-42],[1,-27],[-8,-17]];
    notes.forEach(([nx,ny],k)=>{const xx=px(x,nx),yy=py(ny),c=['#ffd5eb','#ff9ad5','#e881c7','#fff0a8','#d9b4ff'][k];ctx.fillStyle='rgba(19,13,40,.8)';ctx.fillRect(xx+2*s,yy-2*s,5*s,4*s);ctx.fillStyle=c;ctx.beginPath();ctx.ellipse(xx,yy,5*s,3.5*s,-.35,0,6.2832);ctx.fill();ctx.fillRect(xx+3*s,yy-23*s,2*s,23*s);if(k===2)ctx.fillRect(xx+4*s,yy-23*s,12*s,2*s);});
  }else if(o.type==='starTree'){
    ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(px(x,-19),py(2),39*s,8*s);
    for(let k=0;k<7;k++){const a=k*2.399+variant*4,rr=(8+(k%3)*8)*s,xx=x+Math.cos(a)*rr,yy=y-34*s+Math.sin(a)*rr*.72,r=(2+(k%3))*s;ctx.fillStyle=k%2?'#c9b8ff':'#fff2b0';ctx.beginPath();for(let q=0;q<10;q++){const an=-Math.PI/2+q*Math.PI/5,rad=q%2?r*.42:r;const ax=xx+Math.cos(an)*rad,ay=yy+Math.sin(an)*rad; q?ctx.lineTo(ax,ay):ctx.moveTo(ax,ay);}ctx.closePath();ctx.fill();}
  }else if(o.type==='memoryTree'){
    const c=gameWorld.palette.leaf[1];ctx.fillStyle='#463326';ctx.fillRect(px(x,-3),py(-18),7*s,20*s);ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y-34*s,22*s,0,6.2832);ctx.fill();ctx.fillStyle=gameWorld.palette.leafHi;for(let k=0;k<5;k++){const xx=x+((k%3)-1)*12*s,yy=y-(25+(k%2)*15)*s;ctx.fillRect(xx-2*s,yy-2*s,4*s,4*s);ctx.fillStyle='#f6d88a';ctx.fillRect(xx-1*s,yy-1*s,2*s,2*s);ctx.fillStyle=gameWorld.palette.leafHi;}
  }else if(o.type==='note'||o.type==='star'||o.type==='mushroom'||o.type==='shell'||o.type==='paintPot'){
    if(o.type==='note'){ctx.fillStyle='#f7cae4';ctx.beginPath();ctx.ellipse(x-3*s,y-4*s,5*s,3*s,-.35,0,6.2832);ctx.fill();ctx.fillRect(px(x,0),py(-20),2*s,17*s);ctx.fillRect(px(x,1),py(-20),9*s,2*s);}
    else if(o.type==='star'){ctx.fillStyle=variant>.5?'#fff0a8':'#c9b8ff';ctx.beginPath();for(let q=0;q<10;q++){const an=-Math.PI/2+q*Math.PI/5,r=(q%2?3:7)*s,xx=x+Math.cos(an)*r,yy=y-7*s+Math.sin(an)*r;q?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy);}ctx.closePath();ctx.fill();}
    else if(o.type==='mushroom'){ctx.fillStyle='#e8d4bb';ctx.fillRect(px(x,-2),py(-9),5*s,9*s);ctx.fillStyle='#d88673';ctx.beginPath();ctx.ellipse(x,y-10*s,9*s,5*s,0,Math.PI,6.2832);ctx.fill();ctx.fillStyle='#fff0d2';ctx.fillRect(px(x,-4),py(-13),2*s,2*s);}
    else if(o.type==='shell'){ctx.fillStyle='#bbd9e8';ctx.beginPath();ctx.ellipse(x,y-3*s,9*s,5*s,0,Math.PI,6.2832);ctx.fill();ctx.fillStyle='#e3f2f5';ctx.fillRect(px(x,-7),py(-5),14*s,2*s);}
    else{ctx.fillStyle='#d58b67';ctx.fillRect(px(x,-6),py(-10),12*s,10*s);ctx.fillStyle='#f0c2a3';ctx.fillRect(px(x,-7),py(-12),14*s,3*s);ctx.fillStyle=['#ed78ba','#65bce0','#f4d05f'][Math.floor(variant*3)%3];ctx.fillRect(px(x,-4),py(-8),4*s,5*s);ctx.fillStyle='#eee0d0';ctx.fillRect(px(x,2),py(-7),2*s,4*s);}
  }else if(o.type==='earth'){
    const r=29*s;ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(x,y+31*s,35*s,9*s,0,0,6.2832);ctx.fill();ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle='rgba(194,177,255,.7)';ctx.lineWidth=2*s;ctx.beginPath();ctx.ellipse(x,y-10*s,49*s,15*s,-.25,0,6.2832);ctx.stroke();ctx.restore();ctx.fillStyle='#347eb9';ctx.beginPath();ctx.arc(x,y-12*s,r,0,6.2832);ctx.fill();ctx.fillStyle='#62c991';ctx.beginPath();ctx.moveTo(x-19*s,y-23*s);ctx.lineTo(x-7*s,y-31*s);ctx.lineTo(x-2*s,y-20*s);ctx.lineTo(x-10*s,y-13*s);ctx.lineTo(x-6*s,y-4*s);ctx.lineTo(x-19*s,y-7*s);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(x+6*s,y-32*s);ctx.lineTo(x+21*s,y-27*s);ctx.lineTo(x+16*s,y-17*s);ctx.lineTo(x+24*s,y-10*s);ctx.lineTo(x+11*s,y-3*s);ctx.lineTo(x+2*s,y-16*s);ctx.closePath();ctx.fill();ctx.fillStyle='rgba(214,240,255,.5)';ctx.beginPath();ctx.arc(x-9*s,y-21*s,17*s,2.9,4.7);ctx.stroke();
  }else if(o.type==='portal'){
    ctx.strokeStyle='#a99bff';ctx.lineWidth=3*s;ctx.beginPath();ctx.ellipse(x,y-11*s,12*s,23*s,0,0,6.2832);ctx.stroke();ctx.strokeStyle='#e5dfff';ctx.lineWidth=1*s;ctx.beginPath();ctx.ellipse(x,y-11*s,6*s,17*s,0,0,6.2832);ctx.stroke();
  }else if(o.type==='tree'){
    const colors=gameWorld.palette.leaf,leaf=colors[Math.floor(variant*colors.length)%colors.length],hi=gameWorld.palette.leafHi;
    ctx.fillStyle='rgba(0,0,0,.34)';ctx.beginPath();ctx.ellipse(x,y+2*s,19*s,6*s,0,0,6.2832);ctx.fill();
    ctx.fillStyle='#32251e';ctx.fillRect(px(x,-5),py(-17),10*s,20*s);ctx.fillRect(px(x,-10),py(-2),8*s,3*s);ctx.fillRect(px(x,3),py(-5),9*s,3*s);
    ctx.fillStyle='#70432b';ctx.fillRect(px(x,-2),py(-15),3*s,17*s);ctx.fillStyle='#99633c';ctx.fillRect(px(x,1),py(-12),2*s,12*s);
    ctx.fillStyle='#4b3025';ctx.fillRect(px(x,-9),py(-39),3*s,19*s);ctx.fillRect(px(x,6),py(-35),3*s,15*s);
    for(let tier=0;tier<4;tier++){
      const yy=-62+tier*12,ww=(25-tier*3)*s;
      ctx.fillStyle='#071d25';ctx.fillRect(px(x,-ww/2-3),py(yy+3),ww+6*s,13*s);
      ctx.fillStyle=leaf;ctx.fillRect(px(x,-ww/2-1),py(yy),ww+2*s,12*s);
      ctx.fillStyle=gameWorld.palette.leaf[(Math.floor(variant*7)+tier+1)%colors.length];ctx.fillRect(px(x,-ww/2+2),py(yy+7),ww-3*s,4*s);
      ctx.fillStyle=hi;ctx.fillRect(px(x,-ww/2+4),py(yy+2),Math.max(2,ww*.42),2*s);ctx.fillRect(px(x,-ww/2+8),py(yy+5),Math.max(2,ww*.23),1.5*s);
      for(let fleck=0;fleck<5;fleck++){
        const fx=-ww/2+((fleck*11+Math.floor(variant*37)+tier*5)%(Math.max(8,ww-5)));
        const fy=yy+3+((fleck*7+tier*3)%7);
        ctx.fillStyle=fleck%3===0?hi:gameWorld.palette.grass;ctx.fillRect(px(x,fx),py(fy),1.5*s,1.5*s);
      }
    }
  }else if(o.type==='bookTree'){
    const covers=['#17477a','#235f9b','#287cad','#12365f'];
    ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(px(x,-17),py(1),35*s,8*s);
    for(let tier=0;tier<4;tier++){
      const yy=-66+tier*13,ww=(28-tier*2)*s;
      ctx.fillStyle='#dceaf0';ctx.fillRect(px(x,-ww/2),py(yy+3),ww,11*s);
      ctx.fillStyle=covers[(tier+Math.floor(variant*4))%covers.length];ctx.fillRect(px(x,-ww/2-2),py(yy),ww+4*s,9*s);
      ctx.fillStyle='#9dd7eb';ctx.fillRect(px(x,-ww/2+4),py(yy+2),Math.max(2,ww*.43),1.5*s);
      ctx.fillStyle='#e2c77a';ctx.fillRect(px(x,ww/2-5),py(yy+1),1.5*s,7*s);
    }
  }else if(o.type==='looseBook'){
    ctx.fillStyle='#e4edf0';ctx.fillRect(px(x,-9),py(-3),18*s,8*s);ctx.fillStyle='#27689d';ctx.fillRect(px(x,-10),py(-7),18*s,6*s);ctx.fillStyle='#9dd7eb';ctx.fillRect(px(x,-7),py(-5),10*s,1.5*s);
  }else if(o.type==='bush'){
    ctx.fillStyle='#102e28';ctx.fillRect(px(x,-11),py(-2),22*s,11*s);ctx.fillStyle='#267249';ctx.fillRect(px(x,-8),py(-7),16*s,9*s);ctx.fillStyle='#4b9b5a';ctx.fillRect(px(x,-4),py(-8),5*s,3*s);
  }else if(o.type==='rock'){
    const rockCol=variant>.5?'#686057':'#69665d';ctx.fillStyle='rgba(0,0,0,.3)';ctx.beginPath();ctx.ellipse(x,y+2*s,10*s,4*s,0,0,6.2832);ctx.fill();
    ctx.fillStyle='#25282a';ctx.beginPath();ctx.moveTo(px(x,-10),py(-1));ctx.lineTo(px(x,-7),py(-8));ctx.lineTo(px(x,-2),py(-12));ctx.lineTo(px(x,5),py(-10));ctx.lineTo(px(x,10),py(-4));ctx.lineTo(px(x,9),py(1));ctx.closePath();ctx.fill();
    ctx.fillStyle=rockCol;ctx.beginPath();ctx.moveTo(px(x,-8),py(-2));ctx.lineTo(px(x,-5),py(-7));ctx.lineTo(px(x,-1),py(-10));ctx.lineTo(px(x,4),py(-8));ctx.lineTo(px(x,7),py(-3));ctx.lineTo(px(x,5),py(0));ctx.closePath();ctx.fill();
    ctx.fillStyle='#aaa08c';ctx.fillRect(px(x,-5),py(-7),3*s,2*s);ctx.fillRect(px(x,-2),py(-9),2*s,2*s);ctx.fillStyle='#414247';ctx.fillRect(px(x,3),py(-5),3*s,4*s);
  }else if(o.type==='flower'){
    ctx.fillStyle='#31452f';ctx.fillRect(px(x,-1),py(-9),2*s,9*s);ctx.fillStyle=variant>.5?'#f0d2a1':'#e4b6c4';ctx.fillRect(px(x,-4),py(-12),9*s,6*s);ctx.fillStyle='#f5d66e';ctx.fillRect(px(x,-1),py(-10),3*s,3*s);
  }else if(o.type==='largeCanvas'){
    ctx.fillStyle='rgba(0,0,0,.34)';ctx.beginPath();ctx.ellipse(x,y+5*s,24*s,7*s,0,0,6.2832);ctx.fill();ctx.fillStyle='#563d32';ctx.fillRect(px(x,-3),py(-4),6*s,39*s);ctx.fillRect(px(x,-27),py(-43),54*s,5*s);ctx.fillRect(px(x,-24),py(-40),4*s,43*s);ctx.fillRect(px(x,20),py(-40),4*s,43*s);ctx.fillStyle='#f0ddbb';ctx.fillRect(px(x,-21),py(-39),42*s,31*s);ctx.fillStyle='#493b58';ctx.fillRect(px(x,-18),py(-36),36*s,25*s);ctx.fillStyle='#f18fc4';ctx.beginPath();ctx.moveTo(x-16*s,y-14*s);ctx.lineTo(x-2*s,y-33*s);ctx.lineTo(x+2*s,y-18*s);ctx.closePath();ctx.fill();ctx.fillStyle='#77c5dd';ctx.beginPath();ctx.arc(x+9*s,y-29*s,5*s,0,6.2832);ctx.fill();ctx.fillStyle='#ffd16f';ctx.fillRect(px(x,-13),py(-16),10*s,3*s);
  }else if(o.type==='largeStar'){
    ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,226,137,.27)';ctx.beginPath();ctx.arc(x,y-24*s,34*s,0,6.2832);ctx.fill();ctx.restore();ctx.fillStyle='rgba(0,0,0,.36)';ctx.beginPath();ctx.ellipse(x,y+4*s,23*s,7*s,0,0,6.2832);ctx.fill();ctx.beginPath();for(let k=0;k<10;k++){const a=-Math.PI/2+k*Math.PI/5,r=(k%2?15:32)*s,xx=x+Math.cos(a)*r,yy=y-27*s+Math.sin(a)*r;k?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy);}ctx.closePath();ctx.fillStyle='#f5d477';ctx.fill();ctx.lineWidth=2*s;ctx.strokeStyle='#fff1b4';ctx.stroke();ctx.fillStyle='#fff9d9';ctx.beginPath();ctx.arc(x-7*s,y-36*s,4*s,0,6.2832);ctx.fill();ctx.fillStyle='#b9a8ff';ctx.beginPath();ctx.arc(x+11*s,y-20*s,3*s,0,6.2832);ctx.fill();
  }else if(o.type==='largeHouse'){
    ctx.fillStyle='rgba(0,0,0,.34)';ctx.beginPath();ctx.ellipse(x,y+5*s,30*s,8*s,0,0,6.2832);ctx.fill();ctx.fillStyle='#f0d5a7';ctx.fillRect(px(x,-24),py(-37),48*s,39*s);ctx.fillStyle='#b86c54';ctx.beginPath();ctx.moveTo(px(x,-31),py(-34));ctx.lineTo(px(x),py(-60));ctx.lineTo(px(x,31),py(-34));ctx.closePath();ctx.fill();ctx.fillStyle='#654356';ctx.fillRect(px(x,-7),py(-19),14*s,21*s);ctx.fillStyle='#8fd8e8';ctx.fillRect(px(x,-19),py(-28),9*s,10*s);ctx.fillRect(px(x,10),py(-28),9*s,10*s);ctx.fillStyle='#ffe7a0';ctx.fillRect(px(x,-15),py(-26),2*s,3*s);ctx.fillRect(px(x,14),py(-26),2*s,3*s);ctx.fillStyle='#e5bd70';ctx.fillRect(px(x,-24),py(-2),48*s,4*s);
  }else if(o.type==='studio'){
    ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(px(x,-25),py(5),50*s,8*s);ctx.fillStyle='#49325b';ctx.fillRect(px(x,-23),py(-27),46*s,30*s);ctx.fillStyle='#d890bd';ctx.fillRect(px(x,-20),py(-29),40*s,4*s);ctx.fillStyle='#f5c8df';ctx.fillRect(px(x,-14),py(-19),13*s,11*s);ctx.fillStyle='#704776';ctx.fillRect(px(x,-12),py(-17),9*s,7*s);ctx.fillStyle='#ffc85e';ctx.fillRect(px(x,8),py(-22),9*s,15*s);ctx.fillStyle='#78c9db';ctx.fillRect(px(x,11),py(-19),4*s,7*s);ctx.fillStyle='#f3c6e1';ctx.fillRect(px(x,-7),py(-2),26*s,3*s);
  }else if(o.type==='easel'){
    ctx.fillStyle='#d8b37c';ctx.fillRect(px(x,-1),py(-3),3*s,21*s);ctx.fillRect(px(x,-10),py(-5),21*s,3*s);ctx.fillRect(px(x,-8),py(-20),17*s,14*s);ctx.fillStyle=['#f18fc4','#77c5dd','#ffd16f'][Math.floor(variant*3)%3];ctx.fillRect(px(x,-6),py(-18),12*s,10*s);ctx.fillStyle='#63476e';ctx.fillRect(px(x,-9),py(15),19*s,3*s);
  }else if(o.type==='harborHouse'){
    ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(px(x,-25),py(5),50*s,8*s);ctx.fillStyle='#e8c99c';ctx.fillRect(px(x,-21),py(-29),42*s,31*s);ctx.fillStyle='#bb7658';ctx.beginPath();ctx.moveTo(px(x,-26),py(-27));ctx.lineTo(px(x),py(-49));ctx.lineTo(px(x,26),py(-27));ctx.closePath();ctx.fill();ctx.fillStyle='#6f4552';ctx.fillRect(px(x,-5),py(-13),11*s,15*s);ctx.fillStyle='#91c9d1';ctx.fillRect(px(x,-16),py(-21),8*s,8*s);ctx.fillRect(px(x,9),py(-21),8*s,8*s);
  }else if(o.type==='hollow'){
    ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(px(x,-31),py(6),62*s,10*s);ctx.fillStyle='#69442d';ctx.fillRect(px(x,-18),py(-40),36*s,43*s);ctx.fillStyle='#8d6039';ctx.fillRect(px(x,-12),py(-45),24*s,11*s);ctx.fillStyle='#192b2d';ctx.beginPath();ctx.ellipse(x,y-7*s,10*s,13*s,0,0,6.2832);ctx.fill();ctx.fillStyle='#b67b43';for(let k=0;k<6;k++){const xx=x+Math.cos(k)*24*s,yy=y-24*s+Math.sin(k*1.7)*15*s;ctx.fillRect(xx,yy,4*s,4*s);}
  }else if(o.type==='memoryOrb'){
    ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,215,133,.28)';ctx.beginPath();ctx.arc(x,y-11*s,18*s,0,6.2832);ctx.fill();ctx.restore();ctx.fillStyle='#7dce9a';ctx.beginPath();ctx.arc(x,y-11*s,8*s,0,6.2832);ctx.fill();ctx.fillStyle='#fff0bc';ctx.fillRect(px(x,-2),py(-14),4*s,7*s);
  }else if(o.type==='dock'){
    ctx.fillStyle='#61452f';ctx.fillRect(px(x,-16),py(-3),32*s,7*s);for(let k=-1;k<=1;k++)ctx.fillRect(px(x,k*11-2),py(-1),4*s,15*s);ctx.fillStyle='#b9824e';for(let k=0;k<4;k++)ctx.fillRect(px(x,-15+k*9),py(-4),7*s,3*s);
  }else if(o.type==='boat'){
    ctx.fillStyle='#854e3c';ctx.beginPath();ctx.moveTo(px(x,-19),py(-4));ctx.lineTo(px(x,19),py(-4));ctx.lineTo(px(x,12),py(4));ctx.lineTo(px(x,-12),py(4));ctx.closePath();ctx.fill();ctx.fillStyle='#d9c99f';ctx.fillRect(px(x,-1),py(-20),2*s,17*s);ctx.fillStyle='#f0e3c4';ctx.beginPath();ctx.moveTo(px(x,1),py(-18));ctx.lineTo(px(x,14),py(-6));ctx.lineTo(px(x,1),py(-5));ctx.closePath();ctx.fill();
  }else if(o.type==='lamp'){
    ctx.fillStyle='#493927';ctx.fillRect(px(x,-2),py(-21),4*s,22*s);ctx.fillStyle='#ffe5a1';ctx.fillRect(px(x,-6),py(-27),12*s,9*s);ctx.fillStyle='rgba(255,231,161,.2)';ctx.beginPath();ctx.arc(x,y-23*s,15*s,0,6.2832);ctx.fill();
  }else if(o.type==='lighthouse'){
    ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(px(x,-32),py(8),66*s,10*s);
    for(let tier=0;tier<5;tier++){
      const yy=5-tier*11,ww=(58-tier*5)*s;
      ctx.fillStyle='#e5edf0';ctx.fillRect(px(x,-ww/2),py(yy-8),ww,10*s);
      ctx.fillStyle=['#164477','#205e91','#2c78a8','#174b7b','#2874a0'][tier];ctx.fillRect(px(x,-ww/2-2),py(yy-17),ww+4*s,10*s);
      ctx.fillStyle='#a9d7e9';ctx.fillRect(px(x,-ww/2+5),py(yy-14),ww*.48,2*s);
      ctx.fillStyle='#d7bd75';ctx.fillRect(px(x,ww/2-7),py(yy-16),2*s,8*s);
    }
    ctx.fillStyle='#d8eef5';ctx.fillRect(px(x,-13),py(-72),26*s,17*s);ctx.fillStyle='#5db5da';ctx.fillRect(px(x,-9),py(-68),18*s,9*s);
    ctx.fillStyle='#f4dc8c';ctx.beginPath();ctx.moveTo(px(x,-18),py(-72));ctx.lineTo(px(x),py(-91));ctx.lineTo(px(x,18),py(-72));ctx.closePath();ctx.fill();
    ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(140,224,255,.22)';ctx.beginPath();ctx.moveTo(px(x,-9),py(-68));ctx.lineTo(px(x,-125),py(-99));ctx.lineTo(px(x,76),py(-99));ctx.lineTo(px(x,9),py(-68));ctx.closePath();ctx.fill();ctx.restore();
  }else if(o.type==='tent'){
    ctx.fillStyle='rgba(0,0,0,.26)';ctx.fillRect(px(x,-20),py(4),45*s,8*s);ctx.fillStyle='#4d4038';ctx.fillRect(px(x,-18),py(-18),40*s,24*s);ctx.fillStyle='#d8c9a9';ctx.beginPath();ctx.moveTo(px(x,-17),py(-17));ctx.lineTo(px(x,2),py(-43));ctx.lineTo(px(x,23),py(-17));ctx.closePath();ctx.fill();ctx.fillStyle='#a88d6a';ctx.beginPath();ctx.moveTo(px(x,2),py(-42));ctx.lineTo(px(x,22),py(-17));ctx.lineTo(px(x,2),py(-17));ctx.closePath();ctx.fill();ctx.fillStyle='#54463b';ctx.fillRect(px(x,-1),py(-17),8*s,23*s);
  }else if(o.type==='fire'){
    ctx.fillStyle='#2e2823';ctx.beginPath();ctx.ellipse(x,y,15*s,8*s,0,0,6.2832);ctx.fill();ctx.fillStyle='#69412b';ctx.fillRect(px(x,-9),py(-2),18*s,4*s);ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,154,55,.22)';ctx.beginPath();ctx.arc(x,y-9*s,19*s,0,6.2832);ctx.fill();ctx.restore();ctx.fillStyle='#f3a445';ctx.fillRect(px(x,-4),py(-15+Math.sin(T*5)*2),8*s,12*s);ctx.fillStyle='#ffe59b';ctx.fillRect(px(x,-2),py(-10+Math.sin(T*5)*2),4*s,7*s);
  }else if(o.type==='bench'||o.type==='crate'||o.type==='log'||o.type==='fence'||o.type==='sign'||o.type==='well'){
    ctx.fillStyle='#34261e';ctx.fillRect(px(x,-10),py(-2),20*s,8*s);ctx.fillStyle=o.type==='well'?'#77786c':'#9a6638';ctx.fillRect(px(x,-9),py(-8),18*s,6*s);ctx.fillStyle='#cf9b54';ctx.fillRect(px(x,-8),py(-7),15*s,2*s);
    if(o.type==='well'){ctx.fillStyle='#644329';ctx.fillRect(px(x,-11),py(-32),3*s,31*s);ctx.fillRect(px(x,9),py(-32),3*s,31*s);ctx.fillStyle='#8ca5a0';ctx.fillRect(px(x,-13),py(-35),28*s,4*s);}
    if(o.type==='fence'){ctx.fillStyle='#54351f';ctx.fillRect(px(x,-12),py(-16),3*s,17*s);ctx.fillRect(px(x,7),py(-16),3*s,17*s);ctx.fillStyle='#9d6d3d';ctx.fillRect(px(x,-12),py(-14),22*s,3*s);}
  }else if(o.type==='cave'){
    ctx.fillStyle='#171a1b';ctx.beginPath();ctx.moveTo(px(x,-44),py(8));ctx.lineTo(px(x,-38),py(-24));ctx.lineTo(px(x,-21),py(-39));ctx.lineTo(px(x,9),py(-44));ctx.lineTo(px(x,40),py(-30));ctx.lineTo(px(x,47),py(8));ctx.closePath();ctx.fill();ctx.fillStyle='#050708';ctx.beginPath();ctx.ellipse(x+5*s,y-7*s,23*s,19*s,0,Math.PI,6.2832);ctx.fill();ctx.fillStyle='#55483d';ctx.fillRect(px(x,-39),py(-25),8*s,4*s);
  }else if(o.type==='bookMemory'){
    ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(101,203,255,.25)';ctx.beginPath();ctx.arc(x,y-23*s,28*s,0,6.2832);ctx.fill();ctx.restore();
    ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(px(x,-19),py(2),39*s,8*s);
    ctx.fillStyle='#eaf2f4';ctx.fillRect(px(x,-16),py(-36),32*s,36*s);
    ctx.fillStyle=['#17477a','#205f96','#2879a8','#344f86'][Math.floor(variant*4)%4];ctx.fillRect(px(x,-19),py(-39),32*s,36*s);
    ctx.fillStyle='#9ed8ee';ctx.fillRect(px(x,-14),py(-33),20*s,2*s);ctx.fillRect(px(x,-14),py(-28),14*s,1.5*s);ctx.fillRect(px(x,-14),py(-23),17*s,1.5*s);
    ctx.fillStyle='#e5ce83';ctx.fillRect(px(x,10),py(-37),2*s,31*s);ctx.fillStyle='#dce8ed';ctx.fillRect(px(x,14),py(-35),2*s,32*s);
  }else if(o.type==='memory'){
    ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,227,135,.25)';ctx.beginPath();ctx.arc(x,y-13*s,16*s,0,6.2832);ctx.fill();ctx.restore();ctx.fillStyle='#2e2834';ctx.fillRect(px(x,-5),py(-3),10*s,4*s);ctx.fillStyle='#e8d078';ctx.beginPath();ctx.moveTo(x,y-8*s);ctx.lineTo(x+4*s,y-15*s);ctx.lineTo(x,y-24*s);ctx.lineTo(x-4*s,y-15*s);ctx.closePath();ctx.fill();ctx.fillStyle='#fff5cb';ctx.fillRect(px(x,-1),py(-19),2*s,8*s);
  }else if(o.type==='musicDisc'){
    // 唱片（音乐记忆）：发光黑胶唱片，靠近可点击播放
    const spin=Music.entry&&Music.entry.id===o.entryId&&Music.playing?T*0.6:0;
    ctx.save();ctx.globalCompositeOperation='lighter';
    ctx.fillStyle='rgba(255,209,102,.22)';ctx.beginPath();ctx.arc(x,y-26*s,30*s,0,6.2832);ctx.fill();ctx.restore();
    ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(x,y+2*s,24*s,7*s,0,0,6.2832);ctx.fill();
    // 唱针臂
    ctx.strokeStyle='#8a7a9a';ctx.lineWidth=3*s;ctx.beginPath();ctx.moveTo(x+10*s,y-34*s);ctx.lineTo(x+22*s,y-12*s);ctx.stroke();
    // 黑胶唱片
    ctx.save();ctx.translate(x,y-26*s);ctx.rotate(spin);
    ctx.fillStyle='#160f22';ctx.beginPath();ctx.arc(0,0,20*s,0,6.2832);ctx.fill();
    ctx.strokeStyle='#2c2140';ctx.lineWidth=1.4;ctx.beginPath();ctx.arc(0,0,16*s,0,6.2832);ctx.stroke();ctx.beginPath();ctx.arc(0,0,11*s,0,6.2832);ctx.stroke();ctx.beginPath();ctx.arc(0,0,6*s,0,6.2832);ctx.stroke();
    ctx.fillStyle='#ffd166';ctx.beginPath();ctx.arc(0,0,5*s,0,6.2832);ctx.fill();
    ctx.fillStyle='#fff0c8';ctx.beginPath();ctx.arc(0,0,1.8*s,0,6.2832);ctx.fill();
    ctx.restore();
    // 顶部音符标记
    ctx.fillStyle='#ffd166';ctx.font='bold '+Math.max(12,15*s)+'px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('🎵',x,y-52*s);
  }else if(o.type==='musicHall'){
    ctx.fillStyle='rgba(0,0,0,.32)';ctx.fillRect(px(x,-20),py(4),44*s,8*s);
    ctx.fillStyle='#3a2f52';ctx.fillRect(px(x,-18),py(-28),40*s,32*s);
    ctx.fillStyle='#2a2240';ctx.fillRect(px(x,-6),py(-16),16*s,20*s);ctx.fillStyle='#ffd166';ctx.fillRect(px(x,-3),py(-12),10*s,14*s);
    ctx.fillStyle='#ffd166';ctx.beginPath();ctx.moveTo(px(x,-16),py(-30));ctx.lineTo(px(x),py(-50));ctx.lineTo(px(x,16),py(-30));ctx.closePath();ctx.fill();
    ctx.fillStyle='#fff0c8';ctx.fillRect(px(x,-1),py(-50),3*s,4*s);ctx.fillStyle='#fff0c8';ctx.fillRect(px(x,-1),py(-54),1.5*s,4*s);
    ctx.fillStyle='#ffd166';ctx.fillRect(px(x,-20),py(-26),3*s,6*s);ctx.fillRect(px(x,18),py(-26),3*s,6*s);
  }else if(o.type==='bigNote'){
    ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,209,102,.26)';ctx.beginPath();ctx.arc(x,y-24*s,34*s,0,6.2832);ctx.fill();ctx.restore();
    ctx.fillStyle='rgba(0,0,0,.32)';ctx.fillRect(px(x,-15),py(2),32*s,8*s);
    ctx.fillStyle='#ffd166';ctx.beginPath();ctx.ellipse(x-4*s,y-12*s,11*s,8*s,-0.2,0,6.2832);ctx.fill();
    ctx.fillStyle='#ffe9b0';ctx.fillRect(px(x,6),py(-34),3*s,22*s);ctx.fillStyle='#ffd166';ctx.fillRect(px(x,9),py(-34),6*s,3*s);ctx.fillRect(px(x,10),py(-30),6*s,3*s);
    ctx.fillStyle='#fff0c8';ctx.beginPath();ctx.ellipse(x-5*s,y-14*s,5*s,3*s,-0.2,0,6.2832);ctx.fill();
  }else if(o.type==='speaker'){
    ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(px(x,-10),py(2),22*s,7*s);
    ctx.fillStyle='#3a2f52';ctx.fillRect(px(x,-10),py(-22),22*s,24*s);ctx.fillStyle='#241d38';ctx.fillRect(px(x,-7),py(-19),16*s,8*s);
    ctx.fillStyle='#120e20';ctx.beginPath();ctx.arc(x,y-8*s,6*s,0,6.2832);ctx.fill();ctx.fillStyle='#8a6fd0';ctx.beginPath();ctx.arc(x,y-8*s,4*s,0,6.2832);ctx.fill();ctx.fillStyle='#c9b6ff';ctx.beginPath();ctx.arc(x-1*s,y-9*s,1.5*s,0,6.2832);ctx.fill();
  }else if(o.type==='record'){
    ctx.fillStyle='#160f22';ctx.beginPath();ctx.arc(x,y-10*s,9*s,0,6.2832);ctx.fill();ctx.strokeStyle='#2c2140';ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(x,y-10*s,6*s,0,6.2832);ctx.stroke();ctx.fillStyle='#ffd166';ctx.beginPath();ctx.arc(x,y-10*s,2.5*s,0,6.2832);ctx.fill();
  }
}
function drawGameAdventurer(){
  const x=Math.round(explorer.x),y=Math.round(explorer.y);
  const step=explorer.step;
  const walk=explorer.moving?Math.sin(step):0;         // 爬行四肢摆动相位（-1~1）
  const bob=explorer.moving?Math.round(Math.abs(Math.sin(step))*1.2):0;  // 爬行起伏（更贴地）
  /* 影子（爬行姿态更宽更扁） */
  ctx.fillStyle='rgba(0,0,0,.30)';ctx.beginPath();ctx.ellipse(x,y+1,12,3.5,0,0,6.2832);ctx.fill();

  /* 星星拖尾：爬行时在身后喷出小星星，向上飘散并淡出（数量少、尺寸大、约 1.5 秒淡出） */
  if(explorer.moving && Math.random()<0.3){
    starTrail.push({x:x-explorer.facing*12, y:y-6+Math.random()*9, vx:-explorer.facing*(0.3+Math.random()*0.6), vy:-(0.25+Math.random()*0.6), r:3+Math.random()*2.6, life:1, decay:1/90});
  }
  for(let i=starTrail.length-1;i>=0;i--){
    const p=starTrail[i]; p.x+=p.vx; p.y+=p.vy; p.vy-=0.01; p.life-=p.decay;
    if(p.life<=0){starTrail.splice(i,1);continue;}
    const tw=0.5+0.5*Math.abs(Math.sin(T*3+i));
    ctx.fillStyle='rgba(255,240,196,'+(p.life*tw*0.6).toFixed(3)+')';
    const s=p.r*(0.75+0.25*tw);
    ctx.save();ctx.translate(p.x,p.y);
    ctx.beginPath();
    for(let k=0;k<8;k++){const a=k*Math.PI/4,rr=k%2?s:s*0.5; k?ctx.lineTo(Math.cos(a)*rr,Math.sin(a)*rr):ctx.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}
    ctx.closePath();ctx.fill();ctx.restore();
  }

  ctx.save();ctx.translate(x,y+bob);ctx.scale(explorer.facing,1);
  /* 熊猫（像素宠物形象）：四脚并用爬行，圆滚滚白肚皮、黑耳朵黑眼圈、张嘴笑 */
  const legSwing=walk*3.5;
  /* 四肢（黑色短腿，爬行交替摆动：对角线前后肢同相，左右交替） */
  ctx.fillStyle='#23201f';
  ctx.fillRect(-9+legSwing,-2,4,5);                    // 左前腿
  ctx.fillRect(7-legSwing,-2,4,5);                     // 右后腿
  ctx.fillRect(-4-legSwing,-1,4,5);                    // 左后腿
  ctx.fillRect(4+legSwing,-1,4,5);                     // 右前腿
  /* 圆滚滚的身体（白色为主，趴伏姿态） */
  ctx.fillStyle='#f4f1ea';ctx.fillRect(-11,-12,22,11);
  ctx.fillStyle='#e8e3d8';ctx.fillRect(-11,-12,22,3);  // 背部阴影
  /* 黑色肩带（熊猫特征，绕身体一圈的黑色） */
  ctx.fillStyle='#2c2828';ctx.fillRect(-11,-12,4,11);ctx.fillRect(7,-12,4,11);
  /* 白肚皮 */
  ctx.fillStyle='#fbf9f4';ctx.fillRect(-5,-8,10,6);
  /* 圆圆的短尾巴 */
  ctx.fillStyle='#2c2828';ctx.beginPath();ctx.arc(-12,0,2.5,0,6.2832);ctx.fill();
  /* 头（白色圆脸，稍抬） */
  ctx.fillStyle='#f4f1ea';ctx.fillRect(-9,-25,17,13);
  /* 黑色圆耳朵 */
  ctx.fillStyle='#23201f';
  ctx.beginPath();ctx.arc(-7,-26,3,0,6.2832);ctx.fill();
  ctx.beginPath();ctx.arc(8,-26,3,0,6.2832);ctx.fill();
  /* 黑眼圈（斜椭圆） */
  ctx.fillStyle='#23201f';
  ctx.fillRect(-7,-21,5,5);ctx.fillRect(2,-21,5,5);
  /* 眼睛（眼圈内白点高光） */
  ctx.fillStyle='#fff';ctx.fillRect(-6,-20,1.5,1.5);ctx.fillRect(3,-20,1.5,1.5);
  /* 黑鼻子 + 张开的嘴（开心笑） */
  ctx.fillStyle='#23201f';ctx.fillRect(-1,-16.5,3,1.5);
  ctx.fillStyle='#5c3a35';                             // 张开的嘴
  ctx.fillRect(-1.5,-14.5,4,2.5);
  ctx.fillStyle='#c9526a';ctx.fillRect(0,-13,1.5,1);   // 小舌头
  ctx.restore();

  /* 表情包：每 5 秒（真实时间）头顶浮现一个，颜色加重；出现后停留 1 秒再淡出 */
  const now=performance.now();
  const cyc=5000;                                       // 每 5 秒一个周期
  const t=now%cyc;                                       // 周期内经过时间（ms）
  const HOLD=1000;                                       // 停留 1 秒
  const FADE=400;                                        // 淡出 0.4 秒
  const SHOW=500;                                        // 弹入 0.5 秒
  if(t < SHOW+HOLD+FADE){
    const ec=Math.floor(now/cyc);
    const emo=EMOJIS[ec%EMOJIS.length];
    /* 透明度：弹入后完全显示，停留 1 秒，再淡出 */
    let alpha=1;
    if(t<SHOW) alpha=t/SHOW;                              // 淡入
    else if(t>=SHOW+HOLD) alpha=Math.max(0,1-(t-SHOW-HOLD)/FADE);  // 淡出
    /* 高度：停留期间固定，淡入淡出时轻微上升 */
    const ey=y-38 - (t<SHOW? (1-t/SHOW)*6 : (t>=SHOW+HOLD? (t-SHOW-HOLD)/FADE*8 : 0));
    const escale=0.7+0.3*Math.min(1,t/SHOW*3);
    ctx.save();ctx.globalAlpha=alpha;
    ctx.translate(x,ey);ctx.scale(escale,escale);
    ctx.font='bold 15px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
    /* 颜色加重：先画深色描边阴影，再叠一层正文，让表情更浓郁醒目 */
    ctx.lineWidth=3;ctx.strokeStyle='rgba(60,40,90,.9)';ctx.lineJoin='round';
    ctx.strokeText(emo,0,0);
    ctx.fillStyle='#fff';
    ctx.fillText(emo,0,0);
    ctx.fillText(emo,0,0);                               // 叠画一遍加深颜色
    ctx.restore();
  }
}
function drawAdventureFrame(dt){
  if(!gameWorld||gameWorld.id!==adventureFocus){gameWorld=buildAdventureWorld(ISL[adventureFocus]);placeExplorerAtStart();resetNearbyPrompt();}
  stepExplorer(dt);
  updateNearbyPrompt();
  const smooth=1-Math.pow(.001,dt);gameCam.x=lerp(gameCam.x,explorer.x,smooth);gameCam.y=lerp(gameCam.y,explorer.y,smooth);
  const halfW=VW/(2*gameZoom),halfH=VH/(2*gameZoom);
  gameCam.x=clamp(gameCam.x,Math.min(halfW,GAME_W/2),Math.max(GAME_W-halfW,GAME_W/2));
  gameCam.y=clamp(gameCam.y,Math.min(halfH,GAME_H/2),Math.max(GAME_H-halfH,GAME_H/2));
  ctx.setTransform(DPR,0,0,DPR,0,0);ctx.imageSmoothingEnabled=false;ctx.fillStyle='#062f2d';ctx.fillRect(0,0,VW,VH);
  ctx.setTransform(DPR*gameZoom,0,0,DPR*gameZoom,DPR*(VW/2-gameCam.x*gameZoom),DPR*(VH/2-gameCam.y*gameZoom));
  ctx.drawImage(gameWorld.terrain,0,0);
  const vx0=gameCam.x-halfW-80,vx1=gameCam.x+halfW+80,vy0=gameCam.y-halfH-90,vy1=gameCam.y+halfH+20;
  let avatarDrawn=false;
  for(const o of gameWorld.objects){
    if(!avatarDrawn&&o.y>explorer.y){drawGameAdventurer();avatarDrawn=true;}
    if(o.x<vx0||o.x>vx1||o.y<vy0||o.y>vy1)continue;
    drawAdventureObject(o);
  }
  if(!avatarDrawn)drawGameAdventurer();
  ctx.setTransform(DPR,0,0,DPR,0,0);ctx.imageSmoothingEnabled=true;
  const shade=ctx.createRadialGradient(VW/2,VH*.48,Math.min(VW,VH)*.22,VW/2,VH*.5,Math.max(VW,VH)*.88);
  shade.addColorStop(0,'rgba(0,0,0,0)');shade.addColorStop(1,'rgba(0,5,7,.38)');ctx.fillStyle=shade;ctx.fillRect(0,0,VW,VH);
  const fade=clamp((performance.now()-gameFadeAt)/520,0,1);if(fade<1){ctx.fillStyle='rgba(0,0,0,'+(1-fade).toFixed(3)+')';ctx.fillRect(0,0,VW,VH);}
}
function stepExplorer(dt){
  if(!gameMode||!adventureFocus)return;
  let dx=moveAxis.x,dy=moveAxis.y,strength=Math.min(1,Math.hypot(dx,dy));
  if(strength>0.001) explorer.target=null;
  else{
    dx=(moveKeys.has('right')?1:0)-(moveKeys.has('left')?1:0);
    dy=(moveKeys.has('down')?1:0)-(moveKeys.has('up')?1:0);
    strength=dx||dy?1:0;
    if(strength) explorer.target=null;
    else if(explorer.target){
      dx=explorer.target.x-explorer.x;dy=explorer.target.y-explorer.y;
      if(Math.hypot(dx,dy)<1.2){explorer.target=null;dx=dy=0;}
      else strength=1;
    }
  }
  const len=Math.hypot(dx,dy); explorer.moving=len>0.001;
  if(!explorer.moving)return;
  dx/=len;dy/=len;explorer.facing=dx<0?-1:1;explorer.step+=dt*11;
  const speed=225*strength, nx=explorer.x+dx*speed*dt, ny=explorer.y+dy*speed*dt;
  if(gameCanWalk(nx,ny)){
    explorer.x=nx;explorer.y=ny;gameCam.x=lerp(gameCam.x,explorer.x,.12);gameCam.y=lerp(gameCam.y,explorer.y,.12);
  }else if(explorer.target){explorer.target=null;}
}
function drawExplorer(){
  const bob=explorer.moving?Math.round(Math.sin(explorer.step)*0.65):0;
  const x=Math.round(explorer.x),y=Math.round(explorer.y);
  ctx.fillStyle='rgba(10,14,20,.38)';ctx.beginPath();ctx.ellipse(x,y+0.2,2.7,1.15,0,0,6.2832);ctx.fill();
  ctx.save();ctx.translate(x,y+bob);ctx.scale(explorer.facing,1);
  ctx.fillStyle='#201b2d';ctx.fillRect(-2,-8,4,2);ctx.fillRect(-2.5,-6,5,4);ctx.fillRect(-2.5,-2,5,4);
  ctx.fillStyle='#4b302d';ctx.fillRect(-2,-9,4,2);ctx.fillStyle='#f1c49a';ctx.fillRect(-1.5,-6,3,3);
  ctx.fillStyle='#f1a85f';ctx.fillRect(-2,-3,4,4);ctx.fillStyle='#6d4bc2';ctx.fillRect(1.5,-2,1.5,3);
  ctx.fillStyle='#30283e';ctx.fillRect(-2,-0.5,1.5,3);ctx.fillRect(0.5,-0.5,1.5,3);
  ctx.fillStyle='#f7e6c7';ctx.fillRect(-2.2,2.2,1.8,0.8);ctx.fillRect(0.4,2.2,1.8,0.8);
  ctx.restore();
}

let adventureFocus=null;
/* ② 命中判定：按"画出来的那块"算（宽 × 从脚底往上 hitH 的那一整块），
   不再只看脚底那一点 —— 点大书/大树的上半部分也能打开。 */
function adventureHitBox(o){
  const w=o.hitW||(34*(o.s||1)), h=o.hitH||(46*(o.s||1));
  return {x0:o.x-w*0.5, x1:o.x+w*0.5, y0:o.y-h, y1:o.y+6*(o.s||1)};
}
function adventurePick(gx,gy){
  if(!gameWorld) return null;
  let best=null,bd=1e9;
  for(const o of gameWorld.objects){
    if(!o.entryId&&!o.islandLink) continue;
    const b=adventureHitBox(o);
    if(gx<b.x0||gx>b.x1||gy<b.y0||gy>b.y1) continue;
    const d=Math.hypot(gx-o.x,gy-o.y);
    if(d<bd){bd=d;best=o;}
  }
  return best;
}
function adventureNearby(){
  if(!gameWorld) return null;
  const padding=48,px=explorer.x,py=explorer.y;
  let best=null,bestD=1e9;
  for(const o of gameWorld.objects){
    if(!o.entryId&&!o.islandLink) continue;
    const b=adventureHitBox(o);
    if(px<b.x0-padding||px>b.x1+padding||py<b.y0-padding||py>b.y1+padding) continue;
    const d=Math.hypot(px-o.x,py-(o.y+(o.hitH||48)*0.08));
    if(d<bestD){bestD=d;best=o;}
  }
  return best;
}
let nearbyPromptKey='',nearbyDismissedKey='',nearbyPromptPick=null;
function nearbyKeyFor(o){
  return o&&o.entryId?('entry:'+o.entryId):o&&o.islandLink?('island:'+adventureFocus):'';
}
function hideNearbyPrompt(reset){
  const card=$('nearbyCard');if(card){card.classList.remove('show');card.setAttribute('aria-hidden','true');}
  nearbyPromptPick=null;
  if(reset){nearbyPromptKey='';nearbyDismissedKey='';}
}
function resetNearbyPrompt(){hideNearbyPrompt(true);}
function showNearbyPrompt(o,key){
  const card=$('nearbyCard'),island=ISL[adventureFocus];if(!card||!island)return;
  let kicker='靠近记忆',title='',meta='',text='',button='查看完整详情';
  if(o.entryId){
    const entry=ensureRegion(adventureFocus).entries.find(item=>item.id===o.entryId);
    if(!entry)return;
    const kind=KIND_META[entry.kind||'memory']||KIND_META.memory;
    const isMusic=(entry.kind||'memory')==='music';
    kicker=readOnly?'好友记忆 · 靠近提示':(isMusic?'音乐 · 靠近提示':'记忆 · 靠近提示');
    title=entry.title||'(未命名)';
    meta=(isMusic?'🎵 音乐 · ':(kind.icon+' '+kind.name+' · '))+fmtDate(entry.date)+' · '+regionName(island);
    text=isMusic?'点击播放这首歌，让旋律在爱乐之城里响起。':String(entry.text||'').replace(/\s+/g,' ').trim();
    if(text.length>132)text=text.slice(0,132)+'…';
    button=isMusic?'▶ 播放这首音乐':'查看完整详情与互动';
  }else{
    const count=ensureRegion(adventureFocus).entries.length;
    kicker='岛屿入口 · 靠近提示';
    title=regionName(island);
    meta=island.emoji+' '+regionTag(island)+' · '+count+' 段记忆';
    text=count?'这里收着你在岛上留下的记忆，点开可以查看全部内容。':'这座岛还很安静，写下第一段记忆后，它就会出现在这里。';
    button='查看这座岛的全部记忆';
  }
  $('nearbyKicker').textContent=kicker;$('nearbyTitle').textContent=title;$('nearbyMeta').textContent=meta;$('nearbyText').textContent=text;
  const open=$('nearbyOpen');open.textContent=button;
  open.onclick=()=>{
    if(o.entryId){
      const ent=ensureRegion(adventureFocus).entries.find(item=>item.id===o.entryId);
      if(ent&&(ent.kind||'memory')==='music'){ Music.play(ent); }
      else openDetail(adventureFocus,o.entryId);
    }
    else openRegion(adventureFocus);
  };
  nearbyPromptPick=o;nearbyPromptKey=key;
  card.classList.add('show');card.setAttribute('aria-hidden','false');
}
function updateNearbyPrompt(){
  if(!gameMode||!gameWorld){hideNearbyPrompt(true);return;}
  const o=adventureNearby(),key=nearbyKeyFor(o);
  if(key===nearbyPromptKey)return;
  nearbyPromptKey=key;
  if(!key){nearbyDismissedKey='';hideNearbyPrompt(false);return;}
  if(key===nearbyDismissedKey){hideNearbyPrompt(false);return;}
  showNearbyPrompt(o,key);
}

function handleAdventureTap(cx,cy){
  if(!gameWorld)return;
  const rect=cvs.getBoundingClientRect(),gx=(cx-rect.left-VW/2)/gameZoom+gameCam.x,gy=(cy-rect.top-VH/2)/gameZoom+gameCam.y;
  const pick=adventurePick(gx,gy);
  if(pick){
    if(pick.entryId){
      const ent=ensureRegion(adventureFocus).entries.find(item=>item.id===pick.entryId);
      if(ent&&(ent.kind||'memory')==='music'){ Music.play(ent); return; }
      openDetail(adventureFocus,pick.entryId);return;
    }
    /* 招牌大物件：打开这座岛的记忆（没有记忆就提示去写一段） */
    const r=ensureRegion(adventureFocus);
    if(!r.entries.length){ toast('这座岛还没有记忆 · 点「记一段」写下来，它就会出现在路旁'); }
    openRegion(adventureFocus);
    return;
  }
  if(gameCanWalk(gx,gy))explorer.target={x:gx,y:gy};
}
/* ① 把小人放到"最早那条记忆"旁；这座岛还没有记忆时，站回原来的路口默认点 */
function placeExplorerAtStart(){
  const sp=(gameWorld&&gameWorld.startSpot)||null;
  explorer.x=sp?sp.x:45*GAME_TILE;
  explorer.y=sp?sp.y:36*GAME_TILE;
  explorer.target=null; explorer.moving=false; explorer.step=0; explorer.facing=1;
  gameCam.x=explorer.x; gameCam.y=explorer.y;
}
function startAdventure(id){
  const island=ISL[id];if(!island)return;
  adventureFocus=id;gameWorld=buildAdventureWorld(island);gameMode=true;gameZoom=1.05;gameFadeAt=performance.now();
  placeExplorerAtStart();moveKeys.clear();resetJoystick();resetNearbyPrompt();
  document.body.classList.add('island-mode');
  document.body.classList.toggle('music-mode', id==='music');
  $('btnBack').classList.add('show');$('adventureName').textContent=regionName(island);
  const nEnt=ensureRegion(id).entries.length;
  $('adventureStats').textContent=(nEnt?('已带你到最早的一条记忆旁 · '):'')+nEnt+' 段记忆 · 点击或按住任意位置拖动 / WASD / 点击地面移动 · 靠近发光物件自动显示';
  $('hint').textContent='点击或按住任意位置拖动 / WASD 移动 · 点击地面行走 · 靠近发光物件自动显示详情';closeRegion();$('scrim').classList.remove('on');
}
function exitAdventure(){
  gameMode=false;adventureFocus=null;gameWorld=null;moveKeys.clear();resetJoystick();resetNearbyPrompt();explorer.target=null;document.body.classList.remove('island-mode');document.body.classList.remove('music-mode');$('btnBack').classList.remove('show');
  Music.stop();
  const wc=worldCenter();setTarget(wc[0],wc[1],fitZoom,true);$('hint').textContent='拖动探索 · 滚轮 / 双指缩放 · 点击岛屿进入';
}
$('rsExplore').onclick=()=>{if(activeRegion)startAdventure(activeRegion);};$('btnBack').onclick=exitAdventure;
const movePad=$('movePad'),joystickKnob=$('joystickKnob');
function setJoystickPosition(dx,dy){
  joystickKnob.style.setProperty('--jx',dx.toFixed(1)+'px');joystickKnob.style.setProperty('--jy',dy.toFixed(1)+'px');
}
function placeJoystickAt(clientX,clientY){
  const rect=movePad.getBoundingClientRect(),radius=(rect.width||132)/2+8;
  const safe=Math.min(radius,Math.min(window.innerWidth,window.innerHeight)/2);
  const x=clamp(clientX,safe,Math.max(safe,window.innerWidth-safe));
  const y=clamp(clientY,safe,Math.max(safe,window.innerHeight-safe));
  movePad.style.left=x+'px';movePad.style.top=y+'px';
}
function updateJoystick(e){
  if(e.pointerId!==joystickPointer)return;
  const rect=movePad.getBoundingClientRect(),cx=rect.left+rect.width/2,cy=rect.top+rect.height/2;
  let dx=e.clientX-cx,dy=e.clientY-cy;
  const maxTravel=Math.max(28,rect.width/2-25),raw=Math.hypot(dx,dy),limit=Math.min(raw,maxTravel);
  if(raw>0){dx=dx/raw*limit;dy=dy/raw*limit;}
  setJoystickPosition(dx,dy);
  const magnitude=raw/maxTravel,dead=0.14;
  if(magnitude<=dead){moveAxis.x=0;moveAxis.y=0;return;}
  if(magnitude>0.18)joystickMoved=true;
  const strength=Math.min(1,(magnitude-dead)/(1-dead));
  if(raw>0){moveAxis.x=dx/limit*strength;moveAxis.y=dy/limit*strength;}
  explorer.target=null;
}
function beginJoystick(e){
  if(!gameMode||joystickPointer!==null)return false;
  if(e.button!==undefined&&e.button!==0)return false;
  joystickPointer=e.pointerId;joystickMoved=false;
  placeJoystickAt(e.clientX,e.clientY);
  movePad.classList.add('active');
  updateJoystick(e);
  return true;
}
function resetJoystick(){
  joystickPointer=null;joystickMoved=false;moveAxis.x=0;moveAxis.y=0;
  if(movePad)movePad.classList.remove('active');
  if(joystickKnob)setJoystickPosition(0,0);
}
$('nearbyClose').onclick=()=>{nearbyDismissedKey=nearbyPromptKey;hideNearbyPrompt(false);};
window.addEventListener('keydown',e=>{if(!gameMode)return;const dirs={ArrowUp:'up',w:'up',W:'up',ArrowDown:'down',s:'down',S:'down',ArrowLeft:'left',a:'left',A:'left',ArrowRight:'right',d:'right',D:'right'},dir=dirs[e.key];if(dir){e.preventDefault();moveKeys.add(dir);explorer.target=null;}if(e.key==='Escape')exitAdventure();});
window.addEventListener('keyup',e=>{const dirs={ArrowUp:'up',w:'up',W:'up',ArrowDown:'down',s:'down',S:'down',ArrowLeft:'left',a:'left',A:'left',ArrowRight:'right',d:'right',D:'right'};if(dirs[e.key])moveKeys.delete(dirs[e.key]);});window.addEventListener('blur',()=>{moveKeys.clear();resetJoystick();});
function toast(msg){
  const t=$('toast');t.textContent=msg;t.classList.add('show');
  clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove('show'),2100);
}
function buildChips(){
  const box=$('chips');box.innerHTML='';
  for(const i of ISLANDS){
    const d=document.createElement('div');
    d.className='chip';d.style.setProperty('--c',i.color);
    d.innerHTML='<span class="e">'+i.emoji+'</span><span class="t">'+regionName(i)+'</span>';
    d.onclick=()=>{focusIsland(i,true);};
    d.dataset.id=i.id;
    box.appendChild(d);
  }
}
function syncChips(){
  const box=$('chips');
  [...document.querySelectorAll('.chip')].forEach(c=>{
    const on=c.dataset.id===activeRegion;
    c.classList.toggle('on',on);
    if(on&&box) box.scrollLeft=c.offsetLeft-(box.clientWidth-c.offsetWidth)/2;   // 岛多了自动滚到选中项
  });
}
function focusIsland(i,openSheet){
  setTarget(i.x,i.y,Math.max(cam.zoom,1.15),true);
  activeRegion=i.id;syncChips();
  if(openSheet){setTimeout(()=>openRegion(i.id),420);}
}
function openRegion(id){
  const i=ISL[id];activeRegion=id;syncChips();
  const r=ensureRegion(id);
  $('rsBadge').textContent=i.emoji;
  $('rsBadge').style.setProperty('--c',i.color);
  $('rsName').textContent=regionName(i);
  $('rsDesc').textContent=regionTag(i)+' · '+i.desc;
  // 成长统计：这座岛上积累了什么
  const st=$('rsStats'); st.innerHTML=''; st.style.setProperty('--c',i.color);
  const counts=[['⭐',i.starCount||0,'颗星星'],['🌱',i.goalCount||0,'棵成长树'],
                ['🏔',i.tripCount||0,'处风景'],['🎵',i.musicCount||0,'段旋律']];
  const reviews=r.entries.filter(e=>(e.kind||'memory')==='recall').length;
  counts.filter(c=>c[1]>0).forEach(c=>{
    const b=document.createElement('b');b.className='c';
    b.textContent=c[0]+' '+c[1]+' '+c[2];st.appendChild(b);
  });
  if(reviews){const b=document.createElement('b');b.className='c';b.textContent='✦ 被回顾 '+reviews+' 次';st.appendChild(b);}
  const eco=i.ecology;
  if(eco&&eco.count){
    const b=document.createElement('b');b.className='c eco';b.style.setProperty('--ec',eco.color||'#8f7cff');
    b.textContent=eco.icon+' '+eco.count+' 只 '+eco.name;st.appendChild(b);
  }
  if(!counts.some(c=>c[1]>0)&&!reviews){
    const b=document.createElement('b');b.textContent='这里还什么都没有';st.appendChild(b);
  }
  $('rsDel').style.display=(i.custom&&!readOnly)?'block':'none';
  const list=$('rsList');list.innerHTML='';
  if($('rsAdd')) $('rsAdd').style.display=readOnly?'none':'';   // 只读（好友世界）：藏起「在这里记一段」
  if(!r.entries.length){
    list.innerHTML='<div class="empty">这里还很安静。<br>写下第一段，岛上就会多出点什么。</div>';
  }else{
    r.entries.slice().sort((a,b)=>new Date(b.date)-new Date(a.date)).forEach(e=>{
      const d=document.createElement('div');d.className='entry';
      const has=e.images&&e.images.length, kd=KIND_META[e.kind||'memory']||KIND_META.memory;
      d.innerHTML=(has?'<img class="thumb" src="'+e.images[0]+'" alt="">'
                     :'<div class="thumb ph">'+kd.icon+'</div>')
        +'<div class="meta"><h3></h3><p></p><div class="d"></div></div>';
      d.querySelector('h3').textContent=(e.kind==='recall'?'✦ ':'')+(e.title||'(未命名)');
      d.querySelector('p').textContent=e.text||'';
      d.querySelector('.d').textContent=kd.icon+' '+kd.name+' · '+fmtDate(e.date)+(has?' · '+e.images.length+' 张图':'');
      d.onclick=()=>openDetail(id,e.id);
      list.appendChild(d);
    });
  }
  $('regionSheet').classList.add('open');
  $('editSheet').classList.remove('open');
  $('hint').style.opacity=0;
  renderIslandFeature(i,r);
}
/* 每座岛都有一件能做的小事和一个藏在岛上的原创彩蛋。 */
function islandFeatureMeta(i){
  const meta={
    harbor:{kicker:'HARBOR LIGHT',title:'港湾灯语',copy:'灯塔会把最早的一段陪伴照出来。有时，先被看见的才是最值得靠近的。',action:'循着最早的灯'},
    knowledge:{kicker:'KNOWLEDGE MAP',title:'知识星图',copy:'从两段学习里寻找同一颗词星，让看似无关的知识互相照亮。',action:'点亮知识星图'},
    memory:{kicker:'ECHO FIREFLY',title:'回声萤火',copy:'同一月份、不同年份的两段记忆，会在森林里发生一次短暂回声。',action:'点燃回声萤火'},
    creation:{kicker:'IDEA PRISM',title:'灵感棱镜',copy:'把最近的作品放进棱镜，折出一张属于这座岛的原创灵感卡。',action:'折射一束灵感'},
    future:{kicker:'LETTER TO LATER',title:'未来信箱',copy:'给未来的自己写一句话，封存到选定的日子。时间到之前，岛会替你保管。',action:'封存未来'},
    music:{kicker:'RHYTHM GARDEN',title:'节拍花园',copy:'从爱乐之城里挑一段旋律，让音乐暂时接管这片海。',action:'让花园响起'}
  }[i.id];
  if(meta) return meta;
  const themes={
    garden:{kicker:'GARDEN WHISPER',title:'花语温室',copy:'第一朵花记得你最初为什么想造这座岛。',action:'闻一闻第一朵花'},
    valley:{kicker:'VALLEY BELL',title:'山谷回铃',copy:'山谷会把最早的一段声音送回来，像一封慢慢抵达的信。',action:'摇响山谷铃'},
    market:{kicker:'MARKET GLOW',title:'灯市长街',copy:'灯市只在有人想起时开张。第一盏灯亮起，旧故事就重新营业。',action:'点亮第一盏灯'},
    star:{kicker:'STAR DECK',title:'星光甲板',copy:'把最近的一段愿望放到甲板上，让星轨替你校准方向。',action:'校准星轨'},
    grove:{kicker:'GROVE HOLLOW',title:'幽林树洞',copy:'树洞收藏未说完的话。打开它，它只回答一次。',action:'叩响树洞'}
  }[i.theme]||{kicker:'YOUR ISLAND',title:'岛心回声',copy:'这座岛从第一段记忆开始有了自己的回声。',action:'听一听岛心'};
  return themes;
}
function islandSecretFor(i,r){
  const n=(r&&r.entries?r.entries.length:0)||0;
  const secrets={
    harbor:'灯塔转完一圈，会把当天最短的一句想念排在最前面。',
    knowledge:'知识岛的纸页在无人学习时会交换标点，像在悄悄讨论一个答案。',
    memory:'回声萤火其实不照亮道路，它们只照亮那些本来就被你记得的人。',
    creation:'颜料干了以后，创作岛会在背面多画一条你看不见的线。',
    future:'未来之岛的轨道偶尔会经过今天，所以今天的愿望也算数。',
    music:'爱乐之城安静下来时，海面会沿着最后一首音乐的心跳起伏。'
  };
  if(secrets[i.id]) return secrets[i.id];
  const custom={
    garden:'花盆里偶尔会长出一片不是花的叶子，那是岛屿在练习自己的签名。',
    valley:'山谷最深处的回音比原声多一个字，那个字只有造岛的人听得见。',
    market:'灯市收摊后，总有一盏小灯不灭，留给晚归的故事。',
    star:'星光台会把没说完的愿望折成一颗很暗的星，等以后再亮。',
    grove:'幽林里的树洞每天都在换位置，只认脚步声，不认地图。'
  };
  const header=n?('这座岛收下了 '+n+' 段生活。'):'这座岛还在等第一段生活。';
  return header+(custom[i.theme]||'当海风绕过岛缘，它会替你把一段悄悄话藏进颜色里。');
}
function featureEntryList(entries,islandId,limit){
  return (entries||[]).slice(0,limit||3).map(function(e){return {islandId:islandId,entry:e};});
}
function featureKnowledgePair(entries){
  const tokenize=function(e){
    const text=String((e&&e.title)||'')+' '+String((e&&e.text)||'');
    const out=[];
    (text.toLowerCase().match(/[a-z0-9]{3,}/g)||[]).forEach(function(x){out.push(x)});
    (text.match(/[\u4e00-\u9fa5]{2,}/g)||[]).forEach(function(seg){
      if(seg.length<=5) out.push(seg);
      for(let k=0;k<seg.length-1;k++) out.push(seg.slice(k,k+2));
    });
    return new Set(out);
  };
  let pair=null,best=0;
  for(let a=0;a<entries.length;a++){
    const ta=tokenize(entries[a]);
    for(let b=a+1;b<entries.length;b++){
      const tb=tokenize(entries[b]);let score=0;
      ta.forEach(function(x){if(tb.has(x))score++;});
      if(score>best){best=score;pair=[entries[a],entries[b]];}
    }
  }
  return pair;
}
function featureEchoPair(entries){
  const sorted=(entries||[]).slice().sort(function(a,b){return new Date(a.date)-new Date(b.date)});
  let pair=null,best=999;
  for(let a=0;a<sorted.length;a++){
    const da=new Date(sorted[a].date);
    for(let b=a+1;b<sorted.length;b++){
      const db=new Date(sorted[b].date);
      const gap=Math.abs(db.getFullYear()-da.getFullYear());
      if(da.getMonth()===db.getMonth()&&gap>0&&gap<best){best=gap;pair=[sorted[a],sorted[b]];}
    }
  }
  if(pair) return pair;
  if(sorted.length>=2) return [sorted[0],sorted[sorted.length-1]];
  return null;
}
function renderIslandFeature(i,r){
  const box=$('rsFeature'); if(!box) return;
  box.innerHTML=''; box.style.setProperty('--fc',i.color||'#8f7cff');
  const meta=islandFeatureMeta(i);
  const kicker=document.createElement('div');kicker.className='feature-kicker';kicker.textContent=meta.kicker;
  const title=document.createElement('h3');title.className='feature-title';title.textContent=meta.title;
  const copy=document.createElement('p');copy.className='feature-copy';copy.textContent=meta.copy;
  const tools=document.createElement('div');tools.className='feature-tools';
  const result=document.createElement('div');result.className='feature-result';
  function showResult(message,items){
    result.innerHTML='';
    const p=document.createElement('div');p.textContent=message;result.appendChild(p);
    if(items&&items.length){
      const wrap=document.createElement('div');wrap.className='feature-pair';
      items.forEach(function(item){
        const b=document.createElement('button');b.type='button';
        const label=document.createElement('b');label.textContent=item.entry.title||'(未命名)';
        const sub=document.createElement('span');sub.textContent=fmtDate(item.entry.date)+' · '+regionName(ISL[item.islandId]||i);
        b.appendChild(label);b.appendChild(sub);b.onclick=function(){closeRegion();setTimeout(function(){openDetail(item.islandId,item.entry.id);},90);};
        wrap.appendChild(b);
      });
      result.appendChild(wrap);
    }
    result.classList.add('show');
  }
  const entries=(r.entries||[]).slice().sort(function(a,b){return new Date(a.date)-new Date(b.date)});
  const action=document.createElement('button');action.type='button';action.className='feature-action';action.textContent=meta.action;
  if(i.id==='music'){
    action.disabled=!entries.length;
    action.onclick=function(){
      const music=entries.filter(function(e){return (e.kind||'memory')==='music'});
      if(!music.length){showResult('爱乐之城还没有音乐。导入第一首后，节拍花园就会开花。');return;}
      const pick=music[(Math.floor(T*10)+music.length)%music.length];
      Music.play(pick);
      showResult('正在播放「'+(pick.title||pick.audioName||'音乐')+'」。环境音会在这一刻安静退场，音乐结束后再回来。');
    };
  }else if(i.id==='future'){
    action.textContent='查看未来信箱';
    action.onclick=function(){
      const cap=r.capsule;
      if(!cap){showResult('信箱还是空的。写下给未来的一句话，再选择开启的时间。');return;}
      if(Date.now()>=new Date(cap.openAt).getTime()) showResult('未来的你已经可以读到这段话：\n\n'+(cap.text||''));
      else showResult('这句话会在 '+fmtDate(cap.openAt)+' 开启。信纸现在仍被岛上的星轨封存着。');
    };
  }else{
    action.onclick=function(){
      if(i.id==='harbor'){
        if(!entries.length){showResult('港湾的灯还亮着，但还没有一段陪伴被写下来。');return;}
        showResult('灯火落在最早的那一天。',featureEntryList([entries[0]],i.id,1));
      }else if(i.id==='knowledge'){
        const pair=featureKnowledgePair(entries);
        if(!pair){showResult(entries.length<2?'知识星图需要至少两段学习记录才能连成一条线。':'这些学习记录还没有交汇；再写下一点，新的词星就会靠过来。');return;}
        showResult('两条记录共享了同一颗知识星，它们被星图连在了一起。',featureEntryList(pair,i.id,2));
      }else if(i.id==='memory'){
        const pair=featureEchoPair(entries);
        if(!pair){showResult('回声萤火需要至少两段记忆才能辨认出时间里的回声。');return;}
        const sameMonth=new Date(pair[0].date).getMonth()===new Date(pair[1].date).getMonth();
        showResult(sameMonth?'同一月份的回声被重新点亮了。':'还没有同月重逢的碎片，萤火先替你照亮相隔最远的两段。',featureEntryList(pair,i.id,2));
      }else if(i.id==='creation'){
        const latest=entries[entries.length-1];
        const motifs=['一条只在黄昏出现的路','一种用声音保存下来的颜色','一扇记得所有敲门声的门','一场没有观众却持续很久的演出','一张会随心情改变天气的地图','一封从十年前寄到明天的信'];
        const seed=(latest?String(latest.title||'').length:0)+Math.floor(T*0.7)+entries.length;
        const prompt=latest?('以「'+(latest.title||'最近的作品')+'」为起点，加入'+motifs[seed%motifs.length]+'。'):('先创作一个小片段：'+motifs[seed%motifs.length]+'。');
        showResult('灵感棱镜折出了一张新卡片：\n\n'+prompt);
      }else{
        if(!entries.length){showResult('岛心还在等待第一段生活。');return;}
        const pick=i.theme==='star'&&entries.length>1?entries[entries.length-1]:entries[0];
        showResult('岛心回响了一段属于这里的旧声音。',featureEntryList([pick],i.id,1));
      }
    };
  }
  const secret=document.createElement('button');secret.type='button';secret.className='feature-action soft';secret.textContent='发现彩蛋';
  secret.onclick=function(){
    showResult(islandSecretFor(i,r));
    if(!readOnly){ if(!state.islandSecrets) state.islandSecrets={}; if(!state.islandSecrets[i.id]){state.islandSecrets[i.id]=Date.now();saveState();} }
  };
  tools.appendChild(action);tools.appendChild(secret);
  box.appendChild(kicker);box.appendChild(title);box.appendChild(copy);box.appendChild(tools);
  if(i.id==='future'&&!readOnly){
    const form=document.createElement('div');form.className='feature-capsule';
    const input=document.createElement('input');input.type='text';input.maxLength=80;input.placeholder='写给未来的一句话';
    const wait=document.createElement('select');wait.setAttribute('aria-label','开启时间');
    [['30','1个月'],['180','半年'],['365','1年'],['1095','3年']].forEach(function(o){const op=document.createElement('option');op.value=o[0];op.textContent=o[1];wait.appendChild(op);});
    wait.style.cssText='border:1px solid rgba(255,255,255,.14);border-radius:9px;background:rgba(255,255,255,.05);color:#fff;padding:0 7px;font-size:11px';
    const save=document.createElement('button');save.type='button';save.textContent='封存';
    save.onclick=function(){const text=input.value.trim();if(!text){toast('先写一句给未来的话');return;}const days=Number(wait.value)||365;const openAt=new Date(Date.now()+days*86400000).toISOString();r.capsule={text:text,createdAt:new Date().toISOString(),openAt:openAt};if(saveState()){input.value='';showResult('未来信箱已封存。它会在 '+fmtDate(openAt)+' 开启。');}};
    form.appendChild(input);form.appendChild(wait);form.appendChild(save);box.appendChild(form);
  }
  box.appendChild(result);
}
function closeRegion(){ $('regionSheet').classList.remove('open'); activeRegion=null; syncChips(); }
function fmtDate(iso){
  const d=new Date(iso);
  return d.getFullYear()+'.'+String(d.getMonth()+1).padStart(2,'0')+'.'+String(d.getDate()).padStart(2,'0');
}
/* 好友互动：每条记忆单独保存点赞和评论，详情页每 7 秒同步一次。 */
let activeDetail=null, detailRefreshTimer=null, detailRefreshInFlight=0, detailMutationBusy=false, detailLoadVersion=0;
function detailViewerProfile(){
  const account=LocalAuth.current();
  if(!account) return null;
  return Cloud.profile||accountProfile(account);
}
function detailActorKey(profile){
  return String(profile&&(profile.id||profile.owner_id||profile.userId||profile.handle)||'');
}
function detailOwnerId(){
  if(Cloud.guest) return String(Cloud.guest.ownerId||'');
  return String(Cloud.user&&Cloud.user.id||'');
}
function fmtSocialTime(value){
  const stamp=Date.parse(value||'');
  if(!stamp) return '刚刚';
  const diff=Math.max(0,Date.now()-stamp);
  if(diff<60000) return '刚刚';
  if(diff<3600000) return Math.max(1,Math.floor(diff/60000))+' 分钟前';
  if(diff<86400000) return Math.max(1,Math.floor(diff/3600000))+' 小时前';
  if(diff<604800000) return Math.max(1,Math.floor(diff/86400000))+' 天前';
  const d=new Date(stamp), pad=n=>String(n).padStart(2,'0');
  return (d.getMonth()+1)+'月'+d.getDate()+'日 '+pad(d.getHours())+':'+pad(d.getMinutes());
}
function stopDetailAutoRefresh(){
  if(detailRefreshTimer){ clearInterval(detailRefreshTimer); detailRefreshTimer=null; }
}
function closeDetail(){
  stopDetailAutoRefresh();
  activeDetail=null;
  detailLoadVersion++;
  $('detail').classList.remove('open');
}
function buildMemorySocial(){
  const section=document.createElement('section'); section.className='memory-social';
  section.innerHTML='<div class="social-head"><div><div class="social-kicker">好友互动</div><div class="social-title">给这段记忆留个回应</div></div><div class="social-status">同步中…</div></div>'+
    '<div class="social-like-row"><button class="social-like" type="button"><span class="social-heart">♡</span><span class="social-like-label">点赞</span></button><div class="social-like-names">还没有人点赞</div></div>'+
    '<div class="social-comments-head"><span>评论</span><b class="social-comment-count">0</b></div><div class="social-comments"></div>'+
    '<div class="social-composer"><textarea class="social-comment-input" maxlength="500" rows="3" placeholder="写下你的评论…"></textarea><button class="social-send" type="button">发表评论</button></div>'+
    '<button class="social-login" type="button">登录后可以点赞和评论</button>';
  section.querySelector('.social-like').onclick=toggleDetailLike;
  section.querySelector('.social-send').onclick=submitDetailComment;
  section.querySelector('.social-login').onclick=()=>openAuth('login');
  section.querySelector('.social-comment-input').addEventListener('keydown',event=>{
    if((event.ctrlKey||event.metaKey)&&event.key==='Enter'){ event.preventDefault(); submitDetailComment(); }
  });
  return section;
}
function renderInteractionDoc(doc){
  if(!activeDetail) return;
  const section=$('detail').querySelector('.memory-social');
  if(!section) return;
  const profile=detailViewerProfile();
  const myKey=detailActorKey(profile);
  const likes=Array.isArray(doc&&doc.likes)?doc.likes.slice():[];
  const liked=!!myKey&&likes.some(item=>String(item.userId||item.handle||'')===myKey);
  const likeButton=section.querySelector('.social-like');
  likeButton.classList.toggle('on',liked);
  likeButton.disabled=!Cloud.user;
  likeButton.querySelector('.social-heart').textContent=liked?'♥':'♡';
  likeButton.querySelector('.social-like-label').textContent=liked?'已点赞':'点赞';
  const likeNames=section.querySelector('.social-like-names');
  if(!likes.length) likeNames.textContent='还没有人点赞';
  else{
    const names=likes.slice(-12).reverse().map(item=>String(item.nickname||item.handle||'好友'));
    likeNames.textContent=names.join('、')+(likes.length>12?' 等 '+likes.length+' 人赞过':' 赞过');
  }
  const comments=Array.isArray(doc&&doc.comments)?doc.comments.slice().sort((x,y)=>(Date.parse(x.createdAt||'')||0)-(Date.parse(y.createdAt||'')||0)):[];
  section.querySelector('.social-comment-count').textContent=String(comments.length);
  const list=section.querySelector('.social-comments'); list.textContent='';
  if(!comments.length){
    const empty=document.createElement('div'); empty.className='social-empty'; empty.textContent='还没有评论，说点什么吧'; list.appendChild(empty);
  }else{
    comments.forEach(comment=>{
      const row=document.createElement('div'); row.className='social-comment';
      const avatar=document.createElement('div'); avatar.className='social-avatar'; avatar.textContent=String(comment.avatar||'🌏').slice(0,8);
      const body=document.createElement('div'); body.className='social-comment-body';
      const meta=document.createElement('div'); meta.className='social-comment-meta';
      const actorKey=String(comment.userId||comment.handle||'');
      const name=document.createElement('b'); name.textContent=actorKey&&actorKey===myKey?'我':String(comment.nickname||comment.handle||'好友');
      const time=document.createElement('time'); time.textContent=fmtSocialTime(comment.createdAt);
      const text=document.createElement('div'); text.className='social-comment-text'; text.textContent=String(comment.text||'');
      meta.appendChild(name); meta.appendChild(time); body.appendChild(meta); body.appendChild(text); row.appendChild(avatar); row.appendChild(body); list.appendChild(row);
    });
  }
  const composer=section.querySelector('.social-composer'), login=section.querySelector('.social-login');
  composer.style.display=Cloud.user?'':'none'; login.style.display=Cloud.user?'none':'';
}
async function refreshDetailInteractions(options={}){
  if(!activeDetail||(!options.force&&detailRefreshInFlight)) return;
  const context={ownerId:activeDetail.ownerId,regionId:activeDetail.regionId,entryId:activeDetail.entryId,key:activeDetail.key};
  const version=++detailLoadVersion;
  detailRefreshInFlight++;
  const section=$('detail').querySelector('.memory-social');
  const status=section&&section.querySelector('.social-status');
  if(status&&!options.silent) status.textContent='同步中…';
  try{
    const doc=await Cloud.memoryInteractions(context.ownerId,context.regionId,context.entryId);
    if(!activeDetail||activeDetail.key!==context.key||version!==detailLoadVersion) return;
    renderInteractionDoc(doc);
    if(status) status.textContent='好友可见 · 自动更新';
  }catch(e){
    if(status) status.textContent='暂时无法同步';
  }finally{
    detailRefreshInFlight=Math.max(0,detailRefreshInFlight-1);
  }
}
async function toggleDetailLike(){
  if(!Cloud.user){ openAuth('login'); return; }
  if(!activeDetail||detailMutationBusy) return;
  const context={ownerId:activeDetail.ownerId,regionId:activeDetail.regionId,entryId:activeDetail.entryId,key:activeDetail.key};
  const section=$('detail').querySelector('.memory-social');
  const button=section&&section.querySelector('.social-like');
  const wasLiked=!!(button&&button.classList.contains('on'));
  detailMutationBusy=true; detailLoadVersion++;
  if(button) button.disabled=true;
  try{
    const doc=await Cloud.toggleMemoryLike(context.ownerId,context.regionId,context.entryId);
    if(activeDetail&&activeDetail.key===context.key){
      renderInteractionDoc(doc);
      const status=section.querySelector('.social-status'); if(status) status.textContent='刚刚更新';
      toast(wasLiked?'已取消点赞':'已点赞，好友都能看到');
    }
  }catch(e){ toast(e&&e.message||'点赞失败，请检查网络后重试'); }
  finally{ detailMutationBusy=false; if(button) button.disabled=!Cloud.user; }
}
async function submitDetailComment(){
  if(!Cloud.user){ openAuth('login'); return; }
  if(!activeDetail||detailMutationBusy) return;
  const section=$('detail').querySelector('.memory-social');
  const input=section&&section.querySelector('.social-comment-input'), button=section&&section.querySelector('.social-send');
  const text=String(input&&input.value||'').trim();
  if(!text){ toast('先写一句评论吧'); if(input) input.focus(); return; }
  const context={ownerId:activeDetail.ownerId,regionId:activeDetail.regionId,entryId:activeDetail.entryId,key:activeDetail.key};
  detailMutationBusy=true; detailLoadVersion++;
  if(button){ button.disabled=true; button.textContent='发布中…'; }
  try{
    const doc=await Cloud.addMemoryComment(context.ownerId,context.regionId,context.entryId,text);
    if(activeDetail&&activeDetail.key===context.key){
      if(input) input.value='';
      renderInteractionDoc(doc);
      const status=section.querySelector('.social-status'); if(status) status.textContent='刚刚更新';
      toast('评论已发布，好友都能看到');
    }
  }catch(e){ toast(e&&e.message||'评论发布失败，请检查网络后重试'); }
  finally{ detailMutationBusy=false; if(button){ button.disabled=false; button.textContent='发表评论'; } }
}
function startDetailAutoRefresh(){
  stopDetailAutoRefresh();
  detailRefreshTimer=setInterval(()=>{ if(!document.hidden&&activeDetail) refreshDetailInteractions({silent:true}); },7000);
}
function openDetail(id,eid){
  stopDetailAutoRefresh(); activeDetail=null; detailLoadVersion++;
  const i=ISL[id], r=ensureRegion(id), e=r.entries.find(x=>x.id===eid); if(!e)return;
  $('dtWhere').textContent=regionName(i)+' · '+fmtDate(e.date);
  const b=$('dtBody');b.innerHTML='';
  (e.images||[]).forEach(src=>{const im=document.createElement('img');im.className='shot';im.src=src;b.appendChild(im);});
  const kd=KIND_META[e.kind||'memory']||KIND_META.memory;
  const h=document.createElement('h2');h.textContent=e.title||'(未命名)';b.appendChild(h);
  const d=document.createElement('div');d.className='dt';d.textContent=kd.icon+' '+kd.name+' · '+fmtDate(e.date)+' · '+regionName(i);b.appendChild(d);
  if(e.kind==='recall'&&e.target){
    const tg=findEntry(e.target);
    const rl=document.createElement('div');rl.className='dt';
    rl.textContent='✦ 重新点亮了「'+(tg?tg.entry.title:'一段往事')+'」'+(tg?' · '+tg.island.name:'');
    b.appendChild(rl);
  }
  const t=document.createElement('div');t.className='tx';t.textContent=e.text||'';b.appendChild(t);
  if((e.kind||'memory')==='music'){
    const pb=document.createElement('button');pb.className='btn';pb.style.marginTop='18px';
    pb.textContent='▶ 播放这首音乐';
    pb.onclick=()=>Music.play(e);
    b.appendChild(pb);
  }
  if(!readOnly){
    const del=document.createElement('button');del.className='btn danger';del.style.marginTop='28px';
    del.textContent='从世界里删除这一条';
    del.onclick=()=>{
      if(!confirm('确认删除？它在这座岛上留下的痕迹会一起消失。'))return;
      if(e.audioStore==='idb'&&e.audioBlobId){ try{AudioStore.del(e.audioBlobId);}catch(err){} }
      r.entries=r.entries.filter(x=>x.id!==eid);
      saveState();refreshMarkers();closeDetail();openRegion(id);refreshHeader();toast('已删除');
    };
    b.appendChild(del);
  }
  const ownerId=detailOwnerId();
  activeDetail={ownerId,regionId:id,entryId:eid,key:[ownerId,id,eid].join('|')};
  const related=renderRelatedBlock(id,e);
  if(related) b.appendChild(related);
  b.appendChild(buildMemorySocial());
  $('detail').classList.add('open');
  startDetailAutoRefresh();
  refreshDetailInteractions({silent:false});
}
/* 编辑器 */
let editRegion='harbor', editImages=[], editTarget=null;
function openEditor(regionId){
  if(readOnly){ toast('这是好友的世界，只能查看'); return; }
  editRegion=regionId||activeRegion||'harbor';
  editImages=[]; editTarget=null;
  $('edTitle').value='';$('edText').value='';
  renderEditRegions();renderPicks();
  $('regionSheet').classList.remove('open');
  $('editSheet').classList.add('open');
  setTimeout(()=>{ try{$('edTitle').focus({preventScroll:true});}catch(e){$('edTitle').focus();} },320);
}
function renderEditRegions(){
  const box=$('editRegions');box.innerHTML='';
  for(const i of ISLANDS){
    const d=document.createElement('div');
    d.className='rg'+(i.id===editRegion?' on':'');
    d.style.setProperty('--c',i.color);
    d.innerHTML='<span>'+i.emoji+'</span><span>'+regionName(i)+'</span>';
    d.onclick=()=>{editRegion=i.id;editTarget=null;renderEditRegions();};
    box.appendChild(d);
  }
}
/* 记录类型已取消：界面与逻辑一并移除，所有新记录都是「记忆」。
   下面这张表只用于「显示」老数据里留下的类型图标，界面上不再给选择。 */
const KIND_META={
  memory:{icon:'⭐',name:'记忆'}, goal:{icon:'🌱',name:'目标'}, travel:{icon:'🏔',name:'旅行'},
  music:{icon:'🎵',name:'音乐'},  recall:{icon:'✦',name:'回顾'}
};
function renderPicks(){
  const box=$('edPicks');
  box.innerHTML='';
  editImages.forEach((src,idx)=>{
    const d=document.createElement('div');d.className='pick';
    d.innerHTML='<img src="'+src+'"><button class="x">×</button>';
    d.querySelector('.x').onclick=()=>{editImages.splice(idx,1);renderPicks();};
    box.appendChild(d);
  });
  const lb=document.createElement('label');lb.className='pick add';lb.setAttribute('for','fileIn');
  lb.innerHTML='<span>＋</span><span>'+(editImages.length?'继续加':'相册')+'</span>';
  box.appendChild(lb);
}
$('fileIn').addEventListener('change',async e=>{
  const files=[...e.target.files].filter(f=>f.type.startsWith('image/'));
  if(!files.length) return;
  toast('正在导入相册…');
  for(const f of files){
    try{ const src=await shrink(f); editImages.push(src); }catch(err){}
  }
  renderPicks(); e.target.value='';
  toast('已导入 '+files.length+' 张图片');
});
function shrink(file,max){
  max=max||760;
  return new Promise((res,rej)=>{
    const fr=new FileReader();
    fr.onload=()=>{
      const im=new Image();
      im.onload=()=>{
        let {width:w,height:h}=im;
        const k=Math.min(1,max/Math.max(w,h));
        const c=C(Math.max(1,w*k),Math.max(1,h*k)),g=GC(c);
        g.drawImage(im,0,0,c.width,c.height);
        res(c.toDataURL('image/jpeg',0.82));
      };
      im.onerror=rej; im.src=fr.result;
    };
    fr.onerror=rej; fr.readAsDataURL(file);
  });
}
/* 桌面拖拽 / 粘贴 */
const phone=document.getElementById('phone');
phone.addEventListener('dragover',e=>{e.preventDefault();});
phone.addEventListener('drop',async e=>{
  e.preventDefault();
  const files=[...(e.dataTransfer.files||[])].filter(f=>f.type.startsWith('image/'));
  if(!files.length)return;
  if(!$('editSheet').classList.contains('open')) openEditor();
  for(const f of files) { try{editImages.push(await shrink(f));}catch(err){} }
  renderPicks();toast('已导入 '+files.length+' 张图片');
});
window.addEventListener('paste',async e=>{
  const items=[...(e.clipboardData?.items||[])].filter(i=>i.type.startsWith('image/'));
  if(!items.length)return;
  if(!$('editSheet').classList.contains('open')) openEditor();
  for(const it of items){const f=it.getAsFile();if(f){try{editImages.push(await shrink(f));}catch(err){}}}
  renderPicks();toast('已粘贴图片');
});

/* 记录类型已取消：新写的每一条都是「记忆」，在岛上亮起一颗星星 */
function findEntry(eid){
  for(const i of ISLANDS){
    const r=state.regions[i.id]; if(!r) continue;
    const e=(r.entries||[]).find(x=>x.id===eid);
    if(e) return {island:i,entry:e};
  }
  return null;
}
function effectMeta(){
  const i=ISL[editRegion];
  const n=((state.regions[editRegion]&&state.regions[editRegion].entries)||[])
    .filter(e=>(e.kind||'memory')==='memory').length;
  return {ox:0.18, oy:-0.18, burst:i.color, msg:()=>'「'+regionName(i)+'」亮起第 '+n+' 颗星星 ⭐'};
}
$('edCancel').onclick=()=>{$('editSheet').classList.remove('open');};
$('edSave').onclick=()=>{
  if(readOnly){ toast('这是好友的世界，只能查看'); return; }
  const title=$('edTitle').value.trim(), text=$('edText').value.trim();
  if(!title&&!text&&!editImages.length){toast('写点什么再保存吧');return;}
  const r=ensureRegion(editRegion);
  const entry={id:'e'+Math.random().toString(36).slice(2,9),
    kind:'memory', target:null, bornAt:Date.now(),
    title:title||(text.slice(0,16)||'记忆'), text,
    date:new Date().toISOString(), images:editImages.slice()};
  r.entries.push(entry);
  if(!saveState()) return;
  refreshMarkers(); refreshHeader();
  if(gameMode) gameWorld=null;      // 岛内新写的记忆：重建岛屿地图，新物件立刻出现在路旁（排在已有之后）
  $('editSheet').classList.remove('open');
  closeAll();
  const i=ISL[editRegion];
  // 岛已经在画面里就直接原地庆祝；不在就切过去，保证演出始终对准岛心
  const scr=w2s(i.x,i.y);
  const onScreen=scr[0]>70&&scr[0]<VW-70&&scr[1]>70&&scr[1]<VH-70;
  if(!onScreen) setTarget(i.x,i.y,Math.max(cam.tz,1.3),false);
  const fx=effectMeta();
  burst(i.x+fx.ox*i.r, i.y+fx.oy*i.r, fx.burst);
  // 全屏演出：闪光 + 冲击波 + 光束 + 满屏碎光 + 庆祝卡片
  celebrate(i, 'memory', {
    burst:fx.burst,
    title:entry.title,
    sub:regionName(i)+' · 记忆 · '+fx.msg()
  });
  const relCount=attachRelations([{entry:entry,islandId:editRegion}]);
  if(relCount) saveState();
  setTimeout(()=>{
    if(relCount){ openDetail(editRegion,entry.id); toast('找到了 '+relCount+' 段与你有关的旧碎片'); }
    else openRegion(editRegion);
  },relCount?1700:1500);
};
/* 保存粒子 */
const bursts=[];
function burst(x,y,color){
  const c=hex2rgb(color);
  for(let k=0;k<34;k++){
    const a=Math.random()*6.2832, sp=6+Math.random()*26;
    bursts.push({x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp*0.7-8,life:1,c:c,r:0.6+Math.random()*1.2});
  }
}
function stepBursts(dt){
  for(let k=bursts.length-1;k>=0;k--){
    const b=bursts[k];
    b.x+=b.vx*dt;b.y+=b.vy*dt;b.vy+=26*dt;b.vx*=0.96;b.life-=dt*0.85;
    if(b.life<=0)bursts.splice(k,1);
  }
}
function drawBursts(){
  if(!bursts.length)return;
  ctx.globalCompositeOperation='lighter';
  for(const b of bursts){
    const [sx,sy]=w2s(b.x,b.y);
    ctx.fillStyle='rgba('+(b.c[0])+','+(b.c[1])+','+(b.c[2])+','+Math.max(0,b.life).toFixed(3)+')';
    ctx.fillRect(sx,sy,b.r*S(),b.r*S());
  }
  ctx.globalCompositeOperation='source-over';
}

/* ---------------- 10b. 记录完成后的全屏演出 ---------------- */
const FX={t:9e9,dur:2.7,kind:'memory',color:[143,124,255],ox:0,oy:0,rings:[],sparks:[]};
const FX_PAL=[[255,255,255],[255,240,192],[178,214,255]];
function celebrate(island,kind,meta){
  const p=w2s(island.x,island.y);
  const R=mulberry32((Math.random()*1e9)|0);
  const diag=Math.hypot(VW,VH);
  FX.t=0; FX.kind=kind; FX.color=hex2rgb(meta&&meta.burst?meta.burst:island.color);
  FX.ox=p[0]; FX.oy=p[1];
  FX.rings=[0,0.13,0.27];
  FX.sparks=[];
  for(let n=0;n<200;n++){                       // 岛心炸开、飞满整块屏幕
    const a=R()*6.2832, sp=(0.28+R()*1.05)*diag*0.55;
    FX.sparks.push({x:FX.ox,y:FX.oy,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,
      r:1.4+R()*3.6,life:1+R()*0.9,del:0.42+R()*1.05});
  }
  for(let n=0;n<130;n++){                        // 白/金/蓝的小碎光
    const a=R()*6.2832, sp=(0.5+R()*0.9)*diag*0.62;
    FX.sparks.push({x:FX.ox,y:FX.oy,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-diag*0.05,
      r:1.2+R()*2.2,life:0.8+R()*0.8,del:0.3+R()*0.8,c:FX_PAL[(R()*FX_PAL.length)|0]});
  }
  Snd.fanfare(kind);
  showBanner(kind,island,meta);
}
function stepFX(dt){
  if(FX.t>FX.dur) return;
  FX.t+=dt;
  const g=Math.hypot(VW,VH)*0.05;
  for(let k=FX.sparks.length-1;k>=0;k--){
    const p=FX.sparks[k];
    p.x+=p.vx*dt; p.y+=p.vy*dt;
    const dec=Math.pow(0.09,dt);
    p.vx*=dec; p.vy*=dec; p.vy+=g*dt; p.life-=dt*p.del;
    if(p.life<=0) FX.sparks.splice(k,1);
  }
}
function drawFX(){
  if(FX.t>FX.dur) return;
  const t=FX.t, col=FX.color, diag=Math.hypot(VW,VH);
  const c3=col[0]+','+col[1]+','+col[2];
  ctx.setTransform(DPR,0,0,DPR,0,0);
  ctx.globalCompositeOperation='lighter';
  // 1 · 全屏闪光
  if(t<0.55){
    const f=Math.pow(1-t/0.55,2.2);
    const g=ctx.createRadialGradient(FX.ox,FX.oy,0,FX.ox,FX.oy,diag*0.92);
    g.addColorStop(0,'rgba(255,255,255,'+(0.44*f).toFixed(3)+')');
    g.addColorStop(0.35,'rgba('+c3+','+(0.30*f).toFixed(3)+')');
    g.addColorStop(1,'rgba('+c3+',0)');
    ctx.fillStyle=g; ctx.fillRect(0,0,VW,VH);
  }
  // 2 · 整个屏幕的边缘泛光
  if(t<1.6){
    const f=Math.pow(Math.max(0,1-t/1.6),1.6);
    const g=ctx.createRadialGradient(VW/2,VH/2,Math.min(VW,VH)*0.16,VW/2,VH/2,Math.max(VW,VH)*0.74);
    g.addColorStop(0,'rgba('+c3+',0)');
    g.addColorStop(1,'rgba('+c3+','+(0.32*f).toFixed(3)+')');
    ctx.fillStyle=g; ctx.fillRect(0,0,VW,VH);
  }
  // 3 · 从岛心扩散到屏幕四角的冲击波
  for(const d of FX.rings){
    const p=(t-d)/1.15;
    if(p<=0||p>=1) continue;
    const e=1-Math.pow(1-p,3.0), rad=diag*0.84*e;
    ctx.beginPath(); ctx.arc(FX.ox,FX.oy,rad,0,6.2832);
    ctx.strokeStyle='rgba('+c3+','+(Math.pow(1-p,1.5)*0.85).toFixed(3)+')';
    ctx.lineWidth=Math.max(1.2,11*(1-p)); ctx.stroke();
    ctx.beginPath(); ctx.arc(FX.ox,FX.oy,rad,0,6.2832);
    ctx.strokeStyle='rgba(255,255,255,'+(Math.pow(1-p,2.2)*0.55).toFixed(3)+')';
    ctx.lineWidth=Math.max(1,3.5*(1-p)); ctx.stroke();
  }
  // 4 · 放射光束
  if(t<0.95){
    const f=Math.pow(1-t/0.95,1.4), n=16;
    for(let k=0;k<n;k++){
      const a=k/n*6.2832+t*0.22, w=6+26*f, L=diag*0.74;
      ctx.save(); ctx.translate(FX.ox,FX.oy); ctx.rotate(a);
      const g=ctx.createLinearGradient(0,0,L,0);
      g.addColorStop(0,'rgba(255,255,255,'+(0.36*f).toFixed(3)+')');
      g.addColorStop(0.35,'rgba('+c3+','+(0.20*f).toFixed(3)+')');
      g.addColorStop(1,'rgba('+c3+',0)');
      ctx.fillStyle=g;
      ctx.beginPath(); ctx.moveTo(0,-1.5); ctx.lineTo(L,-w); ctx.lineTo(L,w); ctx.closePath(); ctx.fill();
      ctx.restore();
    }
  }
  // 5 · 飞满整块屏幕的碎光
  for(const p of FX.sparks){
    const a=clamp(p.life,0,1), c=p.c||col, s=p.r*Math.max(0.55,a);
    ctx.fillStyle='rgba('+c[0]+','+c[1]+','+c[2]+','+a.toFixed(3)+')';
    ctx.fillRect(p.x-s/2,p.y-s/2,s,s);
  }
  ctx.globalCompositeOperation='source-over';
}
/* 中央庆祝卡片（和网页 UI 同层，压在任何抽屉之上） */
function showBanner(kind,island,meta){
  const box=$('fxBanner'); if(!box) return;
  const K={icon:'⭐', name:'记忆', hint:'岛上亮起一颗星星'};
  const el=box.cloneNode(true);            // 每次重建 → 动画必定重播
  el.classList.remove('show');
  el.querySelector('.fbi').textContent=(meta&&meta.icon)||K.icon;
  el.querySelector('.fbk').textContent=(meta&&meta.label)||('SAVED · '+(K.name||'记录'));
  el.querySelector('b').textContent=(meta&&meta.title)?meta.title:regionName(island);
  el.querySelector('span').textContent=(meta&&meta.sub)?meta.sub:K.hint;
  el.style.setProperty('--c',island.color);
  box.parentNode.replaceChild(el,box);
  void el.offsetWidth;
  el.classList.add('show');
  setTimeout(()=>{ if(el.parentNode) el.classList.remove('show'); },2700);
}

/* ---------------- 10c. 小地图（宽屏） ---------------- */
const mini=document.getElementById('mini'), mctx=mini?mini.getContext('2d'):null;
let miniW=168, miniH=168, miniScale=1, miniOX=0, miniOY=0;
function syncMiniSize(){
  if(!mini||!mctx||mini.offsetParent===null) return;
  const maxW=170, maxH=170, asp=WW/Math.max(1,WH);
  if(asp>=1){ miniW=maxW; miniH=Math.round(maxW/asp); }
  else{ miniH=maxH; miniW=Math.round(maxH*asp); }
  miniW=clamp(miniW,84,190); miniH=clamp(miniH,84,190);
  mini.style.width=miniW+'px'; mini.style.height=miniH+'px';
  mini.width=Math.round(miniW*DPR); mini.height=Math.round(miniH*DPR);
  miniScale=Math.min(miniW/WW, miniH/WH);
  miniOX=(miniW-WW*miniScale)/2; miniOY=(miniH-WH*miniScale)/2;
}
/* 小地图缩略风景：把真实世界（深海 / 地形 / 道路 / 岛屿上的房子树木地标）
   缩成一张小图 —— 不再给每座岛画一个"中心圆圈"，每一处都是它自己的风景。 */
let miniCv=null, miniDirty=true;
function buildMiniThumb(){
  const c=C(WW,WH), g=GC(c);
  g.fillStyle='rgb(11,15,36)'; g.fillRect(0,0,WW,WH);
  if(oceanPat){ g.save(); g.translate(-WOX,-WOY); g.fillStyle=oceanPat; g.fillRect(WOX,WOY,WW,WH); g.restore(); }
  if(terrainCv) g.drawImage(terrainCv,0,0);          // 陆地：五座岛各有自己的配色
  if(bridgeCv) g.drawImage(bridgeCv,0,0);            // 桥与小径
  for(const p of PROPS){
    if(p.mark) continue;                             // 记录标记由 drawMini 动态画
    const spr=SPR[p.spr]; if(!spr) continue;
    const cv=spr.cv, w=cv.width*p.sc, h=cv.height*p.sc;
    g.drawImage(cv, p.x-w*spr.ax, p.y-h*spr.ay, w, h);
  }
  miniCv=c; miniDirty=false; return c;
}
function drawMini(){
  if(!mctx||!mini||mini.offsetParent===null) return;
  if(drawMini._f++%3) return;
  const g=mctx, toM=(x,y)=>[miniOX+(x-WOX)*miniScale, miniOY+(y-WOY)*miniScale];
  g.setTransform(DPR,0,0,DPR,0,0);
  g.clearRect(0,0,miniW,miniH);
  g.fillStyle='rgba(6,9,22,.94)'; g.fillRect(0,0,miniW,miniH);
  if(miniDirty||!miniCv) buildMiniThumb();           // 世界变了才重画缩略图
  if(miniCv){ g.imageSmoothingEnabled=false; g.drawImage(miniCv,miniOX,miniOY,WW*miniScale,WH*miniScale); }
  const hw=VW/(2*S()), hh=VH/(2*S()), v=toM(cam.x-hw,cam.y-hh);
  g.fillStyle='rgba(255,255,255,.07)';
  g.fillRect(v[0],v[1],hw*2*miniScale,hh*2*miniScale);
  g.strokeStyle='rgba(255,255,255,.6)'; g.lineWidth=1;
  g.strokeRect(v[0],v[1],hw*2*miniScale,hh*2*miniScale);
  const miniColor={memory:'#ffe58a',goal:'#a9ef9a',travel:'#9ddcff',music:'#ff9ddd',recall:'#ffe2f0'};
  /* 记录只留一枚安静的小点：让缩略风景本身说话，点它仍能跳过去看 */
  for(const p of PROPS){
    if(!p.entryId) continue;
    const [x,y]=toM(p.x,p.y); if(x<-8||x>miniW+8||y<-8||y>miniH+8) continue;
    const col=miniColor[p.kind]||'#fff';
    const pulse=0.78+0.22*Math.sin(T*2.6+(p.phase||0));
    g.beginPath(); g.arc(x,y,3.3,0,6.2832);
    g.fillStyle=col; g.globalAlpha=pulse; g.fill(); g.globalAlpha=1;
    g.lineWidth=0.8; g.strokeStyle='rgba(10,13,26,.8)'; g.stroke();
  }
}
drawMini._f=0;
if(mini){
  let mDown=false;
  const hitRecord=e=>{const r=mini.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;let best=null,bd=10;for(const p of PROPS){if(!p.entryId)continue;const x=miniOX+(p.x-WOX)*miniScale,y=miniOY+(p.y-WOY)*miniScale,d=Math.hypot(mx-x,my-y);if(d<bd){best=p;bd=d;}}return best;};
  const jump=e=>{
    const r=mini.getBoundingClientRect();
    const wx=(e.clientX-r.left-miniOX)/miniScale+WOX;
    const wy=(e.clientY-r.top-miniOY)/miniScale+WOY;
    setTarget(wx,wy,Math.max(cam.tz,fitZoom*2.1),true);
  };
  mini.addEventListener('pointerdown',e=>{e.stopPropagation();e.preventDefault();const marker=hitRecord(e);if(marker){const found=findEntry(marker.entryId);if(found){if((found.entry.kind||'memory')==='music')Music.play(found.entry);else openDetail(found.island.id,marker.entryId);return;}}mDown=true;try{mini.setPointerCapture(e.pointerId);}catch(err){}jump(e);});
  mini.addEventListener('pointermove',e=>{if(mDown)jump(e);});
  mini.addEventListener('pointerup',()=>{mDown=false;});
  mini.addEventListener('pointercancel',()=>{mDown=false;});
}
/* 头部信息 */
function refreshHeader(){
  $('wName').firstChild.nodeValue=state.name+' ';
  $('wSub').textContent='把生活变成一个世界 · '+totalEntries()+' 条记忆';
}

/* 顶部按钮 */
$('btnAdd').onclick=()=>openEditor(activeRegion||'harbor');
$('rsAdd').onclick=()=>openEditor(activeRegion);
$('rsDel').onclick=()=>{
  const id=activeRegion; if(!id) return;
  const i=ISL[id]; if(!i||!i.custom) return;
  const n=((state.regions[id]&&state.regions[id].entries.length)||0);
  if(!confirm('把「'+regionName(i)+'」从世界里移除？'+(n?('岛上的 '+n+' 条记录也会一起消失。'):'')+'确定吗？')) return;
  removeIsland(id); closeAll();
  toast('「'+i.name+'」沉回海里了');
};
/* ---- 添加岛屿 ---- */
const EMOJI_POOL=['🌊','🌸','🍄','🏔','🌙','🪐','🎠','🏕','🕯','🧭','🍵','🐾','🎐','🪁','🔥','🌿','🍉','🎨','🎵','📚','🏡','⭐','💡','📷','🍜','✈️','🏆','💌','🧩','🪴','🦋','🎮'];
const THEME_KEYS=Object.keys(ISLAND_THEMES);
let isEmoji='🌊', isTheme='garden', isNearIsland='harbor';
function renderIsEmojis(){
  const box=$('isEmojis'); box.innerHTML='';
  EMOJI_POOL.forEach(e=>{
    const d=document.createElement('div');
    d.className='emoji'+(e===isEmoji?' on':''); d.textContent=e;
    d.onclick=()=>{isEmoji=e;renderIsEmojis();};
    box.appendChild(d);
  });
}
function renderIsNearbyIslands(){
  const box=$('isNearbyIslands'); if(!box) return;
  if(!ISL[isNearIsland]) isNearIsland=(ISL.harbor?'harbor':((ISLANDS[0]||{}).id||'harbor'));
  box.innerHTML='';
  for(const i of ISLANDS){
    const d=document.createElement('div');
    d.className='rg'+(i.id===isNearIsland?' on':'');
    d.style.setProperty('--c',i.color);
    d.innerHTML='<span>'+i.emoji+'</span><span>'+regionName(i)+'</span>';
    d.onclick=()=>{isNearIsland=i.id;renderIsNearbyIslands();};
    box.appendChild(d);
  }
}
function renderIsThemes(){
  const box=$('isThemes'); box.innerHTML='';
  THEME_KEYS.forEach(k=>{
    const th=ISLAND_THEMES[k];
    const d=document.createElement('div');
    d.className='theme'+(k===isTheme?' on':''); d.style.setProperty('--c',th.color);
    d.innerHTML='<i></i><span>'+th.name+'</span>';
    d.onclick=()=>{isTheme=k;renderIsThemes();};
    box.appendChild(d);
  });
}
function openAddSheet(){
  isEmoji='🌊'; isTheme='garden'; isNearIsland=(ISL[isNearIsland]?isNearIsland:(ISL.harbor?'harbor':((ISLANDS[0]||{}).id||'harbor')));
  $('isName').value=''; $('isDesc').value='';
  renderIsNearbyIslands(); renderIsEmojis(); renderIsThemes();
  $('regionSheet').classList.remove('open');
  $('editSheet').classList.remove('open');
  $('addSheet').classList.add('open');
  setTimeout(()=>{try{$('isName').focus({preventScroll:true});}catch(e){}},320);
}
$('isCancel').onclick=()=>{$('addSheet').classList.remove('open');};
$('isCreate').onclick=()=>{
  const nm=$('isName').value.trim();
  if(!nm){toast('先给它起个名字吧');try{$('isName').focus();}catch(e){}return;}
  const em=isEmoji, th=isTheme, ds=$('isDesc').value.trim(), near=isNearIsland;
  $('addSheet').classList.remove('open');
  toast('正在把「'+nm+'」放进世界里…');
  // 让 toast 先画出来，再去做世界重建（岛多了会有一小段计算）
  setTimeout(()=>{
    const id=addIsland(nm,em,th,ds,near);
    if(!id) return;
    const isl=ISL[id];
    setTarget(isl.x,isl.y,Math.max(cam.tz,1.25),true);
    burst(isl.x,isl.y,isl.color);
    celebrate(isl,'memory',{burst:isl.color,icon:isl.emoji,label:'NEW ISLAND',
      title:nm, sub:'已落在 '+((ISL[near]&&regionName(ISL[near]))||'选中岛屿')+' 旁边'});
    setTimeout(()=>openRegion(id),1400);
  },40);
};
$('dtBack').onclick=closeDetail;
$('btnFit').onclick=()=>{const wc=worldCenter();setTarget(wc[0],wc[1],fitZoom,true);toast('世界全览');};
/* 网页端：遮罩联动 + 缩放控件 + 键盘快捷键 */
const SHEET_IDS=['regionSheet','editSheet','addSheet','detail','archive'];
function closeAll(){closeDetail();if(typeof closeArchive==='function') closeArchive();['regionSheet','editSheet','addSheet'].forEach(id=>$(id).classList.remove('open'));activeRegion=null;syncChips();}
$('scrim').onclick=closeAll;
new MutationObserver(()=>{
  $('scrim').classList.toggle('on',SHEET_IDS.some(id=>$(id).classList.contains('open')));
}).observe(phone,{subtree:true,attributes:true,attributeFilter:['class']});
function zoomStep(f){ zoomTo(VW/2,VH/2,cam.tz*(f-1)); }
$('zIn').onclick=()=>zoomStep(1.34);
$('zOut').onclick=()=>zoomStep(1/1.34);
/* 键盘平移，一次挪 34px */
function nudge(dx,dy){ cam.mvx=0;cam.mvy=0; cam.x+=dx*34/S(); cam.y+=dy*34/S(); cam.tx=cam.x;cam.ty=cam.y; camFollow=true; clampCam(); }
window.addEventListener('keydown',e=>{
  const tag=(e.target&&e.target.tagName)||'';
  if(tag==='INPUT'||tag==='TEXTAREA'){ if(e.key!=='Escape') return; }
  if(e.key==='Escape'){
    if($('detail').classList.contains('open')) closeDetail();
    else if(['regionSheet','editSheet','addSheet','archive'].some(id=>$(id).classList.contains('open'))) closeAll();
    else $('menu').classList.remove('open');
  }
  else if(e.key==='0'){ const wc=worldCenter(); setTarget(wc[0],wc[1],fitZoom,true); toast('世界全览'); }
  else if(e.key==='+'||e.key==='='){ zoomStep(1.34); }
  else if(e.key==='-'||e.key==='_'){ zoomStep(1/1.34); }
  else if(e.key==='ArrowLeft'||e.key==='a'||e.key==='A'){ nudge(-1,0); }
  else if(e.key==='ArrowRight'||e.key==='d'||e.key==='D'){ nudge(1,0); }
  else if(e.key==='ArrowUp'||e.key==='w'||e.key==='W'){ nudge(0,-1); }
  else if(e.key==='ArrowDown'||e.key==='s'||e.key==='S'){ nudge(0,1); }
},false);
$('btnMenu').onclick=e=>{e.stopPropagation();$('menu').classList.toggle('open');};
$('menu').onclick=e=>{
  const act=e.target.dataset.act; if(!act)return;
  $('menu').classList.remove('open');
  if(act==='archive'){ openArchive(); return; }
  if(act==='chronicle'){ openArchive('chronicle'); return; }
  if(act==='friends'){ if(Cloud.user){ togglePersona(); } else { openAuth(); } return; }
  if(readOnly&&(act==='addisland'||act==='rename'||act==='reset')){ toast('这是好友的世界，只能查看'); return; }
  if(act==='addisland'){ openAddSheet(); return; }
  if(act==='rename'){
    const n=prompt('给你的世界起个名字：',state.name);
    if(n&&n.trim()){state.name=n.trim();saveState();refreshHeader();buildChips();toast('世界已重命名');}
  }else if(act==='export'){
    const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'});
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);
    a.download=(state.name||'my-world')+'.json';a.click();
    toast('已导出世界数据');
  }else if(act==='reset'){
    if(confirm('重置会清空你写入的所有记忆，换成示例世界。确定吗？')){
      seedData();
      ISLANDS=ISLANDS.filter(i=>!i.custom);      // 自建岛也一并清掉
      rebuildWorld(); buildChips(); refreshHeader();
      activeRegion='harbor'; openRegion('harbor');
      toast('已重置为示例世界');
    }
  }
};
document.addEventListener('click',e=>{if(!$('menu').contains(e.target)&&e.target!==$('btnMenu'))$('menu').classList.remove('open');});
/* 手势关闭抽屉 */
(function(){
  let sy=0,moving=false;
  const sh=$('regionSheet');
  sh.addEventListener('touchstart',e=>{if(sh.querySelector('.bd').scrollTop<=0){sy=e.touches[0].clientY;moving=true;}},{passive:true});
  sh.addEventListener('touchmove',e=>{
    if(!moving)return;
    const dy=e.touches[0].clientY-sy;
    if(dy>0){sh.style.transform='translateY('+dy+'px)';}
  },{passive:true});
  sh.addEventListener('touchend',e=>{
    const dy=(e.changedTouches[0].clientY-sy);
    sh.style.transform='';
    if(dy>90){sh.classList.remove('open');activeRegion=null;syncChips();}
    moving=false;
  });
})();

/* ---------------- 11. 环境音（WebAudio，无外部文件） ---------------- */
const Snd={
  on:true, ctx:null, master:null, started:false, ducked:false, prevOn:true,
  init(){
    if(this.ctx)return;
    const AC=window.AudioContext||window.webkitAudioContext; if(!AC)return;
    this.ctx=new AC();
    this.master=this.ctx.createGain(); this.master.gain.value=0;
    const lp=this.ctx.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=720;
    this.master.connect(lp); lp.connect(this.ctx.destination);
    // 三音垫
    [110,164.81,220,329.63].forEach((f,idx)=>{
      const o=this.ctx.createOscillator(); o.type=idx%2?'triangle':'sine';
      o.frequency.value=f*(1+(idx%2?0.004:-0.003));
      const g=this.ctx.createGain(); g.gain.value=0.16/(idx+1);
      const lfo=this.ctx.createOscillator(); lfo.frequency.value=0.05+idx*0.017;
      const lg=this.ctx.createGain(); lg.gain.value=0.07/(idx+1);
      lfo.connect(lg); lg.connect(g.gain); lfo.start();
      o.connect(g); g.connect(this.master); o.start();
    });
    // 延迟回声
    this.delay=this.ctx.createDelay(1.2); this.delay.delayTime.value=0.42;
    this.fb=this.ctx.createGain(); this.fb.gain.value=0.34;
    this.delay.connect(this.fb); this.fb.connect(this.delay);
    this.delay.connect(this.ctx.destination);
    setInterval(()=>{ if(this.on&&this.started&&Math.random()<0.7) this.chime(); },3400);
  },
  chime(){
    if(!this.ctx)return;
    const scale=[523.25,587.33,659.25,783.99,880,1046.5];
    const f=scale[(Math.random()*scale.length)|0]*(Math.random()<0.5?1:0.5);
    const o=this.ctx.createOscillator(); o.type='sine'; o.frequency.value=f;
    const g=this.ctx.createGain();
    const t=this.ctx.currentTime;
    g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(0.075,t+0.03);
    g.gain.exponentialRampToValueAtTime(0.0001,t+2.6);
    o.connect(g); g.connect(this.master); g.connect(this.delay);
    o.start(t); o.stop(t+2.8);
  },
  /* 记录保存时的上行音阶，配合全屏演出 */
  fanfare(kind){
    if(!this.ctx||!this.on||!this.started)return;
    const t0=this.ctx.currentTime+0.01;
    const notes=kind==='music'?[523.25,659.25,783.99,1046.5,1318.5]
              :kind==='recall'?[392,523.25,659.25,987.77]
              :[392,523.25,659.25,880];
    notes.forEach((f,idx)=>{
      const o=this.ctx.createOscillator(); o.type=idx%2?'sine':'triangle'; o.frequency.value=f;
      const g=this.ctx.createGain();
      const t=t0+idx*0.072;
      g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(0.13,t+0.02);
      g.gain.exponentialRampToValueAtTime(0.0001,t+1.8);
      o.connect(g); g.connect(this.master); g.connect(this.delay);
      o.start(t); o.stop(t+1.9);
    });
  },
  start(){ this.init(); if(!this.ctx)return; this.started=true; this.ctx.resume(); this.master.gain.linearRampToValueAtTime(this.ducked?0:0.5,this.ctx.currentTime+3); },
  setOn(v){ this.on=v; if(!this.ctx||this.ducked)return; this.master.gain.cancelScheduledValues(this.ctx.currentTime); this.master.gain.linearRampToValueAtTime(v?0.5:0,this.ctx.currentTime+0.5); },
  /* 音乐播放时让环境音暂时退场，音乐结束或暂停后再淡入 */
  duck(){ if(this.ducked)return; this.prevOn=this.on; this.ducked=true; if(!this.ctx)return; try{ this.master.gain.cancelScheduledValues(this.ctx.currentTime); this.master.gain.linearRampToValueAtTime(0,this.ctx.currentTime+0.22); }catch(e){} },
  unduck(){ if(!this.ducked)return; this.ducked=false; if(!this.ctx)return; try{ this.master.gain.cancelScheduledValues(this.ctx.currentTime); this.master.gain.linearRampToValueAtTime(this.on?0.5:0,this.ctx.currentTime+0.65); }catch(e){} }
};
$('btnSound').onclick=()=>{
  Snd.init();
  if(!Snd.started){Snd.start();}
  else{ Snd.on=!Snd.on; Snd.setOn(Snd.on); }
  $('btnSound').textContent=Snd.on?'🔊':'🔇';
  toast(Snd.on?'环境音已开启':'环境音已关闭');
};

/* ---------------- 11c. 爱乐之城 · 音乐导入与播放 ---------------- */
/* 小音频直接内嵌（可随世界同步给好友）；大音频缓存进浏览器 IndexedDB，避免 localStorage 超限。 */
const AUDIO_INLINE_LIMIT=600*1024;      // 约 600KB：内嵌保存并随云端同步给好友
const AUDIO_CLOUD_LIMIT=8*1024*1024;    // 约 8MB：仍读入内存供云端同步；更大的只在本机离线库播放
const AudioStore={
  db:null, ok:typeof indexedDB!=='undefined',
  open(){
    if(this.db) return Promise.resolve(this.db);
    if(!this.ok) return Promise.reject(new Error('当前浏览器不支持离线音频库'));
    return new Promise((res,rej)=>{
      let req;
      try{ req=indexedDB.open('lifeWorldAudio',1); }catch(e){ rej(e); return; }
      req.onupgradeneeded=()=>{ const db=req.result; if(!db.objectStoreNames.contains('files')) db.createObjectStore('files'); };
      req.onsuccess=()=>{ this.db=req.result; res(this.db); };
      req.onerror=()=>rej(req.error||new Error('离线音频库打开失败'));
      req.onblocked=()=>rej(new Error('离线音频库被其他页面占用'));
    });
  },
  put(id,blob){
    return this.open().then(db=>new Promise((res,rej)=>{
      let tx;
      try{ tx=db.transaction('files','readwrite'); tx.objectStore('files').put(blob,id); }
      catch(e){ rej(e); return; }
      tx.oncomplete=()=>res(true);
      tx.onerror=()=>rej(tx.error||new Error('音频写入失败'));
      tx.onabort=()=>rej(tx.error||new Error('音频写入被中断'));
    }));
  },
  get(id){
    return this.open().then(db=>new Promise((res,rej)=>{
      let tx;
      try{ tx=db.transaction('files','readonly'); }catch(e){ rej(e); return; }
      const rq=tx.objectStore('files').get(id);
      rq.onsuccess=()=>res(rq.result||null);
      rq.onerror=()=>rej(rq.error||new Error('音频读取失败'));
    }));
  },
  del(id){
    if(!this.ok) return Promise.resolve(false);
    return this.open().then(db=>new Promise(res=>{
      try{
        const tx=db.transaction('files','readwrite'); tx.objectStore('files').delete(id);
        tx.oncomplete=()=>res(true); tx.onerror=()=>res(false); tx.onabort=()=>res(false);
      }catch(e){ res(false); }
    })).catch(()=>false);
  }
};
/* 音乐文件转 dataURL（不做压缩，音频不重编码以免失真） */
function audioToDataURL(file){
  return new Promise((res,rej)=>{
    const fr=new FileReader();
    fr.onload=()=>res(fr.result);
    fr.onerror=()=>rej(new Error('音频读取失败，请重试'));
    const mime=audioMimeFor(file&&file.name,file&&file.type);
    const source=file&&file.type===mime?file:new Blob([file],{type:mime});
    fr.readAsDataURL(source);
  });
}
/* 浏览器有时拿不到音频 MIME，会导致 data URL / Blob 无法解码。
   这里按扩展名补全类型，并统一用内存 Blob 地址交给播放器。 */
const AUDIO_MIME={
  mp3:'audio/mpeg',mp2:'audio/mpeg',mpga:'audio/mpeg',wav:'audio/wav',
  m4a:'audio/mp4',m4b:'audio/mp4',mp4:'audio/mp4',aac:'audio/aac',
  ogg:'audio/ogg',oga:'audio/ogg',opus:'audio/ogg',flac:'audio/flac',
  aif:'audio/aiff',aiff:'audio/aiff',wma:'audio/x-ms-wma',
  webm:'audio/webm',caf:'audio/x-caf'
};
function audioMimeFor(name,type){
  const ext=String(name||'').split('.').pop().toLowerCase();
  return AUDIO_MIME[ext]||(String(type||'').startsWith('audio/')?type:'audio/mpeg');
}
async function audioBlobFor(value,name){
  let blob;
  if(value instanceof Blob) blob=value;
  else{
    const src=String(value||'');
    if(!src) throw new Error('这段音乐没有可播放的内容');
    blob=await fetch(src).then(r=>r.blob());
  }
  const mime=audioMimeFor(name,blob.type);
  if(blob.type===mime) return blob;
  return new Blob([blob],{type:mime});
}
/* 全局唯一音乐播放器（原生 Audio 元素） */
const Music={
  el:null, entry:null, playing:false, loading:false, objUrl:null, token:0, urlCache:new Map(),
  ensure(){
    if(this.el) return this.el;
    this.el=new Audio(); this.el.preload='auto';
    this.el.setAttribute('playsinline','');
    this.el.setAttribute('webkit-playsinline','');
    this.el.className='musicAudio';
    this.el.style.cssText='display:none;';
    try{ $('musicPlayer').appendChild(this.el); }catch(e){}
    const upd=()=>{
      if(!this.el) return;
      const d=this.el.duration||0, t=this.el.currentTime||0;
      $('mpFill').style.width=(d?Math.min(100,t/d*100):0)+'%';
      $('mpToggle').textContent=this.loading?'…':(this.playing?'⏸':'▶');
      $('musicPlayer').classList.toggle('playing',this.playing);
    };
    this.el.addEventListener('timeupdate',upd);
    this.el.addEventListener('play',()=>{this.playing=true;this.hideNativeFallback();upd();});
    this.el.addEventListener('pause',()=>{this.playing=false;upd();Snd.unduck();});
    this.el.addEventListener('ended',()=>{this.playing=false;this.loading=false;try{this.el.currentTime=0;}catch(e){}Snd.unduck();upd();});
    this.el.addEventListener('error',()=>{
      if(!this.entry)return;
      this.playing=false;this.loading=false;Snd.unduck();upd();
      this.showNativeFallback();
      toast('浏览器无法解码这首音乐，请换 MP3 / M4A / WAV 格式重试');
    });
    return this.el;
  },
  rememberUrl(id,url){
    if(id) this.urlCache.set(id,url);
    while(this.urlCache.size>40){
      const first=this.urlCache.entries().next().value;
      this.urlCache.delete(first[0]);
      if(first[1]&&first[1]!==this.objUrl){ try{URL.revokeObjectURL(first[1]);}catch(e){} }
    }
    return url;
  },
  blobFor(entry){
    if(entry.audio) return audioBlobFor(entry.audio,entry.audioName||entry.title);
    if(entry.audioStore==='idb'&&entry.audioBlobId){
      return AudioStore.get(entry.audioBlobId).then(blob=>{
        if(!blob) throw new Error('这首音乐的文件保存在导入它的设备上，当前设备暂时无法播放');
        return audioBlobFor(blob,entry.audioName||entry.title);
      });
    }
    return Promise.reject(new Error('这段音乐没有可播放的内容'));
  },
  async warm(entry){
    const key=entry&&(entry.id||entry.audioBlobId);
    if(!key||this.urlCache.has(key)) return key?this.urlCache.get(key):null;
    const blob=await this.blobFor(entry);
    const url=URL.createObjectURL(blob);
    return this.rememberUrl(key,url);
  },
  prefetch(entries){
    const rows=(entries||[]).filter(e=>e&&(e.audio||(e.audioStore==='idb'&&e.audioBlobId)));
    return Promise.all(rows.map(entry=>this.warm(entry).catch(()=>null)));
  },
  async sourceFor(entry){
    // 内嵌小音频直接播放，点击授权不会因异步读取而丢失。
    if(entry.audio){ this.objUrl=entry.audio; return entry.audio; }
    const key=entry.id||entry.audioBlobId;
    if(key&&this.urlCache.has(key)){ this.objUrl=this.urlCache.get(key); return this.objUrl; }
    const blob=await this.blobFor(entry);
    const url=URL.createObjectURL(blob);
    this.objUrl=url;
    return this.rememberUrl(key,url);
  },
  showNativeFallback(){
    const el=this.ensure();
    el.controls=true;
    el.style.cssText='display:block;position:fixed;left:12px;right:12px;bottom:14px;width:calc(100% - 24px);height:44px;z-index:10060;opacity:1;';
    const p=$('musicPlayer'); if(p) p.classList.add('nativeFallback');
  },
  hideNativeFallback(){
    const el=this.el; if(!el) return;
    el.style.cssText='display:none;';
    const p=$('musicPlayer'); if(p) p.classList.remove('nativeFallback');
  },
  async play(entry){
    if(!entry) return;
    const el=this.ensure();
    // 同一首：播放中再点一次 = 暂停；暂停后再点 = 从原位置继续
    if(this.entry===entry&&el.src){
      if(this.playing){ try{el.pause();}catch(e){} return; }
      try{
        this.loading=true; Snd.duck(); await el.play(); this.playing=true;
      }catch(e){
        Snd.unduck();
        if(e&&e.name==='NotAllowedError'){ this.showNativeFallback(); toast('浏览器需要你点一下播放器上的播放键'); }
        else toast('播放失败，请重试');
      }
      finally{ this.loading=false; $('mpToggle').textContent=this.playing?'⏸':'▶'; $('musicPlayer').classList.toggle('playing',this.playing); }
      return;
    }
    const token=++this.token;
    this.entry=entry; this.loading=true; this.playing=false;
    $('mpTitle').textContent=entry.title||entry.audioName||'音乐';
    $('musicPlayer').classList.add('show');
    $('musicPlayer').setAttribute('aria-hidden','false');
    $('mpToggle').textContent='…';
    try{
      const src=await this.sourceFor(entry);
      if(token!==this.token||this.entry!==entry) return;
      el.src=src; el.currentTime=0; try{el.load();}catch(loadErr){}
      Snd.duck();
      await el.play();
      if(token!==this.token) return;
      this.playing=true;
    }catch(err){
      if(token!==this.token) return;
      this.playing=false; Snd.unduck();
      const msg=(err&&err.message)||'播放失败，请重试';
      if(err&&err.name==='NotAllowedError'){
        this.showNativeFallback();
        toast('浏览器需要你点一下播放器上的播放键');
      }else if(msg.indexOf('没有可播放')>=0||msg.indexOf('保存在导入')>=0){
        $('musicPlayer').classList.remove('show');
        $('musicPlayer').setAttribute('aria-hidden','true');
        this.entry=null;
        toast(msg);
      }else{
        this.showNativeFallback();
        toast(msg);
      }
    }finally{
      if(token===this.token){
        this.loading=false; $('mpToggle').textContent=this.playing?'⏸':'▶';
        $('musicPlayer').classList.toggle('playing',this.playing);
      }
    }
  },
  toggle(){ const el=this.ensure(); if(!this.entry)return; if(this.playing){ try{el.pause();}catch(e){} } else { this.play(this.entry); } },
  stop(){
    this.token++;
    if(this.el){ try{this.el.pause();}catch(e){} try{this.el.currentTime=0;}catch(e){} }
    this.playing=false; this.loading=false; this.entry=null;
    $('musicPlayer').classList.remove('show');
    $('musicPlayer').setAttribute('aria-hidden','true');
    $('mpToggle').textContent='▶';
    this.hideNativeFallback();
    Snd.unduck();
  },
  close(){ this.stop(); }
};
$('mpToggle').onclick=()=>Music.toggle();
$('mpClose').onclick=()=>Music.close();
/* 导入音乐按钮 → 唤起系统文件选择 */
$('btnMusicImport').onclick=()=>{
  if(readOnly){ toast('这是好友的世界，只能查看'); return; }
  $('musicIn').click();
};
/* 导入音乐：每条音乐都存成 kind=music 的记忆，在爱乐之城里变成可点击的唱片/音符 */
const AUDIO_EXT_RE=/\.(mp3|wav|m4a|m4b|aac|ogg|oga|flac|opus|aif|aiff|wma|webm|mp4|caf)$/i;
function warmMusicLibrary(){
  const entries=[];
  ISLANDS.forEach(i=>{ const r=state.regions&&state.regions[i.id]; if(r&&Array.isArray(r.entries)) entries.push(...r.entries); });
  if(typeof Music!=='undefined') Music.prefetch(entries);
}
setTimeout(warmMusicLibrary,700);
$('musicIn').addEventListener('change',async e=>{
  const input=e.target;
  const files=[...input.files].filter(f=>(f.type&&f.type.startsWith('audio/'))||AUDIO_EXT_RE.test(f.name||''));
  if(!files.length){ toast('请选择音频文件（mp3 / wav / m4a / aac / ogg / flac 等）'); input.value=''; return; }
  const regionId=adventureFocus||'music';
  const r=ensureRegion(regionId);
  toast('正在导入 '+files.length+' 首音乐…');
  let okCount=0, localOnly=0, lastErr='';
  const createdMusicEntries=[];
  for(const f of files){
    try{
      const name=String(f.name||'音乐').replace(/\.[^.]+$/,'')||'音乐';
      const entry={id:'e'+Date.now().toString(36)+Math.random().toString(36).slice(2,7),
        kind:'music', target:null, bornAt:Date.now(),
        title:name, text:'', audioName:f.name||name,
        date:new Date().toISOString(), images:[]};
      if(f.size<=AUDIO_INLINE_LIMIT){
        entry.audio=await audioToDataURL(f);
      }else{
        let cached=false;
        try{ await AudioStore.put(entry.id,f); entry.audioStore='idb'; entry.audioBlobId=entry.id; cached=true; }
        catch(idbErr){ cached=false; }
        if(f.size<=AUDIO_CLOUD_LIMIT){
          try{ entry.audio=await audioToDataURL(f); }catch(e){ entry.audio=''; }
        }
        if(!cached&&!entry.audio) throw new Error('这首音乐过大，且当前浏览器的离线音频库不可用，请换用较小的文件');
        if(!entry.audio) localOnly++;
      }
      r.entries.push(entry);
      createdMusicEntries.push({entry:entry,islandId:regionId});
      if(entry.audioStore==='idb'&&entry.audioBlobId){
        try{ Music.rememberUrl(entry.id,URL.createObjectURL(f)); }catch(cacheErr){}
      }
      okCount++;
    }catch(err){ lastErr=(err&&err.message)||'导入失败'; }
  }
  input.value='';
  if(!okCount){ toast(lastErr||'导入失败，请换一个音频文件重试'); return; }
  const saved=saveState();
  refreshMarkers(); refreshHeader();
  if(gameMode) gameWorld=null;      // 重建岛屿地图，新唱片立刻出现在路旁
  if(!saved){ toast('音乐已加入世界，但本地空间不足，建议清理部分图片后再保存'); return; }
  const relMusic=attachRelations(createdMusicEntries);
  if(relMusic) saveState();
  toast('已导入 '+okCount+' 首音乐，靠近岛上的唱片或音符即可播放'+(localOnly?('（'+localOnly+' 首仅在本机可播放）'):'')+(relMusic?('，其中找到了 '+relMusic+' 段相关旧碎片'):''));
  if(okCount===1&&relMusic&&createdMusicEntries[0]) setTimeout(()=>openDetail(regionId,createdMusicEntries[0].entry.id),900);
});


/* ---------------- 11b. 账号 / 云服务 / 好友 ---------------- */
/* 专属 ID：纯数字 8 位（好记好输入） */
function genShortId(){
  let s=''; const R=mulberry32((Date.now()^(Math.random()*1e9))|0);
  for(let i=0;i<8;i++) s+='0123456789'[(R()*10)|0];
  // 首位不为 0，避免被当作八进制/前导零混淆
  if(s[0]==='0') s='1'+s.slice(1);
  return s;
}

/* 云服务初始化与账号封装 */
const Cloud={
  client:null, ready:false, user:null, profile:null, guest:null,
  get endpoint(){ return 'https://life-as-a-world-72517.app.workbuddy.host'; },
  get oauth(){ return 'https://www.workbuddy.cn/v2/as/genie-baas/oauth'; },
  get key(){ return 'wbpk_lDpJxw774dgIejmZm0agrC_Yo8PAV7qxU2bAghUbtNyc3eYpCBg58Hw'; },
  init(){
    if(this.ready) return true;
    const WB=window.WorkBuddyCloud;
    if(!WB||!WB.createWorkBuddyCloud){ return false; }   // CDN 未加载，走纯本地
    try{
      this.client=WB.createWorkBuddyCloud({
        endpoint:this.endpoint, oauthRelayBaseUrl:this.oauth, publishableKey:this.key,
      });
      this.ready=true;
      // 监听登录态变化：退出后回到本地
      if(this.client.auth&&this.client.auth.onAuthStateChange){
        this.client.auth.onAuthStateChange((ev,sess)=>{
          if(ev==='SIGNED_OUT'){ this.user=null; this.profile=null; this.guest=null; updateAccountUI(); }
        });
      }
      return true;
    }catch(e){ return false; }
  },
  /* 微信一键登录：返回跳转 URL，登录按钮用它跳转 */
  async wechatLogin(){
    const {data,error}=await this.client.auth.signInWithOAuth({
      provider:'wechat', redirectTo:location.origin,
    });
    if(error) return {ok:false,msg:authMsg(error)};
    return {ok:true,url:data.url};
  },
  /* 微信回调处理：应用启动时无条件调用 */
  async handleWechatCallback(){
    const {data,error}=await this.client.auth.handleWechatWebCallback();
    if(error) return {ok:false,msg:authMsg(error)};
    if(!data){ return {ok:true,session:false}; }   // 无 code，普通访问
    // 成功：清理 URL，然后分配/读取 profile
    history.replaceState(null,'',location.pathname+location.search.replace(/[?&](code|state)=[^&]*/g,'').replace(/^&/,'?'));
    return await this._afterLogin(null, false);
  },
  /* 登录/首次注册后：确保 profile 存在（首次自动分配专属 ID） */
  async _afterLogin(nickname, isSignup){
    const {data:user,error}=await this.client.auth.getUser();
    if(error||!user){ return {ok:false,msg:'登录后无法获取用户信息'}; }
    this.user=user;
    let {data:prof}=await this.client.database.from('profiles').select('*').eq('owner_id',user.id).maybeSingle();
    // 首次登录自动创建 profile（分配专属 ID），昵称可后续在资料里改
    if(!prof){
      const handle=genShortId();
      const {data:ins,error:ie}=await this.client.database.from('profiles')
        .insert({owner_id:user.id, handle, nickname:nickname||('用户'+genShortId().slice(-4)), world_name:'我的世界'}).select();
      if(ie||!ins||!ins[0]) return {ok:false,msg:'创建账号失败：'+(ie?ie.message:'未知')};
      prof=ins[0];
    }else if(nickname){
      const {error:ue}=await this.client.database.from('profiles').update({nickname}).eq('owner_id',user.id);
      if(ue) return {ok:false,msg:'更新昵称失败：'+ue.message};
      prof.nickname=nickname;
    }
    this.profile=prof;
    localStorage.setItem(KEY_UID,user.id);
    updateAccountUI();
    return {ok:true,user,profile:prof};
  },
  async logout(){
    if(this.user&&!this.guest) await this.pushWorld(state);
    LocalAuth.exit();
    this.user=null; this.profile=null; this.guest=null;
    localStorage.removeItem(KEY_UID);
    ISLANDS=ISLANDS.filter(i=>!i.custom);
    seedData();
    applyCustomIslands();
    ISLANDS.forEach(i=>ensureRegion(i.id));
    rebuildWorld(); buildChips(); refreshHeader();
    const wc=worldCenter(); cam.zoom=cam.tz=fitZoom*0.98; cam.x=cam.tx=wc[0]; cam.y=cam.ty=wc[1]; clampCam();
    updateAccountUI();
  },
  async pullWorld(){
    if(!this.ready||!this.user) return null;
    const {data,error}=await this.client.database.from('worlds').select('data').eq('owner_id',this.user.id).maybeSingle();
    if(error) return null;
    return data?data.data:null;
  },
  async pushWorld(s){
    if(!this.ready||!this.user||this.guest) return;
    try{
      await this.client.database.from('worlds')
        .upsert({owner_id:this.user.id, data:s, updated_at:new Date().toISOString()});
    }catch(e){}
  },
  /* 好友系统 */
  async searchByHandle(handle){
    handle=String(handle||'').trim();
    const {data,error}=await this.client.database.from('profiles').select('*').eq('handle',handle).maybeSingle();
    if(error) return {ok:false,msg:authMsg(error)};
    if(!data) return {ok:false,msg:'没有找到这个 ID 的用户'};
    return {ok:true,profile:data};
  },
  async sendFriendRequest(friendId){
    const {error}=await this.client.database.from('friendships')
      .insert({owner_id:this.user.id, friend_id:friendId, status:'pending'}).select();
    if(error) return {ok:false,msg:authMsg(error)};
    return {ok:true};
  },
  async listFriends(){
    const uid=this.user.id;
    const {data,error}=await this.client.database.from('friendships')
      .select('*').or('owner_id.eq.'+uid+',friend_id.eq.'+uid);
    if(error) return [];
    return data||[];
  },
  async respondRequest(id,accept){
    if(accept){
      const {error}=await this.client.database.from('friendships').update({status:'accepted'}).eq('id',id);
      if(error) return {ok:false,msg:authMsg(error)};
    }else{
      const {error}=await this.client.database.from('friendships').delete().eq('id',id);
      if(error) return {ok:false,msg:authMsg(error)};
    }
    return {ok:true};
  },
  async removeFriend(id){
    const {error}=await this.client.database.from('friendships').delete().eq('id',id);
    if(error) return {ok:false,msg:authMsg(error)};
    return {ok:true};
  },
  /* 进入好友世界（只读） */
  async viewFriendWorld(ownerId){
    const {data,error}=await this.client.database.from('worlds').select('data').eq('owner_id',ownerId).maybeSingle();
    if(error||!data) return {ok:false,msg:'无法读取该好友的世界（可能还未公开或数据为空）'};
    return {ok:true,data:data.data};
  },
  async memoryInteractions(ownerId,regionId,entryId){
    try{ return await remoteReadInteraction(ownerId,regionId,entryId); }
    catch(e){ return emptyInteraction(ownerId,regionId,entryId); }
  },
  async toggleMemoryLike(ownerId,regionId,entryId){
    const profile=this.profile||accountProfile(LocalAuth.current());
    return remoteToggleMemoryLike(ownerId,regionId,entryId,profile);
  },
  async addMemoryComment(ownerId,regionId,entryId,text){
    const profile=this.profile||accountProfile(LocalAuth.current());
    return remoteAddMemoryComment(ownerId,regionId,entryId,profile,text);
  },
  async getProfile(ownerId){
    const {data}=await this.client.database.from('profiles').select('*').eq('owner_id',ownerId).maybeSingle();
    return data||null;
  },
};
function authMsg(e){
  if(!e) return '操作失败';
  if(e.message) return e.message;
  return '操作失败，请重试';
}

/* 独立账号系统：无需短信或第三方账号，注册后立即生成本地世界。 */
const LOCAL_ACCOUNTS_KEY='lifeWorld.accounts.v2';
const LOCAL_SESSION_KEY='lifeWorld.session.v2';
const LOCAL_FRIENDS_KEY='lifeWorld.friendships.v2';
function localRead(key,fallback){
  try{const raw=localStorage.getItem(key);return raw?JSON.parse(raw):fallback;}catch(e){return fallback;}
}
function localWrite(key,value){
  try{localStorage.setItem(key,JSON.stringify(value));return true;}catch(e){return false;}
}
function localId(prefix){
  return prefix+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
}
function localHandle(accounts){
  let value='';
  do{
    value='';
    for(let i=0;i<8;i++) value+='0123456789'[(Math.random()*10)|0];
    if(value[0]==='0') value='1'+value.slice(1);
  }while(accounts.some(a=>a.handle===value));
  return value;
}
function localWorldKey(uid){ return 'lifeWorld.world.'+uid; }
const LOCAL_FRIEND_CARDS_KEY='lifeWorld.friendCards.v3';
const LOCAL_FRIEND_WORLDS_KEY='lifeWorld.friendWorlds.v3';
const LOCAL_PENDING_INVITE_KEY='lifeWorld.pendingInvite.v3';
function compactSharedWorld(source){
  let out;
  try{ out=JSON.parse(JSON.stringify(source||{name:'我的世界',regions:{},islands:[]})); }
  catch(e){ out={name:'我的世界',regions:{},islands:[]}; }
  out.regions=out.regions||{};
  Object.values(out.regions).forEach(region=>{
    if(!region||!Array.isArray(region.entries)) return;
    region.entries=region.entries.slice().sort((a,b)=>(Date.parse(b.date||'')||0)-(Date.parse(a.date||'')||0)).slice(0,120).map(entry=>({
      ...entry,
      audio:(entry.audioStore==='idb'&&entry.audioBlobId)?'':entry.audio,
      text:String(entry.text||'').slice(0,6000),
      images:[]
    }));
  });
  delete out._syncToken; delete out._syncUpdatedAt; delete out._syncLive;
  return out;
}
function mergeSharedWorldWithLocal(remote,local){
  let out;
  try{ out=JSON.parse(JSON.stringify(remote||{})); }
  catch(e){ return remote||local||null; }
  if(!out.regions||!local||!local.regions) return out;
  Object.keys(out.regions).forEach(regionId=>{
    const remoteRegion=out.regions[regionId], localRegion=local.regions[regionId];
    if(!remoteRegion||!Array.isArray(remoteRegion.entries)||!localRegion||!Array.isArray(localRegion.entries)) return;
    const localById={};
    localRegion.entries.forEach(entry=>{ if(entry&&entry.id) localById[entry.id]=entry; });
    remoteRegion.entries.forEach(entry=>{
      const old=entry&&entry.id&&localById[entry.id];
      if(old&&old.images&&old.images.length&&(!entry.images||!entry.images.length)) entry.images=old.images.slice();
    });
  });
  return out;
}
function friendCardMap(){ return localRead(LOCAL_FRIEND_CARDS_KEY,{}); }
function friendWorldMap(){ return localRead(LOCAL_FRIEND_WORLDS_KEY,{}); }
function storeFriendCard(profile,world){
  const ownerId=profile&&(profile.owner_id||profile.id);
  if(!ownerId) return false;
  const card={...profile,owner_id:ownerId};
  const cards=friendCardMap(); cards[ownerId]=card; localWrite(LOCAL_FRIEND_CARDS_KEY,cards);
  if(world&&world.regions){ const worlds=friendWorldMap(); worlds[ownerId]=world; localWrite(LOCAL_FRIEND_WORLDS_KEY,worlds); }
  return true;
}
function bytesToBase64Url(bytes){
  let bin='';
  for(let i=0;i<bytes.length;i+=0x8000) bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+0x8000));
  return btoa(bin).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function base64UrlToBytes(value){
  let s=String(value||'').replace(/-/g,'+').replace(/_/g,'/');
  while(s.length%4) s+='=';
  const bin=atob(s), out=new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++) out[i]=bin.charCodeAt(i);
  return out;
}
async function gzipBytes(bytes){
  if(typeof CompressionStream==='undefined') return null;
  try{
    const stream=new Blob([bytes]).stream().pipeThrough(new CompressionStream('gzip'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }catch(e){ return null; }
}
async function gunzipBytes(bytes){
  if(typeof DecompressionStream==='undefined') throw new Error('当前浏览器不支持解压邀请链接');
  const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}
async function encodeFriendInvite(profile,world){
  const payload={v:1,type:'life-world-friend',profile,world:compactSharedWorld(world),createdAt:new Date().toISOString()};
  const bytes=new TextEncoder().encode(JSON.stringify(payload));
  const zipped=await gzipBytes(bytes);
  return zipped?'LW1G.'+bytesToBase64Url(zipped):'LW1J.'+bytesToBase64Url(bytes);
}
function inviteCodeFromText(value){
  let text=String(value||'').trim();
  if(!text) return '';
  const hash=text.match(/[#?&]friend=([^&\s]+)/);
  if(hash) text=decodeURIComponent(hash[1]);
  return text;
}
async function decodeFriendInvite(value){
  const code=inviteCodeFromText(value);
  if(!/^LW1[GJ]\./.test(code)) return null;
  try{
    const packed=base64UrlToBytes(code.slice(code.indexOf('.')+1));
    const raw=code.startsWith('LW1G.')?await gunzipBytes(packed):packed;
    const data=JSON.parse(new TextDecoder().decode(raw));
    if(!data||data.type!=='life-world-friend'||!data.profile) return null;
    const ownerId=data.profile.owner_id||data.profile.id;
    if(!ownerId) return null;
    data.profile={...data.profile,owner_id:ownerId};
    return data;
  }catch(e){ return null; }
}
async function copyText(value){
  try{
    if(navigator.clipboard&&navigator.clipboard.writeText){ await navigator.clipboard.writeText(value); return true; }
  }catch(e){}
  try{
    const ta=document.createElement('textarea');
    ta.value=value; ta.style.position='fixed'; ta.style.opacity='0'; document.body.appendChild(ta);
    ta.focus(); ta.select(); const ok=document.execCommand('copy'); ta.remove(); return ok;
  }catch(e){ return false; }
}
function captureFriendInviteFromUrl(){
  const match=(location.hash||'').match(/(?:^#|[#&])friend=([^&]+)/);
  if(!match) return false;
  try{ localStorage.setItem(LOCAL_PENDING_INVITE_KEY,decodeURIComponent(match[1])); }catch(e){ return false; }
  try{ history.replaceState(null,'',location.pathname+location.search); }catch(e){}
  return true;
}
async function processPendingFriendInvite(options={}){
  let code='';
  try{ code=localStorage.getItem(LOCAL_PENDING_INVITE_KEY)||''; }catch(e){ return null; }
  if(!code||!Cloud.user) return null;
  const invite=await decodeFriendInvite(code);
  try{ localStorage.removeItem(LOCAL_PENDING_INVITE_KEY); }catch(e){}
  if(!invite){
    if(!options.silent) toast('好友邀请链接无效或已损坏');
    return null;
  }
  const result=await Cloud.addFriendCard(invite);
  if(!result.ok){
    if(!options.silent) toast(result.msg||'好友导入失败');
    return null;
  }
  renderPersona();
  if(!options.silent) toast('已添加好友 '+(result.profile.nickname||'好友')+' · 双方列表已同步');
  return result.profile;
}
function localFallbackHash(text){
  let h1=0x811c9dc5,h2=0x9e3779b9;
  for(let i=0;i<text.length;i++){
    const c=text.charCodeAt(i);
    h1=Math.imul(h1^c,16777619)>>>0;
    h2=Math.imul(h2^(c+((i*31)&255)),2246822519)>>>0;
  }
  return ('00000000'+h1.toString(16)).slice(-8)+('00000000'+h2.toString(16)).slice(-8);
}
async function localPasswordHash(password,salt){
  const text=salt+':'+password;
  try{
    if(globalThis.crypto&&globalThis.crypto.subtle){
      const bytes=new TextEncoder().encode(text);
      const digest=await globalThis.crypto.subtle.digest('SHA-256',bytes);
      return Array.from(new Uint8Array(digest)).map(b=>b.toString(16).padStart(2,'0')).join('');
    }
  }catch(e){}
  return 'local-'+localFallbackHash(text);
}
function localUsername(value){ return String(value||'').trim().toLowerCase(); }
/* 公共数据空间：账号资料、双向好友关系和最新世界都保存到这里。 */
const REMOTE_SYNC={
  base:'https://mantledb.sh/v2',
  chunkChars:40000,
  timeoutMs:9000,
  pushDelayMs:1100
};
function remoteHash(value){
  const text=String(value||'');
  let a=2166136261>>>0,b=2246822507>>>0;
  for(let i=0;i<text.length;i++){
    const code=text.charCodeAt(i);
    a=Math.imul(a^code,16777619)>>>0;
    b=Math.imul(b^code,3266489909)>>>0;
  }
  return a.toString(36)+b.toString(36);
}
function remoteAccountNamespace(username){
  return 'lw3a-'+remoteHash('account|'+localUsername(username));
}
function remoteProfileNamespace(handle){
  return 'lw3p-'+remoteHash('profile|'+String(handle||'').trim().toLowerCase());
}
function remoteWorldNamespace(ownerId){
  return 'lw3w-'+remoteHash('world|'+String(ownerId||'').trim());
}
function remoteFriendNamespace(ownerId){
  return 'lw3f-'+remoteHash('friends|'+String(ownerId||'').trim());
}
function remoteUrl(ns,path){
  const tail=String(path||'').split('/').filter(Boolean).map(encodeURIComponent).join('/');
  return REMOTE_SYNC.base+'/'+encodeURIComponent(ns)+(tail?'/'+tail:'');
}
async function remoteFetch(ns,path,options={}){
  const method=String(options.method||'GET').toUpperCase();
  const controller=typeof AbortController!=='undefined'?new AbortController():null;
  const timer=controller?setTimeout(()=>controller.abort(),REMOTE_SYNC.timeoutMs):null;
  const headers={...(options.headers||{})};
  if(options.body&&!headers['content-type']) headers['content-type']='application/json';
  let url=remoteUrl(ns,path);
  if(method==='GET') url+=(url.includes('?')?'&':'?')+'_lw='+Date.now();
  try{
    return await fetch(url,{
      method,headers,body:options.body,cache:'no-store',
      signal:controller?controller.signal:undefined,
      keepalive:!!options.keepalive
    });
  }finally{
    if(timer) clearTimeout(timer);
  }
}
async function remoteReadJSON(ns,path){
  try{
    const r=await remoteFetch(ns,path);
    if(!r.ok) return null;
    return await r.json();
  }catch(e){ return null; }
}
async function remoteWriteJSON(ns,path,data,options={}){
  const r=await remoteFetch(ns,path,{
    method:'POST',headers:{'content-type':'application/json'},
    body:JSON.stringify(data),keepalive:!!options.keepalive
  });
  if(!r.ok) throw new Error('同步服务暂时不可用 ('+r.status+')');
  try{ return await r.json(); }catch(e){ return {success:true}; }
}
function publicProfileFromAccount(account){
  const id=account&&account.id||'';
  return {
    id, owner_id:id, handle:account&&account.handle||'',
    nickname:account&&account.nickname||'好友',
    world_name:account&&(account.worldName||account.world_name)||'我的世界',
    avatar:account&&account.avatar||'🌏',
    syncId:String(account&&(account.syncId||account.id)||id),
    created_at:account&&account.createdAt||''
  };
}
async function remoteReadAccountRecord(username){
  const record=await remoteReadJSON(remoteAccountNamespace(username),'account');
  if(!record||localUsername(record.username)!==localUsername(username)) return null;
  return {...record,syncId:String(record.syncId||record.id||'')};
}
async function remotePushAccount(account){
  if(!account||!account.id||!account.username) return false;
  const record={
    id:account.id,username:localUsername(account.username),nickname:account.nickname,
    handle:account.handle,salt:account.salt,passwordHash:account.passwordHash,
    createdAt:account.createdAt,worldName:account.worldName||'我的世界',
    syncId:String(account.syncId||account.id),updatedAt:new Date().toISOString()
  };
  await remoteWriteJSON(remoteAccountNamespace(account.username),'account',record);
  await remoteWriteJSON(remoteProfileNamespace(account.handle),'profile',publicProfileFromAccount({...account,...record}));
  return true;
}
async function remoteReadPublicProfile(handle){
  const wanted=String(handle||'').trim().toLowerCase();
  if(!wanted) return null;
  const profile=await remoteReadJSON(remoteProfileNamespace(wanted),'profile');
  if(!profile||String(profile.handle||'').trim().toLowerCase()!==wanted) return null;
  const id=profile.owner_id||profile.id;
  if(!id) return null;
  return {...profile,id,owner_id:id,syncId:String(profile.syncId||id)};
}
async function remoteEncodeWorld(source){
  const world=compactSharedWorld(source);
  if(!world.updatedAt) world.updatedAt=new Date().toISOString();
  const raw=new TextEncoder().encode(JSON.stringify(world));
  const zipped=await gzipBytes(raw);
  const packed=zipped||raw;
  const encoded=bytesToBase64Url(packed);
  const chunks=[];
  for(let offset=0,index=0;offset<encoded.length;offset+=REMOTE_SYNC.chunkChars,index++){
    chunks.push({index,data:encoded.slice(offset,offset+REMOTE_SYNC.chunkChars)});
  }
  const token=localId('r');
  return {
    manifest:{
      version:2,token,compressed:!!zipped,chunkCount:chunks.length,
      chunkChars:REMOTE_SYNC.chunkChars,packedBytes:packed.length,
      updatedAt:world.updatedAt
    },
    chunks
  };
}
async function remotePushWorldDocument(world,ownerId){
  if(!ownerId) return false;
  const encoded=await remoteEncodeWorld(world);
  const ns=remoteWorldNamespace(ownerId);
  await Promise.all(encoded.chunks.map(chunk=>remoteWriteJSON(
    ns,'chunks/'+chunk.index,{token:encoded.manifest.token,index:chunk.index,data:chunk.data}
  )));
  await remoteWriteJSON(ns,'world',encoded.manifest);
  return true;
}
async function remotePullWorldDocument(ownerId){
  if(!ownerId) return null;
  const ns=remoteWorldNamespace(ownerId);
  const manifest=await remoteReadJSON(ns,'world');
  if(!manifest||manifest.version!==2||!manifest.token||!Number.isFinite(Number(manifest.chunkCount))) return null;
  const count=Number(manifest.chunkCount);
  if(count<1||count>100) return null;
  const records=await Promise.all(Array.from({length:count},(_,index)=>remoteReadJSON(ns,'chunks/'+index)));
  const parts=[];
  for(let index=0;index<count;index++){
    const record=records[index];
    if(!record||record.token!==manifest.token||Number(record.index)!==index||typeof record.data!=='string') return null;
    parts.push(record.data);
  }
  try{
    const bytes=base64UrlToBytes(parts.join(''));
    const raw=manifest.compressed?await gunzipBytes(bytes):bytes;
    const world=JSON.parse(new TextDecoder().decode(raw));
    if(!world||!world.regions) return null;
    world._syncToken=manifest.token;
    world._syncUpdatedAt=manifest.updatedAt||'';
    world._syncLive=true;
    return world;
  }catch(e){ return null; }
}
async function remoteReadFriendList(ownerId){
  if(!ownerId) return [];
  const data=await remoteReadJSON(remoteFriendNamespace(ownerId),'friends');
  return data&&Array.isArray(data.friends)?data.friends:[];
}
async function remoteWriteFriendList(ownerId,list){
  if(!ownerId) return false;
  await remoteWriteJSON(remoteFriendNamespace(ownerId),'friends',{
    version:1,ownerId,updatedAt:new Date().toISOString(),
    friends:Array.from(new Map((list||[]).map(item=>[String(item&&item.friend_id||''),item])).values()).filter(item=>item&&item.friend_id).slice(0,500)
  });
  return true;
}
function remoteFriendRecord(ownerId,friendProfile){
  const friendId=String(friendProfile&&(friendProfile.owner_id||friendProfile.id)||'');
  if(!ownerId||!friendId) return null;
  const profile={...friendProfile,owner_id:friendId,id:friendId,syncId:String(friendProfile.syncId||friendId)};
  return {
    id:'rf-'+remoteHash([String(ownerId),friendId].sort().join('|')),
    owner_id:String(ownerId),friend_id:friendId,status:'accepted',remote:true,
    created_at:new Date().toISOString(),profile
  };
}
async function remoteUpsertMutualFriend(me,friendProfile){
  if(!me||!me.id||!friendProfile) return false;
  const friendId=String(friendProfile.owner_id||friendProfile.id||'');
  if(!friendId||friendId===String(me.id)) return false;
  const meProfile=publicProfileFromAccount({...me,id:me.id,syncId:String(me.syncId||me.id)});
  const mineRecord=remoteFriendRecord(me.id,friendProfile);
  const theirsRecord=remoteFriendRecord(friendId,meProfile);
  const mine=await remoteReadFriendList(me.id).catch(()=>[]);
  const theirs=await remoteReadFriendList(friendId).catch(()=>[]);
  const put=(list,record)=>{
    const next=list.filter(item=>String(item&&item.friend_id||'')!==String(record.friend_id));
    next.push(record);
    return next;
  };
  await Promise.all([
    remoteWriteFriendList(me.id,put(mine,mineRecord)),
    remoteWriteFriendList(friendId,put(theirs,theirsRecord))
  ]);
  storeFriendCard(friendProfile,null);
  return true;
}
async function remoteRemoveMutualFriend(ownerId,friendId){
  if(!ownerId||!friendId) return false;
  const mine=await remoteReadFriendList(ownerId).catch(()=>[]);
  const theirs=await remoteReadFriendList(friendId).catch(()=>[]);
  await Promise.all([
    remoteWriteFriendList(ownerId,mine.filter(item=>String(item&&item.friend_id||'')!==String(friendId))),
    remoteWriteFriendList(friendId,theirs.filter(item=>String(item&&item.friend_id||'')!==String(ownerId)))
  ]);
  return true;
}
/* 每条记忆的点赞与评论共享给能进入该好友世界的人。 */
function remoteInteractionNamespace(ownerId,regionId,entryId){
  return 'lw3i-'+remoteHash('interaction|'+String(ownerId||'')+'|'+String(regionId||'')+'|'+String(entryId||''));
}
function emptyInteraction(ownerId,regionId,entryId){
  return {version:1,ownerId:String(ownerId||''),regionId:String(regionId||''),entryId:String(entryId||''),likes:[],comments:[],updatedAt:''};
}
function interactionActor(profile){
  const id=String(profile&&(profile.id||profile.owner_id||profile.userId)||'').trim();
  const handle=String(profile&&profile.handle||'').trim();
  const key=id||handle;
  if(!key) return null;
  return {userId:id||handle,handle,nickname:String(profile&&profile.nickname||'好友').slice(0,24),avatar:String(profile&&profile.avatar||'🌏').slice(0,8)};
}
async function remoteReadInteraction(ownerId,regionId,entryId){
  const fallback=emptyInteraction(ownerId,regionId,entryId);
  const data=await remoteReadJSON(remoteInteractionNamespace(ownerId,regionId,entryId),'thread');
  if(!data||typeof data!=='object') return fallback;
  return {
    ...fallback,
    likes:Array.isArray(data.likes)?data.likes.filter(x=>x&&(x.userId||x.handle)).slice(0,200):[],
    comments:Array.isArray(data.comments)?data.comments.filter(x=>x&&x.text).slice(-200):[],
    updatedAt:String(data.updatedAt||'')
  };
}
async function remoteWriteInteraction(doc){
  const clean={
    version:1,ownerId:String(doc.ownerId||''),regionId:String(doc.regionId||''),entryId:String(doc.entryId||''),
    likes:Array.isArray(doc.likes)?doc.likes.slice(0,200):[],
    comments:Array.isArray(doc.comments)?doc.comments.slice(-200):[],
    updatedAt:new Date().toISOString()
  };
  await remoteWriteJSON(remoteInteractionNamespace(clean.ownerId,clean.regionId,clean.entryId),'thread',clean);
  return clean;
}
async function remoteToggleMemoryLike(ownerId,regionId,entryId,profile){
  const actor=interactionActor(profile);
  if(!actor) throw new Error('请先登录后再点赞');
  const doc=await remoteReadInteraction(ownerId,regionId,entryId);
  const index=doc.likes.findIndex(x=>String(x.userId||x.handle)===String(actor.userId));
  if(index>=0) doc.likes.splice(index,1);
  else doc.likes.push({...actor,createdAt:new Date().toISOString()});
  return remoteWriteInteraction(doc);
}
async function remoteAddMemoryComment(ownerId,regionId,entryId,profile,text){
  const actor=interactionActor(profile);
  if(!actor) throw new Error('请先登录后再评论');
  const clean=String(text||'').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').trim();
  if(!clean) throw new Error('评论内容不能为空');
  if(clean.length>500) throw new Error('评论最多 500 个字符');
  const doc=await remoteReadInteraction(ownerId,regionId,entryId);
  doc.comments.push({id:localId('c'),...actor,text:clean,createdAt:new Date().toISOString()});
  return remoteWriteInteraction(doc);
}
const LocalAuth={
  accounts(){ return localRead(LOCAL_ACCOUNTS_KEY,[]); },
  saveAccounts(list){ return localWrite(LOCAL_ACCOUNTS_KEY,list); },
  current(){
    const uid=localRead(LOCAL_SESSION_KEY,'');
    if(!uid) return null;
    return this.accounts().find(a=>a.id===uid)||null;
  },
  enter(account){ localWrite(LOCAL_SESSION_KEY,account.id); },
  exit(){ try{localStorage.removeItem(LOCAL_SESSION_KEY);}catch(e){} },
  async register(input){
    const nickname=String(input.nickname||'').trim();
    const username=localUsername(input.username);
    const password=String(input.password||'');
    if(!nickname) return {ok:false,msg:'请输入昵称'};
    if(nickname.length>16) return {ok:false,msg:'昵称不能超过 16 个字符'};
    if(!/^[a-z0-9._@+-]{3,40}$/.test(username)) return {ok:false,msg:'账号需为 3-40 位字母、数字或邮箱'};
    if(password.length<6) return {ok:false,msg:'密码至少需要 6 位'};
    const accounts=this.accounts();
    if(accounts.some(a=>a.username===username)) return {ok:false,msg:'这个账号已经注册过了'};
    const remoteAccount=await remoteReadAccountRecord(username).catch(()=>null);
    if(remoteAccount) return {ok:false,msg:'这个账号已经注册过了，请直接登录'};
    const salt=localId('s');
    const account={
      id:localId('u'), username, nickname, handle:localHandle(accounts), salt,
      passwordHash:await localPasswordHash(password,salt),
      createdAt:new Date().toISOString(),
      worldName:'我的世界', syncId:''
    };
    account.syncId=account.id;
    accounts.push(account);
    if(!this.saveAccounts(accounts)) return {ok:false,msg:'浏览器存储不可用，请关闭无痕模式后重试'};
    this.enter(account);
    try{ await remotePushAccount(account); }catch(e){}
    return {ok:true,account};
  },
  async login(input){
    const username=localUsername(input.username);
    const password=String(input.password||'');
    let account=this.accounts().find(a=>a.username===username);
    if(!account){
      const remoteAccount=await remoteReadAccountRecord(username).catch(()=>null);
      if(remoteAccount){
        const remotePasswordHash=await localPasswordHash(password,remoteAccount.salt);
        if(remotePasswordHash===remoteAccount.passwordHash){
          account={...remoteAccount,syncId:String(remoteAccount.syncId||remoteAccount.id)};
          const accounts=this.accounts();
          const index=accounts.findIndex(a=>a.id===account.id||a.username===account.username);
          if(index>=0) accounts[index]={...accounts[index],...account};
          else accounts.push(account);
          this.saveAccounts(accounts);
        }
      }
    }
    if(!account) return {ok:false,msg:'账号或密码不正确'};
    const hash=await localPasswordHash(password,account.salt);
    if(hash!==account.passwordHash) return {ok:false,msg:'账号或密码不正确'};
    if(!account.syncId) account.syncId=account.id;
    const accounts=this.accounts();
    const index=accounts.findIndex(a=>a.id===account.id);
    if(index>=0) accounts[index]={...accounts[index],...account};
    else accounts.push(account);
    this.saveAccounts(accounts);
    this.enter(account);
    try{ await remotePushAccount(account); }catch(e){}
    return {ok:true,account};
  }
};
function accountProfile(account){
  return publicProfileFromAccount(account);
}
Object.assign(Cloud,{
  client:null, ready:true, _pushTimer:null, _pendingWorld:null, _remotePushing:false, _remotePushAgain:false,
  init(){
    const account=LocalAuth.current();
    if(!account){ this.user=null; this.profile=null; return false; }
    this.user={id:account.id,email:account.username,name:account.nickname};
    this.profile=accountProfile(account);
    localStorage.setItem(KEY_UID,account.id);
    return true;
  },
  async wechatLogin(){ return {ok:false,msg:'请使用上方账号注册或登录'}; },
  async handleWechatCallback(){ return {ok:true,session:false}; },
  async _afterLogin(){ return {ok:false,msg:'请使用账号注册或登录'}; },
  async logout(){
    if(this.user&&!this.guest){
      try{ await this.flushRemoteWorld(); await this.pushWorld(state,{immediate:true}); }catch(e){}
    }
    LocalAuth.exit();
    this.user=null; this.profile=null; this.guest=null;
    localStorage.removeItem(KEY_UID);
    ISLANDS=ISLANDS.filter(i=>!i.custom);
    seedData();
    applyCustomIslands();
    ISLANDS.forEach(i=>ensureRegion(i.id));
    rebuildWorld(); buildChips(); refreshHeader();
    const wc=worldCenter(); cam.zoom=cam.tz=fitZoom*0.98; cam.x=cam.tx=wc[0]; cam.y=cam.ty=wc[1]; clampCam();
    updateAccountUI();
  },
  async ensureRemoteIdentity(account){
    const current=account||LocalAuth.current();
    if(!current) return false;
    try{ return await remotePushAccount(current); }
    catch(e){ return false; }
  },
  async pullWorld(){
    if(!this.user||!this.user.id) return null;
    const remote=await remotePullWorldDocument(this.user.id).catch(()=>null);
    if(remote) return remote;
    return localRead(localWorldKey(this.user.id),null);
  },
  scheduleRemotePush(world){
    if(!this.user||!this.user.id||this.guest||!world) return;
    this._pendingWorld=compactSharedWorld(world);
    if(this._pushTimer) clearTimeout(this._pushTimer);
    this._pushTimer=setTimeout(()=>{ this._pushTimer=null; this.flushRemoteWorld(); },REMOTE_SYNC.pushDelayMs);
  },
  async flushRemoteWorld(){
    if(!this.user||!this.user.id||this.guest) return false;
    if(this._remotePushing){ this._remotePushAgain=true; return false; }
    const snapshot=this._pendingWorld;
    this._pendingWorld=null;
    if(!snapshot) return true;
    this._remotePushing=true;
    try{
      await remotePushWorldDocument(snapshot,this.user.id);
      return true;
    }catch(e){
      if(!this._pendingWorld) this._pendingWorld=snapshot;
      if(!this._pushTimer) this._pushTimer=setTimeout(()=>{ this._pushTimer=null; this.flushRemoteWorld(); },4000);
      return false;
    }finally{
      this._remotePushing=false;
      if(this._remotePushAgain){
        this._remotePushAgain=false;
        if(this._pendingWorld&&!this._pushTimer) this.scheduleRemotePush(this._pendingWorld);
      }
    }
  },
  async pushWorld(world,options={}){
    if(!this.user||!this.user.id||this.guest) return false;
    if(!world.updatedAt) world.updatedAt=new Date().toISOString();
    localWrite(localWorldKey(this.user.id),world);
    if(options.immediate){
      try{ await remotePushWorldDocument(world,this.user.id); return true; }
      catch(e){ return false; }
    }
    this.scheduleRemotePush(world);
    return true;
  },
  async searchByHandle(input){
    const raw=String(input||'').trim();
    const invite=await decodeFriendInvite(raw);
    if(invite) return {ok:true,profile:invite.profile,world:invite.world,invite:true};
    const remoteProfile=await remoteReadPublicProfile(raw).catch(()=>null);
    if(remoteProfile) return {ok:true,profile:remoteProfile};
    const account=LocalAuth.accounts().find(a=>a.handle===raw);
    if(account) return {ok:true,profile:accountProfile(account)};
    return {ok:false,msg:'没有找到这个 ID，请确认对方已经注册并登录过，也可以让对方复制邀请链接给你'};
  },
  async addFriendCard(card){
    if(!this.user) return {ok:false,msg:'请先登录'};
    const rawProfile=(card&&card.profile)||card;
    const ownerId=rawProfile&&(rawProfile.owner_id||rawProfile.id);
    if(!ownerId) return {ok:false,msg:'好友资料无效'};
    if(ownerId===this.user.id) return {ok:false,msg:'不能添加自己'};
    const profile={...rawProfile,id:ownerId,owner_id:ownerId,syncId:String(rawProfile.syncId||ownerId)};
    const account=LocalAuth.current()||{};
    const me={
      id:this.user.id,
      handle:(this.profile&&this.profile.handle)||account.handle||'',
      nickname:(this.profile&&this.profile.nickname)||account.nickname||this.user.name||'好友',
      worldName:(this.profile&&this.profile.world_name)||account.worldName||'我的世界',
      avatar:(this.profile&&this.profile.avatar)||account.avatar||'🌏',
      syncId:String((this.profile&&this.profile.syncId)||account.syncId||this.user.id)
    };
    try{
      await remoteUpsertMutualFriend(me,profile);
    }catch(e){
      return {ok:false,msg:'好友同步失败，请检查网络后重试'};
    }
    storeFriendCard(profile,card&&card.world||null);
    const list=localRead(LOCAL_FRIENDS_KEY,[]);
    const existing=list.find(f=>(f.owner_id===this.user.id&&f.friend_id===ownerId)||(f.owner_id===ownerId&&f.friend_id===this.user.id));
    if(existing){
      existing.status='accepted';
      existing.owner_id=this.user.id;
      existing.friend_id=ownerId;
      existing.remote=true;
    }else{
      list.push({id:'rf-'+remoteHash([String(this.user.id),String(ownerId)].sort().join('|')),owner_id:this.user.id,friend_id:ownerId,status:'accepted',remote:true,created_at:new Date().toISOString(),profile});
    }
    localWrite(LOCAL_FRIENDS_KEY,list);
    return {ok:true,profile};
  },
  async sendFriendRequest(friendId){
    if(!this.user) return {ok:false,msg:'请先登录'};
    if(friendId===this.user.id) return {ok:false,msg:'不能添加自己'};
    const card=friendCardMap()[friendId];
    if(card) return this.addFriendCard({profile:card,world:friendWorldMap()[friendId]||null});
    const list=localRead(LOCAL_FRIENDS_KEY,[]);
    const exists=list.some(f=>(f.owner_id===this.user.id&&f.friend_id===friendId)||(f.owner_id===friendId&&f.friend_id===this.user.id));
    if(exists) return {ok:false,msg:'好友请求已经发送过了'};
    list.push({id:localId('f'),owner_id:this.user.id,friend_id:friendId,status:'pending',created_at:new Date().toISOString()});
    localWrite(LOCAL_FRIENDS_KEY,list);
    return {ok:true};
  },
  async listFriends(){
    if(!this.user) return [];
    const uid=String(this.user.id);
    const local=localRead(LOCAL_FRIENDS_KEY,[]).filter(f=>String(f.owner_id)===uid||String(f.friend_id)===uid);
    const remote=await remoteReadFriendList(uid).catch(()=>[]);
    const merged=new Map();
    remote.forEach(item=>{
      const friendId=String(item&&item.friend_id||'');
      if(!friendId) return;
      if(item.profile) storeFriendCard({...item.profile,owner_id:friendId,id:friendId,syncId:String(item.profile.syncId||friendId)},null);
      merged.set('remote:'+friendId,{...item,id:item.id||('rf-'+remoteHash([uid,friendId].sort().join('|'))),owner_id:uid,friend_id:friendId,status:'accepted',remote:true});
    });
    local.forEach(item=>{
      const other=String(item.owner_id)===uid?String(item.friend_id):String(item.owner_id);
      if(!other||merged.has('remote:'+other)) return;
      merged.set('local:'+String(item.id||other),item);
    });
    return Array.from(merged.values());
  },
  async respondRequest(id,accept){
    let list=localRead(LOCAL_FRIENDS_KEY,[]);
    if(accept) list=list.map(f=>f.id===id?{...f,status:'accepted'}:f);
    else list=list.filter(f=>f.id!==id);
    localWrite(LOCAL_FRIENDS_KEY,list);
    return {ok:true};
  },
  async removeFriend(id){
    const uid=String(this.user&&this.user.id||'');
    if(!uid) return {ok:false,msg:'请先登录'};
    const local=localRead(LOCAL_FRIENDS_KEY,[]);
    const target=local.find(f=>String(f.id)===String(id)||String(f.friend_id)===String(id)||String(f.owner_id)===String(id));
    const friendId=target?(String(target.owner_id)===uid?String(target.friend_id):String(target.owner_id)):String(id);
    try{ await remoteRemoveMutualFriend(uid,friendId); }catch(e){ return {ok:false,msg:'删除好友失败，请稍后重试'}; }
    const next=local.filter(f=>{
      const other=String(f.owner_id)===uid?String(f.friend_id):String(f.owner_id);
      return String(f.id)!==String(id)&&other!==friendId;
    });
    localWrite(LOCAL_FRIENDS_KEY,next);
    return {ok:true};
  },
  async viewFriendWorld(ownerId){
    const card=friendCardMap()[ownerId]||{};
    const syncId=String(card.syncId||ownerId||'');
    const live=await remotePullWorldDocument(syncId).catch(()=>null);
    if(live){
      storeFriendCard({...card,id:ownerId,owner_id:ownerId,syncId},live);
      return {ok:true,data:live,live:true};
    }
    const shared=friendWorldMap()[ownerId];
    const data=shared||localRead(localWorldKey(ownerId),null);
    if(!data) return {ok:false,msg:'暂时没有读到 TA 的最新世界，请稍后重试'};
    return {ok:true,data,live:false};
  },
  async getProfile(ownerId){
    const card=friendCardMap()[ownerId];
    if(card) return card;
    const remoteList=await remoteReadFriendList(this.user&&this.user.id).catch(()=>[]);
    const match=remoteList.find(item=>String(item.friend_id)===String(ownerId)||String(item.profile&&(item.profile.id||item.profile.owner_id))===String(ownerId));
    if(match&&match.profile){ storeFriendCard(match.profile,null); return match.profile; }
    const account=LocalAuth.accounts().find(a=>a.id===ownerId);
    return account?accountProfile(account):null;
  }
});
/* 账号 UI 状态同步 */
function updateAccountUI(){
  const btn=$('btnAccount');
  const p=Cloud.profile;
  if(Cloud.user&&p){
    const name=p.nickname||Cloud.user.email||'我';
    btn.textContent='👤 '+name;
    btn.title='账号：'+name+' · ID '+p.handle;
    $('paName').textContent=name;
    $('paId').textContent=p.handle;
    $('paAv').textContent='🌏';
    if(Cloud.guest){ $('paLogout').textContent='返回我的世界'; }
    else{ $('paLogout').textContent='退出登录'; }
  }else{
    btn.textContent='👤 登录';
    btn.title='登录账号（云端同步 + 好友）';
    $('paName').textContent='未登录';
    $('paId').textContent='00000000';
    $('paLogout').textContent='登录账号';
  }
}
let authMode='register';
function passwordStrength(value){
  const p=String(value||'');
  let score=0;
  if(p.length>=6) score++;
  if(p.length>=10) score++;
  if(/[a-z]/i.test(p)&&/\d/.test(p)) score++;
  if(/[^a-z0-9]/i.test(p)) score++;
  return Math.min(score,4);
}
function updateAuthStrength(){
  const lights=$('authStrength').querySelectorAll('i');
  const score=passwordStrength($('authPass').value);
  lights.forEach((el,i)=>el.classList.toggle('on',i<score));
}
function setAuthMode(mode){
  authMode=mode==='login'?'login':'register';
  const register=authMode==='register';
  document.querySelectorAll('[data-auth-mode]').forEach(tab=>{
    const active=tab.dataset.authMode===authMode;
    tab.classList.toggle('on',active);
    tab.setAttribute('aria-selected',active?'true':'false');
  });
  $('authTitle').textContent=register?'创建你的世界账号':'欢迎回来';
  $('authSub').textContent=register?'一个账号，保存一座只属于你的生活世界。':'登录后继续走进你的生活世界。';
  $('authNameLbl').classList.toggle('field-hide',!register);
  $('authName').classList.toggle('field-hide',!register);
  $('authStrength').classList.toggle('field-hide',!register);
  $('authPass2Wrap').classList.toggle('field-hide',!register);
  $('authPass').setAttribute('autocomplete',register?'new-password':'current-password');
  $('authPass').placeholder=register?'至少 6 位':'输入密码';
  $('authGo').textContent=register?'创建账号':'登录';
  $('authErr').textContent='';
  updateAuthStrength();
}
function openAuth(mode='register'){
  setAuthMode(mode);
  $('authGo').disabled=false;
  $('auth').classList.remove('hide');
  setTimeout(()=>{ const el=authMode==='register'?$('authName'):$('authUser'); if(el) el.focus(); },80);
}
function closeAuth(){
  $('auth').classList.add('hide');
}
async function submitAuth(){
  const err=$('authErr'), go=$('authGo');
  const mode=authMode;
  err.textContent='';
  const nickname=$('authName').value.trim();
  const username=$('authUser').value.trim();
  const password=$('authPass').value;
  if(mode==='register'&&password!==$('authPass2').value){
    err.textContent='两次输入的密码不一致';
    return;
  }
  go.disabled=true;
  go.textContent=mode==='register'?'正在创建…':'正在登录…';
  try{
    const result=mode==='register'
      ? await LocalAuth.register({nickname,username,password})
      : await LocalAuth.login({username,password});
    if(!result.ok){
      err.textContent=result.msg;
      go.disabled=false;
      go.textContent=mode==='register'?'创建账号':'登录';
      return;
    }
    const account=result.account;
    Cloud.user={id:account.id,email:account.username,name:account.nickname};
    Cloud.profile=accountProfile(account);
    Cloud.guest=null;
    localStorage.setItem(KEY_UID,account.id);
    updateAccountUI();
    closeAuth();
    $('authPass').value='';
    $('authPass2').value='';
    await syncFromCloud({silent:true});
    const inviteFriend=await processPendingFriendInvite({silent:true});
    const name=account.nickname||account.username;
    if(inviteFriend){
      toast((mode==='register'?'注册成功':'欢迎回来')+'，已添加好友 '+(inviteFriend.nickname||'好友'));
    }else if(mode==='register'){
      toast('注册成功，'+name+' ✦ 你的专属 ID：'+account.handle);
    }else{
      toast('欢迎回来，'+name+' ✦ 专属 ID：'+account.handle);
    }
  }catch(e){
    err.textContent='暂时无法完成操作，请重试';
    go.disabled=false;
    go.textContent=mode==='register'?'创建账号':'登录';
  }
}
/* 登录成功后载入当前账号自己的世界 */
async function syncFromCloud(options={}){
  if(!Cloud.user) return false;
  await Cloud.ensureRemoteIdentity();
  const remote=await Cloud.pullWorld();
  if(!remote||!remote.regions){
    if(!state||!state.regions) seedData();
    await Cloud.pushWorld(state,{immediate:true});
  }else{
    const localWorld=state&&state.regions?state:null;
    const localStamp=localWorld?Date.parse(localWorld.updatedAt||'')||0:0;
    const remoteStamp=Date.parse(remote.updatedAt||'')||0;
    if(localWorld&&localStamp>remoteStamp){
      state=localWorld;
      await Cloud.pushWorld(state,{immediate:true});
    }else{
      state=mergeSharedWorldWithLocal(remote,localWorld);
      try{ localStorage.setItem(KEY,JSON.stringify(state)); }catch(e){}
    }
  }
  ISLANDS=ISLANDS.filter(i=>!i.custom);
  if(!state.islands) state.islands=[];
  applyCustomIslands();
  ISLANDS.forEach(i=>ensureRegion(i.id));
  rebuildWorld(); buildChips(); refreshHeader();
  const wc=worldCenter(); cam.zoom=cam.tz=fitZoom*0.98; cam.x=cam.tx=wc[0]; cam.y=cam.ty=wc[1]; clampCam();
  if(!options.silent) toast(options.message||'已载入你的世界');
  return true;
}
/* 进入好友世界（只读，自动读取最新版本） */
let friendRefreshTimer=null, friendRefreshBusy=false, friendLastSyncToken='';
function stopFriendAutoRefresh(){
  if(friendRefreshTimer){ clearInterval(friendRefreshTimer); friendRefreshTimer=null; }
}
function renderFriendWorld(data,prof,resetCamera){
  state=data;
  ISLANDS=ISLANDS.filter(i=>!i.custom);
  applyCustomIslands();
  ISLANDS.forEach(i=>ensureRegion(i.id));
  rebuildWorld(); buildChips(); refreshHeader();
  $('guestName').textContent=(prof&&prof.nickname)||'好友';
  $('guestBar').classList.add('show');
  $('btnAdd').style.display='none';
  setReadOnly(true);
  if(resetCamera){
    const wc=worldCenter(); cam.zoom=cam.tz=fitZoom*0.98; cam.x=cam.tx=wc[0]; cam.y=cam.ty=wc[1]; clampCam();
  }
}
async function refreshFriendWorld(options={}){
  if(!Cloud.guest||friendRefreshBusy) return false;
  if(options.silent&&document.hidden) return false;
  friendRefreshBusy=true;
  try{
    const ownerId=Cloud.guest.ownerId;
    const r=await Cloud.viewFriendWorld(ownerId);
    if(!r.ok){ if(!options.silent) toast(r.msg); return false; }
    if(!r.data||!r.data.regions){ if(!options.silent) toast('TA 的世界还是空的'); return false; }
    const token=String(r.data._syncToken||'');
    if(r.live&&token&&token!==friendLastSyncToken){
      friendLastSyncToken=token;
      const prof=await Cloud.getProfile(ownerId);
      Cloud.guest.profile=prof||Cloud.guest.profile;
      renderFriendWorld(r.data,Cloud.guest.profile,false);
      toast('已同步 '+(Cloud.guest.profile&&Cloud.guest.profile.nickname||'好友')+' 的最新世界');
      return true;
    }
    if(!options.silent) toast(r.live?'已经是最新版本':'当前显示的是最近保存的好友版本');
    return false;
  }finally{
    friendRefreshBusy=false;
  }
}
async function enterFriendWorld(ownerId){
  stopFriendAutoRefresh();
  const r=await Cloud.viewFriendWorld(ownerId);
  if(!r.ok){ toast(r.msg); return; }
  const prof=await Cloud.getProfile(ownerId);
  if(!r.data||!r.data.regions){ toast('TA 的世界还是空的'); return; }
  Cloud.guest={ownerId, profile:prof};
  friendLastSyncToken=String(r.data._syncToken||'');
  renderFriendWorld(r.data,prof,true);
  closeAll();
  updateAccountUI();
  friendRefreshTimer=setInterval(()=>refreshFriendWorld({silent:true}),7000);
  toast('已进入 '+(prof&&prof.nickname||'好友')+' 的世界 · 会自动更新');
}
function exitFriendWorld(){
  stopFriendAutoRefresh();
  friendLastSyncToken='';
  Cloud.guest=null;
  $('guestBar').classList.remove('show');
  $('btnAdd').style.display='';
  setReadOnly(false);
  // 恢复自己的世界
  loadState();
  ISLANDS=ISLANDS.filter(i=>!i.custom);
  applyCustomIslands();
  ISLANDS.forEach(i=>ensureRegion(i.id));
  rebuildWorld(); buildChips(); refreshHeader();
  const wc=worldCenter(); cam.zoom=cam.tz=fitZoom*0.98; cam.x=cam.tx=wc[0]; cam.y=cam.ty=wc[1]; clampCam();
  closeAll(); updateAccountUI(); toast('回到我的世界');
}
/* 只读模式：禁止增删改 */
let readOnly=false;
function setReadOnly(v){
  readOnly=v;
  const edit=$('rsAdd'), del=$('rsDel');
  if(edit) edit.style.display=v?'none':'';
  if(del) del.style.display=v?'none':'';
}
/* 好友面板渲染 */
let friendListRefreshTimer=null;
function stopFriendListAutoRefresh(){
  if(friendListRefreshTimer){ clearInterval(friendListRefreshTimer); friendListRefreshTimer=null; }
}
function startFriendListAutoRefresh(){
  stopFriendListAutoRefresh();
  friendListRefreshTimer=setInterval(()=>{
    const p=$('persona');
    if(p&&p.classList.contains('open')&&!Cloud.guest) renderPersona({quiet:true});
  },7000);
}
function renderPersona(options={}){
  const f=$('paFriends'), r=$('paRequests');
  if(!Cloud.user||!Cloud.profile){ f.innerHTML='<div class="empty">登录后才能查看好友</div>'; r.innerHTML=''; return; }
  if(!options.quiet) f.innerHTML='<div class="empty">加载中…</div>';
  Cloud.listFriends().then(async list=>{
    if(Cloud.guest) return;
    const uid=Cloud.user.id;
    const accepted=list.filter(x=>x.status==='accepted');
    const pendingIn=list.filter(x=>x.status==='pending'&&x.friend_id===uid); // 别人发来的
    // 渲染好友
    if(!accepted.length){
      f.innerHTML='<div class="empty">还没有好友 · 用上面的 ID 搜索添加</div>';
    }else{
      f.innerHTML='';
      for(const fr of accepted){
        const other=fr.owner_id===uid?fr.friend_id:fr.owner_id;
        const prof=await Cloud.getProfile(other);
        const name=(prof&&prof.nickname)||'好友';
        const handle=(prof&&prof.handle)||'';
        const div=document.createElement('div'); div.className='frow';
        div.innerHTML='<div class="fav">🌏</div><div class="fm"><b>'+esc(name)+'</b><span>'+esc(handle)+'</span></div>'+
          '<button class="fbtn" data-enter="'+other+'">进入世界</button>'+
          '<button class="fbtn ghost" data-del="'+fr.id+'">删除</button>';
        f.appendChild(div);
      }
    }
    // 渲染收到的请求
    if(!pendingIn.length){
      r.innerHTML='<div class="empty" style="padding:6px 10px;font-size:11px">暂无新请求</div>';
    }else{
      r.innerHTML='';
      for(const fr of pendingIn){
        const prof=await Cloud.getProfile(fr.owner_id);
        const name=(prof&&prof.nickname)||'陌生人';
        const div=document.createElement('div'); div.className='frow';
        div.innerHTML='<div class="fav">🌏</div><div class="fm"><b>'+esc(name)+'</b><span>'+esc(prof&&prof.handle||'')+'</span></div>'+
          '<button class="fbtn" data-acc="'+fr.id+'">接受</button>'+
          '<button class="fbtn ghost" data-rej="'+fr.id+'">拒绝</button>';
        r.appendChild(div);
      }
    }
  });
}
function esc(s){ return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
/* 绑定账号 UI 事件 */
function bindAccountUI(){
  $('btnAccount').onclick=e=>{ e.stopPropagation(); togglePersona(); };
  $('btnLogin').onclick=()=>{ openAuth('register'); };
  $('authGo').onclick=submitAuth;
  $('authBack').onclick=()=>{ closeAuth(); };
  document.querySelectorAll('[data-auth-mode]').forEach(tab=>{
    tab.onclick=()=>setAuthMode(tab.dataset.authMode);
  });
  $('authPass').addEventListener('input',updateAuthStrength);
  ['authName','authUser','authPass','authPass2'].forEach(id=>{
    $(id).addEventListener('keydown',e=>{ if(e.key==='Enter'){ e.preventDefault(); submitAuth(); } });
  });
  $('paLogout').onclick=async()=>{
    if(Cloud.guest){ exitFriendWorld(); }
    else if(Cloud.user){ await Cloud.logout(); closePersona(); toast('已退出登录'); }
    else{ closePersona(); openAuth('login'); }
  };
  $('paFindBtn').onclick=async()=>{
    if(!Cloud.user){ toast('请先登录后再添加好友'); openAuth('login'); return; }
    const v=$('paFind').value.trim();
    if(!v){ toast('请输入好友 ID'); return; }
    const res=await Cloud.searchByHandle(v);
    if(!res.ok){ toast(res.msg); return; }
    if(res.profile.owner_id===Cloud.user.id){ toast('这是你自己的 ID'); return; }
    if(res.invite){
      const r2=await Cloud.addFriendCard(res);
      if(!r2.ok){ toast(r2.msg); return; }
      $('paFind').value='';
      renderPersona();
      toast('已添加好友 '+(r2.profile.nickname||'好友')+' · 可以查看邀请时的世界快照');
      return;
    }
    const r2=await Cloud.addFriendCard({profile:res.profile,world:res.world||null});
    if(r2.ok){
      $('paFind').value='';
      renderPersona();
      toast('已和 '+(res.profile.nickname||'好友')+' 成为好友 · 双方列表都会显示');
    }else toast(r2.msg);
  };
  $('paFind').addEventListener('keydown',e=>{ if(e.key==='Enter') $('paFindBtn').click(); });
  $('paShareBtn').onclick=async()=>{
    if(!Cloud.user||!Cloud.profile){ toast('请先登录后再生成邀请链接'); openAuth('login'); return; }
    const btn=$('paShareBtn'), old=btn.textContent;
    btn.disabled=true; btn.textContent='正在生成邀请链接…';
    try{
      const code=await encodeFriendInvite(Cloud.profile,state);
      const online=/^https?:$/.test(location.protocol);
      const shareValue=online
        ? location.origin+location.pathname+location.search+'#friend='+code
        : code;
      const copied=await copyText(shareValue);
      if(copied){
        toast(online?'邀请链接已复制，发给好友即可添加':'邀请码已复制，请发送给好友');
      }else{
        $('paFind').value=shareValue;
        $('paFind').focus(); $('paFind').select();
        toast('自动复制失败，邀请内容已放入输入框，请手动复制');
      }
    }catch(e){
      toast('生成邀请链接失败，请重试');
    }finally{
      btn.disabled=false; btn.textContent=old;
    }
  };
  // 委托处理好友操作
  $('paFriends').addEventListener('click',async e=>{
    const b=e.target.closest('button'); if(!b) return;
    if(b.dataset.enter){ closePersona(); await enterFriendWorld(b.dataset.enter); }
    else if(b.dataset.del){ await Cloud.removeFriend(b.dataset.del); renderPersona(); toast('已删除好友'); }
  });
  $('paRequests').addEventListener('click',async e=>{
    const b=e.target.closest('button'); if(!b) return;
    if(b.dataset.acc){ await Cloud.respondRequest(b.dataset.acc,true); renderPersona(); toast('已接受，TA 现在能看你的世界了'); }
    else if(b.dataset.rej){ await Cloud.respondRequest(b.dataset.rej,false); renderPersona(); }
  });
  $('guestBack').onclick=exitFriendWorld;
  const guestRefresh=$('guestRefresh');
  if(guestRefresh) guestRefresh.onclick=()=>refreshFriendWorld({silent:false});
  // 关闭 persona 的全局点击
  document.addEventListener('click',e=>{
    const p=$('persona');
    if(p.classList.contains('open')&&!p.contains(e.target)&&e.target!==$('btnAccount')){ p.classList.remove('open'); stopFriendListAutoRefresh(); }
  });
  setAuthMode('register');
}
function togglePersona(){ const p=$('persona'); p.classList.toggle('open'); if(p.classList.contains('open')){ renderPersona(); startFriendListAutoRefresh(); } else stopFriendListAutoRefresh(); }
function closePersona(){ $('persona').classList.remove('open'); stopFriendListAutoRefresh(); }

/* ---------------- 12. 启动 ---------------- */

/* ---------------- 12. 启动 ---------------- */
function boot(){
  buildSprites();
  buildOcean();                   // 世界大小无关，只建一次
  captureFriendInviteFromUrl();   // 先接住好友邀请，登录后再自动导入
  const had=loadState();          // 先读存档，才知道用户自己加过哪些岛
  if(!had){ seedData(); }
  if(!state.islands) state.islands=[];
  applyCustomIslands();
  ISLANDS.forEach(i=>ensureRegion(i.id));
  rebuildWorld();                 // 地形 / 桥梁 / 氛围 / 装饰（含每座岛的成长痕迹）
  buildChips();
  refreshHeader();
  resize();
  window.addEventListener('resize',scheduleResize);
  window.addEventListener('orientationchange',()=>setTimeout(scheduleResize,240));
  // 切回前台时重置计时基准，避免一次巨大的 dt 造成跳帧
  document.addEventListener('visibilitychange',()=>{ drawCore._t=0; draw._t=0; });
  // 账号：恢复本地登录（有账号则载入账号自己的世界）
  Cloud.init();
  bindAccountUI();
  updateAccountUI();
  if(Cloud.user){
    syncFromCloud({silent:true})
      .then(()=>processPendingFriendInvite())
      .catch(()=>{});
  }
  // 开场：拉远 → 推进港湾
  const wc=worldCenter();
  cam.zoom=fitZoom*1.02; cam.x=wc[0]; cam.y=wc[1];
  cam.tz=1; cam.tx=ISL.harbor.x; cam.ty=ISL.harbor.y;
  requestAnimationFrame(draw);
}
$('btnStart').onclick=()=>{
  $('welcome').classList.add('hide');
  setTimeout(()=>{ $('welcome').style.display='none'; },760);
  Snd.start(); $('btnSound').textContent='🔊';
  toast('拖动看看这个世界 · 点击岛屿进入');
};
// ?skip=1 直接进入世界（方便截图 / 演示），可加 &fit=1 / &zoom=2 / &sheet=harbor / &notrans=1
if(/[?&]notrans=1/.test(location.search)){
  const st=document.createElement('style');
  st.textContent='*{transition:none!important;animation:none!important}';
  document.head.appendChild(st);
}
if(/[?&]skip=1/.test(location.search)){
  setTimeout(()=>{
    document.getElementById('welcome').style.display='none';
    const zm=/[?&]zoom=([\d.]+)/.exec(location.search);
    if(zm){ const z=parseFloat(zm[1]);
      cam.zoom=cam.tz=clamp(z,minZoom,maxZoom);
      cam.x=ISL.harbor.x; cam.y=ISL.harbor.y; cam.tx=cam.x; cam.ty=cam.y; clampCam(); }
    const am=/[?&]at=(\w+)/.exec(location.search);
    if(am&&ISL[am[1]]){ const t=ISL[am[1]]; cam.x=cam.tx=t.x; cam.y=cam.ty=t.y; clampCam(); }
    if(/[?&]fit=1/.test(location.search)){ wantFit=true; resize(); }
    const sm=/[?&]sheet=(\w+)/.exec(location.search);
    if(sm){ openRegion(sm[1]); }
    if(/[?&]edit=1/.test(location.search)){
      openEditor('knowledge');

    }
    if(/[?&]addisland=1/.test(location.search)){ openAddSheet(); }
    if(/[?&]demo=island/.test(location.search)){
      addIsland('深夜食堂','🍵','market','凌晨两点还亮着的地方');
      addIsland('骑行日志','🪁','valley','两个轮子走过的路');
      wantFit=true; resize();
    }
    if(/[?&]adventure=1/.test(location.search)){
      const keys=Object.keys(ISL); if(keys.length){ const id=/[?&]island=(\w+)/.exec(location.search); startAdventure(id&&id[1]||keys[0]); }
    }
    const mny=/[?&]many=(\d+)/.exec(location.search);
    if(mny){
      const keys=Object.keys(ISLAND_THEMES), em=['🍵','🪁','🐈','🌊','🎧','🕯','🧵','🍃','🔭','🫧','🎐','🪴'];
      const n=Math.min(60,parseInt(mny[1],10)||0);
      batchAdd=true;
      for(let k=0;k<n;k++) addIsland('自建岛 '+(k+1), em[k%em.length], keys[k%keys.length], '扩展世界');
      batchAdd=false;
      rebuildWorld(); buildChips(); refreshHeader();
      wantFit=true; resize();
    }
    if(/[?&]detail=1/.test(location.search)){
      openRegion('memory');
      setTimeout(()=>openDetail('memory',(state.regions.memory.entries[0]||{}).id),400);
    }
    if(/[?&]autosave=1/.test(location.search)){
      setTimeout(()=>{
        openEditor('knowledge');
        $('edTitle').value='自动测试记录';
        $('edText').value='用于验证保存后的全屏演出。';
        $('edSave').click();
      },300);
    }
  },60);
}
// ?diag=1 诊断；?diag=bench 附带一次世界重建耗时
if(/[?&]diag=1/.test(location.search)){
  setTimeout(()=>{
    let extra='';
    if(/[?&]bench=1/.test(location.search)){
      const t0=performance.now(); rebuildWorld(); const t1=performance.now();
      extra=' rebuild='+(t1-t0).toFixed(0)+'ms islands='+ISLANDS.length+' px='+(WW*WH);
    }
    document.title='WB '+WOX+','+WOY+','+WW+','+WH+' S='+S().toFixed(3)+' fit='+fitZoom.toFixed(3)+' VW='+VW+' VH='+VH+' cam='+cam.x.toFixed(1)+','+cam.y.toFixed(1)+extra;
  },900);
}
// ?atlas=1 精灵图集调试
let atlasCv=null;
if(/[?&]atlas=1/.test(location.search)){
  setTimeout(()=>{
    document.getElementById('welcome').style.display='none';
    const names=Object.keys(SPR), cols=8, cell=64, rows=Math.ceil(names.length/cols);
    const c=C(cols*cell,rows*cell), g=GC(c);
    g.fillStyle='#37543f';g.fillRect(0,0,c.width,c.height);
    names.forEach((n,idx)=>{
      const sx=(idx%cols)*cell, sy=((idx/cols)|0)*cell, sp=SPR[n];
      const k=Math.max(0.5,Math.min((cell-8)/sp.cv.width,(cell-20)/sp.cv.height,3));
      g.drawImage(sp.cv, sx+cell/2-sp.cv.width*k/2, sy+cell-16-sp.cv.height*k, sp.cv.width*k, sp.cv.height*k);
      g.fillStyle='#fff';g.font='9px sans-serif';g.textAlign='center';
      g.fillText(n, sx+cell/2, sy+cell-4);
    });
    atlasCv=c; pauseRender=false;
  },80);
}
// ?perf=1 实时性能读数（写入标题，便于自动化验证）
if(/[?&]perf=1/.test(location.search)){
  let last=performance.now(), lastF=0, fps=0;
  window.__perf=()=>({fps, dpr:+DPR.toFixed(2), level:Q.level, skip:frameSkip,
    paint:+paintEMA.toFixed(1), vw:VW, vh:VH, frames:paintFrames});
  setInterval(()=>{
    const t=performance.now();
    fps=(paintFrames-lastF)/((t-last)/1000); lastF=paintFrames; last=t;
    const p=window.__perf();
    document.title='PERF fps='+fps.toFixed(0)+' dpr='+p.dpr+' lv='+p.level+' skip='+p.skip+
      ' paint='+p.paint+'ms vw='+p.vw+'x'+p.vh;
  },700);
}
/* ---------------- 12. 世界档案：只读重排现有记忆，不修改原数据结构 ---------------- */
var archiveState={tab:"overview",search:"",islandId:"all",echoIslandId:"memory"};
var archiveMapView={scale:1,tx:0,ty:0};
function archiveDate(entry){
  var value=entry&&(entry.date||entry.bornAt)||0;
  var d=new Date(value);
  if(isNaN(d.getTime())) d=new Date(0);
  return d;
}
function archiveAllEntries(){
  var rows=[];
  ISLANDS.forEach(function(island){
    var region=state.regions&&state.regions[island.id];
    var entries=region&&region.entries||[];
    entries.forEach(function(entry){
      rows.push({island:island,entry:entry,ts:archiveDate(entry).getTime()});
    });
  });
  rows.sort(function(a,b){return b.ts-a.ts||String(a.entry&&a.entry.id||"").localeCompare(String(b.entry&&b.entry.id||""));});
  return rows;
}
function archiveKind(entry){return KIND_META[entry&&entry.kind||"memory"]||KIND_META.memory;}
function archiveText(entry){
  return String(entry&&entry.text||"").replace(/\s+/g," ").trim();
}
function archiveTitle(entry){return String(entry&&entry.title||"(未命名)");}
function archiveDayKey(entry){
  var d=archiveDate(entry);
  return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
}
function archiveMonthKey(entry){
  var d=archiveDate(entry);
  return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0");
}
function archiveHash(value){
  var h=2166136261,str=String(value||"");
  for(var i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619);}
  return h>>>0;
}
function archiveFilteredRows(rows){
  var term=String(archiveState.search||"").trim().toLowerCase();
  return rows.filter(function(row){
    if(archiveState.islandId!=="all"&&row.island.id!==archiveState.islandId) return false;
    if(!term) return true;
    return (archiveTitle(row.entry)+" "+archiveText(row.entry)+" "+regionName(row.island)).toLowerCase().indexOf(term)>=0;
  });
}
function archiveOpenEntry(islandId,entryId){
  if(!islandId||!entryId) return;
  closeArchive();
  setTimeout(function(){openDetail(islandId,entryId);},90);
}
function archiveStat(value,label,color){
  return "<div class=\"archiveStat\" style=\"--ac:"+esc(color||"#8f7cff")+"\"><b>"+esc(value)+"</b><span>"+esc(label)+"</span></div>";
}
function archiveOverview(rows){
  var photoCount=0,musicCount=0,active={};
  rows.forEach(function(row){
    if(Array.isArray(row.entry.images)) photoCount+=row.entry.images.length;
    if((row.entry.kind||"memory")==="music") musicCount++;
    active[archiveDayKey(row.entry)]=1;
  });
  var activeDays=Object.keys(active).length;
  var filled=ISLANDS.filter(function(i){return state.regions[i.id]&&state.regions[i.id].entries&&state.regions[i.id].entries.length;}).length;
  var parts=[];
  parts.push("<div class=\"archiveSection\"><div class=\"archiveSectionTitle\"><h3>你的世界，正在长成什么样</h3><span>当前本地与世界同步数据</span></div><div class=\"archiveStatGrid\">");
  parts.push(archiveStat(rows.length,"条记忆","#8f7cff"));
  parts.push(archiveStat(filled,"座岛屿有记忆","#6fdcae"));
  parts.push(archiveStat(photoCount,"张照片","#6fb4ff"));
  parts.push(archiveStat(musicCount,"首音乐","#ffd166"));
  parts.push(archiveStat(activeDays,"个活跃日期","#ff9ad5"));
  parts.push("</div></div>");
  var max=Math.max(1,rows.length);
  parts.push("<div class=\"archiveSection\"><div class=\"archiveSectionTitle\"><h3>记忆分布</h3><span>点击岛屿查看它的长河</span></div><div class=\"archiveDistribution\">");
  ISLANDS.forEach(function(island){
    var n=(state.regions[island.id]&&state.regions[island.id].entries||[]).length;
    var width=Math.max(n?5:0,Math.round(n/max*100));
    parts.push("<div class=\"archiveDistRow\" data-archive-island=\""+esc(island.id)+"\" style=\"--ac:"+esc(island.color||"#8f7cff")+"\">"
      +"<div class=\"archiveDistLabel\">"+esc(island.emoji||"")+" "+esc(regionName(island))+"</div>"
      +"<div class=\"archiveDistTrack\"><div class=\"archiveDistFill\" style=\"width:"+width+"%\"></div></div>"
      +"<div class=\"archiveDistNum\">"+n+"</div></div>");
  });
  parts.push("</div></div>");
  var months=[],now=new Date();
  for(var m=11;m>=0;m--){
    var d=new Date(now.getFullYear(),now.getMonth()-m,1),key=d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0");
    months.push({key:key,label:(d.getMonth()+1)+"月",n:rows.filter(function(r){return archiveMonthKey(r.entry)===key;}).length});
  }
  var mmax=Math.max.apply(null,[1].concat(months.map(function(x){return x.n;})));
  parts.push("<div class=\"archiveSection\"><div class=\"archiveSectionTitle\"><h3>最近的月相</h3><span>每一根柱子，都是一段被留住的时光</span></div><div class=\"archiveMonthBars\">");
  months.forEach(function(x){
    var h=Math.round(6+(x.n/mmax)*88);
    parts.push("<div class=\"archiveMonthBar\" title=\""+esc(x.key)+" · "+x.n+" 条\"><em>"+x.n+"</em><i style=\"height:"+h+"px\"></i><span>"+esc(x.label)+"</span></div>");
  });
  parts.push("</div></div>");
  if(rows.length){
    var newest=rows[0],oldest=rows[rows.length-1];
    var recent=function(row,label){
      return "<div class=\"archiveRecent\" data-open-entry=\""+esc(row.entry.id)+"\" data-entry-island=\""+esc(row.island.id)+"\" style=\"--ac:"+esc(row.island.color||"#8f7cff")+"\"><div class=\"ar-kicker\">"+esc(label)+"</div><h4>"+esc(archiveTitle(row.entry))+"</h4><p>"+esc(archiveText(row.entry).slice(0,105)||"这一段没有文字，只有留下的痕迹。")+"</p><time>"+esc(fmtDate(row.entry.date))+" · "+esc(regionName(row.island))+"</time></div>";
    };
    parts.push("<div class=\"archiveSection\"><div class=\"archiveSectionTitle\"><h3>两端的坐标</h3><span>最近与最早</span></div><div class=\"archiveRecentGrid\">"+recent(newest,"最先被看见")+recent(oldest,"最早留下的")+"</div></div>");
  }
  return parts.join("");
}
function archiveTimeline(rows){
  var list=archiveFilteredRows(rows),parts=[];
  parts.push("<div class=\"archiveToolbar\"><input class=\"archiveSearch\" id=\"archiveSearch\" type=\"search\" placeholder=\"搜索标题、正文或岛屿\" value=\""+esc(archiveState.search)+"\" autocomplete=\"off\"><select class=\"archiveSelect\" id=\"archiveIslandFilter\"><option value=\"all\">全部岛屿 · "+rows.length+" 条</option>");
  ISLANDS.forEach(function(island){
    var n=(state.regions[island.id]&&state.regions[island.id].entries||[]).length;
    parts.push("<option value=\""+esc(island.id)+"\" "+(archiveState.islandId===island.id?"selected":"")+">"+esc(island.emoji||"")+" "+esc(regionName(island))+" · "+n+"</option>");
  });
  parts.push("</select></div>");
  if(!list.length){parts.push("<div class=\"archiveBlank\">还没有找到匹配的记忆。<br>换个关键词，或者回到总览看看分布。</div>");return parts.join("");}
  var groups=[],current=null;
  list.forEach(function(row){
    var key=archiveMonthKey(row.entry);
    if(!current||current.key!==key){current={key:key,label:archiveDate(row.entry).getFullYear()+"年"+(archiveDate(row.entry).getMonth()+1)+"月",rows:[]};groups.push(current);}
    current.rows.push(row);
  });
  parts.push("<div class=\"archiveTimeline\">");
  groups.forEach(function(group){
    parts.push("<div class=\"archiveMonthGroup\"><div class=\"archiveMonthLabel\">"+esc(group.label)+" · "+group.rows.length+" 条</div>");
    group.rows.forEach(function(row){
      var kd=archiveKind(row.entry),text=archiveText(row.entry);
      parts.push("<div class=\"archiveTimelineItem\" data-open-entry=\""+esc(row.entry.id)+"\" data-entry-island=\""+esc(row.island.id)+"\" style=\"--ac:"+esc(row.island.color||"#8f7cff")+"\">"
        +"<div class=\"archiveTimelineIcon\">"+esc(kd.icon)+"</div><div class=\"archiveTimelineMain\"><h4>"+esc(archiveTitle(row.entry))+"</h4><p>"+esc(text||"图片或旋律留下的记忆。")+"</p></div>"
        +"<div class=\"archiveTimelineMeta\">"+esc(String(archiveDate(row.entry).getDate()).padStart(2,"0"))+"日<br>"+esc(regionName(row.island))+"</div></div>");
    });
    parts.push("</div>");
  });
  parts.push("</div>");
  return parts.join("");
}
function archiveMapLines(nodes){
  var lines=[];
  ISLANDS.forEach(function(island){
    var list=nodes.filter(function(n){return n.islandId===island.id;});
    for(var i=1;i<list.length;i++){
      lines.push("<line x1=\""+list[i-1].x.toFixed(1)+"\" y1=\""+list[i-1].y.toFixed(1)+"\" x2=\""+list[i].x.toFixed(1)+"\" y2=\""+list[i].y.toFixed(1)+"\" stroke=\""+esc(island.color||"#8f7cff")+"\" stroke-opacity=\".18\" stroke-width=\"1\"></line>");
    }
  });
  return lines.join("");
}
function archiveMap(rows){
  var list=archiveFilteredRows(rows);
  if(!list.length) return "<div class=\"archiveBlank\">还没有可以点亮的记忆星。</div>";
  var W=920,H=560,cx=460,cy=276,groups=[],nodes=[];
  ISLANDS.forEach(function(island){
    var entries=list.filter(function(row){return row.island.id===island.id;});
    if(entries.length) groups.push({island:island,rows:entries});
  });
  var centers={};
  groups.forEach(function(group,index){
    var angle=-Math.PI/2+index*Math.PI*2/Math.max(1,groups.length);
    var radius=groups.length===1?0:178;
    centers[group.island.id]={x:cx+Math.cos(angle)*radius,y:cy+Math.sin(angle)*radius*.82};
  });
  groups.forEach(function(group,gi){
    var center=centers[group.island.id];
    group.rows.slice().sort(function(a,b){return a.ts-b.ts;}).forEach(function(row,index){
      var radius=12+Math.floor(index/8)*20;
      var angle=index*2.39996323+gi*1.17+((archiveHash(row.entry.id)%100)/100)*.5;
      nodes.push({islandId:group.island.id,x:center.x+Math.cos(angle)*radius,y:center.y+Math.sin(angle)*radius*.82,row:row,index:index});
    });
  });
  var parts=[];
  parts.push("<div class=\"archiveSectionTitle\"><h3>记忆星图</h3><span>拖动浏览 · 点击星星打开记忆</span></div>");
  parts.push("<div class=\"archiveMapWrap\">");
  parts.push("<div class=\"archiveMapControls\"><button type=\"button\" data-map-control=\"in\" title=\"放大\">＋</button><button type=\"button\" data-map-control=\"out\" title=\"缩小\">－</button><button type=\"button\" data-map-control=\"reset\" title=\"回到中心\">⊙</button></div>");
  parts.push("<svg class=\"archiveMapSvg\" id=\"archiveMapSvg\" viewBox=\"0 0 920 560\" aria-label=\"记忆星图\"><g id=\"archiveStarLayer\">");
  parts.push(archiveMapLines(nodes));
  nodes.forEach(function(node){
    var size=node.index%5===0?6.5:4.7,title=archiveTitle(node.row.entry),date=fmtDate(node.row.entry.date);
    parts.push("<g class=\"archiveMapNode\" data-open-entry=\""+esc(node.row.entry.id)+"\" data-entry-island=\""+esc(node.islandId)+"\" style=\"cursor:pointer\"><circle cx=\""+node.x.toFixed(1)+"\" cy=\""+node.y.toFixed(1)+"\" r=\""+size+"\" fill=\""+esc(node.row.island.color||"#8f7cff")+"\" fill-opacity=\".92\"><title>"+esc(title)+" · "+esc(date)+"</title></circle><circle cx=\""+node.x.toFixed(1)+"\" cy=\""+node.y.toFixed(1)+"\" r=\""+(size+3.5)+"\" fill=\"none\" stroke=\""+esc(node.row.island.color||"#8f7cff")+"\" stroke-opacity=\".2\"></circle></g>");
  });
  groups.forEach(function(group){
    var c=centers[group.island.id];
    parts.push("<text x=\""+c.x.toFixed(1)+"\" y=\""+(c.y-92).toFixed(1)+"\" text-anchor=\"middle\" fill=\"#e7e5f5\" font-size=\"12\" font-weight=\"700\" style=\"pointer-events:none\">"+esc(group.island.emoji||"")+" "+esc(regionName(group.island))+"</text><text x=\""+c.x.toFixed(1)+"\" y=\""+(c.y-77).toFixed(1)+"\" text-anchor=\"middle\" fill=\"#8d91ad\" font-size=\"9\" style=\"pointer-events:none\">"+group.rows.length+" 条记忆</text>");
  });
  parts.push("</g></svg><div class=\"archiveMapHint\">拖动移动 · 滚轮 / 双指缩放 · 点击星星查看原记忆</div></div>");
  return parts.join("");
}
function applyArchiveMapTransform(){
  var layer=$('archiveStarLayer');
  if(!layer) return;
  var v=archiveMapView;
  layer.setAttribute("transform","translate("+v.tx.toFixed(1)+" "+v.ty.toFixed(1)+") scale("+v.scale.toFixed(3)+")");
}
function wireArchiveMap(){
  var svg=$('archiveMapSvg');
  if(!svg) return;
  applyArchiveMapTransform();
  var drag=null;
  svg.addEventListener("pointerdown",function(e){
    if(e.target.closest("[data-open-entry]")) return;
    drag={x:e.clientX,y:e.clientY,tx:archiveMapView.tx,ty:archiveMapView.ty};
    svg.classList.add("dragging");
    try{svg.setPointerCapture(e.pointerId);}catch(err){}
  });
  svg.addEventListener("pointermove",function(e){
    if(!drag) return;
    archiveMapView.tx=drag.tx+(e.clientX-drag.x);
    archiveMapView.ty=drag.ty+(e.clientY-drag.y);
    applyArchiveMapTransform();
  });
  var stop=function(){drag=null;svg.classList.remove("dragging");};
  svg.addEventListener("pointerup",stop);svg.addEventListener("pointercancel",stop);
  svg.addEventListener("wheel",function(e){
    e.preventDefault();
    archiveMapView.scale=clamp(archiveMapView.scale*(e.deltaY<0?1.15:1/1.15),.55,2.5);
    applyArchiveMapTransform();
  },{passive:false});
  svg.addEventListener("dblclick",function(){archiveMapView.scale=1;archiveMapView.tx=0;archiveMapView.ty=0;applyArchiveMapTransform();});
}
function archiveEcho(rows){
  var now=new Date(),month=now.getMonth()+1,day=now.getDate(),exact=[],fallback=[];
  rows.forEach(function(row){
    var d=archiveDate(row.entry);
    if(d.getMonth()+1===month&&d.getDate()===day&&d.getFullYear()!==now.getFullYear()) exact.push(row);
    if(row.ts<now.getTime()-30*24*60*60*1000) fallback.push(row);
  });
  var use=exact.length?exact:fallback.slice(0,3);
  var parts=[];
  parts.push("<div class=\"archiveEchoHero\"><div class=\"ae-kicker\">"+(exact.length?"ON THIS DAY":"OLD ECHO")+"</div><h3>"+(exact.length?"那年今日，你写下过这些":"从旧时光里，捞起一段回声")+"</h3><p>"+(exact.length?("今天在 "+exact.length+" 条旧记忆里重逢。它们来自不同的年份，却落在了同一个日期。"):"今天还没有同月同日的记忆。先从旧记录里挑一段，看看它会不会带你回到某个瞬间。")+"</p><div class=\"archiveEchoActions\">"+(readOnly?"":"<button type=\"button\" class=\"archiveEchoPrimary\" data-archive-action=\"write-today\">再次写下今天</button>")+"<button type=\"button\" class=\"archiveEchoGhost\" data-archive-action=\"timeline\">去时光长河看看</button></div></div>");
  if(!use.length){parts.push("<div class=\"archiveBlank\">世界还是空白。写下第一段记忆后，这里就会开始积累回声。</div>");return parts.join("");}
  parts.push("<div class=\"archiveSectionTitle\"><h3>"+(exact.length?"同月同日":"旧日回声")+"</h3><span>点击回到原记忆</span></div><div class=\"archiveEchoList\">");
  use.slice(0,6).forEach(function(row){
    var kd=archiveKind(row.entry),text=archiveText(row.entry);
    archiveState.echoIslandId=row.island.id;
    parts.push("<div class=\"archiveEchoItem\" data-open-entry=\""+esc(row.entry.id)+"\" data-entry-island=\""+esc(row.island.id)+"\" style=\"--ac:"+esc(row.island.color||"#8f7cff")+"\"><div class=\"aei-icon\">"+esc(kd.icon)+"</div><div class=\"aei-main\"><h4>"+esc(archiveTitle(row.entry))+"</h4><p>"+esc(text||"这一段没有文字，只有留下的痕迹。")+"</p><time>"+esc(fmtDate(row.entry.date))+" · "+esc(regionName(row.island))+"</time></div></div>");
  });
  parts.push("</div>");
  return parts.join("");
}
function renderArchive(){
  var screen=$('archive');if(!screen) return;
  var rows=archiveAllEntries(),tab=archiveState.tab||"overview";
  $('archiveSub').textContent=readOnly?("正在看好友的公开档案 · "+rows.length+" 条记忆"):("你的世界档案 · "+rows.length+" 条记忆，慢慢看，慢慢想起");
  document.querySelectorAll("[data-archive-tab]").forEach(function(b){var on=b.dataset.archiveTab===tab;b.classList.toggle("on",on);b.setAttribute("aria-selected",on?"true":"false");});
  if(tab==="timeline") $('archiveBody').innerHTML=archiveTimeline(rows);
  else if(tab==="map") $('archiveBody').innerHTML=archiveMap(rows);
  else if(tab==="echo") $('archiveBody').innerHTML=archiveEcho(rows);
  else if(tab==="chronicle") $('archiveBody').innerHTML=archiveChronicle(rows);
  else $('archiveBody').innerHTML=archiveOverview(rows);
  if(tab==="map") wireArchiveMap();
}
function openArchive(tab){
  if(tab) archiveState.tab=tab;
  var screen=$('archive');if(!screen)return;
  screen.classList.add("open");screen.setAttribute("aria-hidden","false");
  $('archiveBody').scrollTop=0;
  renderArchive();
}
function closeArchive(){
  var screen=$('archive');if(!screen)return;
  screen.classList.remove("open");screen.setAttribute("aria-hidden","true");
}
(function bindArchiveUI(){
  var tabs=$('archiveTabs'),body=$('archiveBody'),close=$('archiveClose');
  if(close) close.onclick=closeArchive;
  if(tabs) tabs.addEventListener("click",function(e){
    var b=e.target.closest("[data-archive-tab]");if(!b)return;
    archiveState.tab=b.dataset.archiveTab||"overview";
    if(archiveState.tab==="map"){archiveMapView.scale=1;archiveMapView.tx=0;archiveMapView.ty=0;}
    renderArchive();
  });
  if(body) body.addEventListener("click",function(e){
    var open=e.target.closest("[data-open-entry]");
    if(open){archiveOpenEntry(open.dataset.entryIsland,open.dataset.openEntry);return;}
    var island=e.target.closest("[data-archive-island]");
    if(island){archiveState.tab="timeline";archiveState.islandId=island.dataset.archiveIsland||"all";archiveState.search="";renderArchive();return;}
    var map=e.target.closest("[data-map-control]");
    if(map){var action=map.dataset.mapControl;if(action==="in")archiveMapView.scale=clamp(archiveMapView.scale*1.18,.55,2.5);else if(action==="out")archiveMapView.scale=clamp(archiveMapView.scale/1.18,.55,2.5);else{archiveMapView.scale=1;archiveMapView.tx=0;archiveMapView.ty=0;}applyArchiveMapTransform();return;}
    var cmode=e.target.closest("[data-chronicle-mode]");
    if(cmode){chronicleState.mode=cmode.dataset.chronicleMode==="island"?"island":"year";renderArchive();return;}
    var cexp=e.target.closest("[data-chronicle-export]");
    if(cexp){chronicleExport(cexp.dataset.chronicleExport);return;}
    var action=e.target.closest("[data-archive-action]");
    if(action){if(action.dataset.archiveAction==="timeline"){archiveState.tab="timeline";renderArchive();return;}if(action.dataset.archiveAction==="write-today"&&!readOnly){var islandId=archiveState.echoIslandId||"memory";closeArchive();setTimeout(function(){openEditor(islandId);if($('edTitle')&&!$('edTitle').value)$('edTitle').value="今天的回声";},120);}}
  });
  if(body) body.addEventListener("input",function(e){
    if(e.target.id!=="archiveSearch")return;
    var pos=e.target.selectionStart||e.target.value.length;
    archiveState.search=e.target.value;
    renderArchive();
    var next=$('archiveSearch');if(next){next.focus();try{next.setSelectionRange(pos,pos);}catch(err){}}
  });
  if(body) body.addEventListener("change",function(e){
    if(e.target.id!=="archiveIslandFilter")return;
    archiveState.islandId=e.target.value||"all";renderArchive();
  });
})();

// 保存粒子与世界特效统一由渲染循环绘制
/* ---------------- 12e. 岛屿生态 / 与你有关 / 世界编年史 ---------------- */

/* ============================================================
   12b. 岛屿生态：居民随记忆一起生长
   全部生物与设定均为原创：页栖灯虫 / 音潮鲸 / 和声跃豚 /
   苔背铃兽 / 墨羽织匠 / 星砂引路兽 / 港灯小蟹 / 微光浮灵
   ============================================================ */
const ECOLOGY_SPECIES={
  knowledge:{name:'页栖灯虫',icon:'🐛',color:'#9fd3ff',note:'书页翻得越多，纸缝里越容易亮起一小盏光'},
  music:{name:'音潮鲸',icon:'🐋',color:'#ffd166',note:'旋律沉进海湾，海面上会浮起一枚星形的呼吸'},
  musicAlt:{name:'和声跃豚',icon:'🐬',color:'#8ef0d0',note:'节奏轻快的时候，会有小豚从浪里跃出来'},
  memory:{name:'苔背铃兽',icon:'✦',color:'#6fdcae',note:'它把旧时光背在背上，走得很慢，铃铛很轻'},
  creation:{name:'墨羽织匠',icon:'🪶',color:'#ff9ad5',note:'把写完的句子一根一根织成羽毛'},
  future:{name:'星砂引路兽',icon:'✨',color:'#b79cff',note:'踏过的地方会留下会发光的星砂'},
  harbor:{name:'港灯小蟹',icon:'🦀',color:'#ffb26b',note:'天亮以前，它替你守着港湾的灯'},
  garden:{name:'微光浮灵',icon:'🫧',color:'#8fd7ff',note:'新岛上的第一户小居民，靠微光生活'}
};
function ecologyScale(n){ return n<=0?0 : n<3?1 : n<6?2 : n<10?4 : n<16?7 : 10; }
function ecologyLineup(id,species,count){
  const out=[];
  for(let k=0;k<count;k++){
    if(id==='music'){
      const dolphin=(k%3===2);
      const sp=dolphin?ECOLOGY_SPECIES.musicAlt:ECOLOGY_SPECIES.music;
      out.push({key:dolphin?'musicAlt':'music',name:sp.name,icon:sp.icon,color:sp.color,index:k});
    }else{
      out.push({key:id,index:k,name:species.name,icon:species.icon,color:species.color});
    }
  }
  return out;
}
function refreshEcology(){
  for(const i of ISLANDS){
    const r=state.regions&&state.regions[i.id];
    const ents=(r&&Array.isArray(r.entries))?r.entries:[];
    let species=i.custom?ECOLOGY_SPECIES.garden:(ECOLOGY_SPECIES[i.id]||ECOLOGY_SPECIES.garden);
    let source=ents.length;
    if(i.id==='knowledge'){
      source=ents.filter(e=>{const k=e.kind||'memory';return k==='memory'||k==='goal';}).length;
      species=ECOLOGY_SPECIES.knowledge;
    }else if(i.id==='music'){
      source=ents.filter(e=>(e.kind||'memory')==='music').length;
      species=source%3===2?ECOLOGY_SPECIES.musicAlt:ECOLOGY_SPECIES.music;
    }
    const count=ecologyScale(source);
    const lineup=ecologyLineup(i.id,species,count);
    const kinds=lineup.reduce((m,sp)=>{m[sp.name]=(m[sp.name]||0)+1;return m;},{});
    const names=Object.keys(kinds).map(n=>n+'×'+kinds[n]);
    i.ecology={count:count,key:i.id,name:species.name,icon:species.icon,color:species.color,
      note:species.note,source:source,lineup:lineup,
      summary:count?(names.join(' · ')):'还没有居民'};
  }
}
function ecologySpot(i,k,eco){
  if(i.id==='music'){
    const bay=i.seed*3.7+1.5;
    const span=1.7;
    const ang=bay+(eco.count<=1?0:((k/(eco.count-1))-0.5)*span);
    const rad=radiusAt(i,((ang*57.29578)%360+360)%360)*(1.08+0.26*((k%3)/3));
    return {x:i.x+Math.cos(ang)*rad,y:i.y+Math.sin(ang)*rad*0.94+Math.sin(T*0.9+k*2.1)*1.7,ang:ang,bay:true};
  }
  const ang=i.seed*1.3+k*2.1+Math.sin(T*0.22+k)*0.07;
  const rad=radiusAt(i,((ang*57.29578)%360+360)%360)*0.84;
  return {x:i.x+Math.cos(ang)*rad,y:i.y+Math.sin(ang)*rad*0.94,ang:ang,bay:false};
}
function ecoStar(g,cx,cy,outer,inner,points){
  g.beginPath();
  for(let s=0;s<points*2;s++){
    const r=(s%2)?inner:outer, a=-Math.PI/2+s*Math.PI/points;
    const px=cx+Math.cos(a)*r, py=cy+Math.sin(a)*r;
    if(s===0) g.moveTo(px,py); else g.lineTo(px,py);
  }
  g.closePath();
}
function drawPageLantern(x,y,sc,k,color){
  const t=T*1.5+k*1.7, bob=Math.sin(t)*1.4;
  ctx.save(); ctx.translate(x,y+bob); ctx.rotate(Math.sin(t*0.5)*0.12); ctx.scale(sc,sc);
  ctx.globalCompositeOperation='lighter';
  const g=ctx.createRadialGradient(0,0,0.5,0,0,13);
  g.addColorStop(0,hexA(color,0.40)); g.addColorStop(1,hexA(color,0));
  ctx.fillStyle=g; ctx.beginPath(); ctx.arc(0,0,13,0,6.2832); ctx.fill();
  ctx.globalCompositeOperation='source-over';
  ctx.fillStyle=hexA(color,0.85);
  ctx.beginPath(); ctx.moveTo(-1,-1.6); ctx.lineTo(-8,-6.4+Math.sin(t)*1.6); ctx.lineTo(-2,-4.4); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(1,-1.6); ctx.lineTo(8,-6.4-Math.sin(t)*1.6); ctx.lineTo(2,-4.4); ctx.closePath(); ctx.fill();
  for(let s=0;s<3;s++){
    ctx.fillStyle=s===1?'#f4f0ff':'#dff0ff';
    ctx.beginPath(); ctx.ellipse((s-1)*3.1,s*0.7,3.0-s*0.22,2.7,0.16*s,0,6.2832); ctx.fill();
  }
  ctx.strokeStyle=hexA(color,0.9); ctx.lineWidth=0.9;
  ctx.beginPath(); ctx.moveTo(-1,-2.2); ctx.quadraticCurveTo(-4,-7,-6.5,-6); ctx.moveTo(1,-2.2); ctx.quadraticCurveTo(4,-7,6.5,-6); ctx.stroke();
  ctx.restore();
}
function drawToneTide(x,y,sc,k,color,isDolphin){
  const t=T*0.9+k*1.3;
  const leap=isDolphin?(0.5+0.5*Math.sin(t*1.15)):0;
  ctx.save(); ctx.translate(x,y-leap*9+Math.sin(t*0.9)*1.6); ctx.scale(sc,sc);
  if(isDolphin) ctx.rotate(Math.sin(t*1.2)*0.4);
  ctx.globalCompositeOperation='lighter';
  const wg=ctx.createRadialGradient(0,4,1,0,4,18);
  wg.addColorStop(0,hexA(color,0.28)); wg.addColorStop(1,hexA(color,0));
  ctx.fillStyle=wg; ctx.beginPath(); ctx.arc(0,4,18,0,6.2832); ctx.fill();
  ctx.globalCompositeOperation='source-over';
  const body=ctx.createLinearGradient(-14,-6,14,6);
  body.addColorStop(0,hexA(color,0.96)); body.addColorStop(1,'rgba(255,255,255,0.92)');
  ctx.fillStyle=body;
  ctx.beginPath();
  ctx.moveTo(13,0);
  ctx.quadraticCurveTo(6,-7,-3,-6);
  ctx.quadraticCurveTo(-11,-5,-14,-1);
  ctx.quadraticCurveTo(-11,4,-3,5);
  ctx.quadraticCurveTo(6,6,13,0);
  ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(-12,-1); ctx.lineTo(-19,-7); ctx.lineTo(-16,0); ctx.lineTo(-19,7); ctx.closePath(); ctx.fill();
  ctx.fillStyle=hexA(color,0.82);
  ctx.beginPath(); ctx.moveTo(-1,-5); ctx.quadraticCurveTo(2,-13,7,-11); ctx.quadraticCurveTo(3,-7,3,-4); ctx.closePath(); ctx.fill();
  ctx.fillStyle='rgba(20,26,44,0.9)'; ctx.beginPath(); ctx.arc(8,-1.5,0.9,0,6.2832); ctx.fill();
  if(!isDolphin){
    ctx.globalCompositeOperation='lighter';
    ctx.fillStyle=hexA(color,0.5+0.25*Math.abs(Math.sin(t*2)));
    ecoStar(ctx,3,-13,4.4,1.8,5); ctx.fill();
    ctx.globalCompositeOperation='source-over';
  }
  ctx.restore();
}
function drawMossBell(x,y,sc,k,color){
  const t=T*0.9+k, bob=Math.abs(Math.sin(t))*1.6;
  ctx.save(); ctx.translate(x,y-bob); ctx.scale(sc,sc);
  ctx.fillStyle='rgba(6,8,20,0.26)'; ctx.beginPath(); ctx.ellipse(0,bob+1,8,2.4,0,0,6.2832); ctx.fill();
  const g=ctx.createLinearGradient(0,-9,0,4); g.addColorStop(0,'#d6efd2'); g.addColorStop(1,hexA(color,0.95));
  ctx.fillStyle=g; ctx.beginPath(); ctx.ellipse(0,-2,8,7,0,0,6.2832); ctx.fill();
  ctx.fillStyle=hexA(color,0.72); ctx.beginPath(); ctx.ellipse(-2,-6,5,2.6,-0.3,0,6.2832); ctx.fill();
  ctx.fillStyle='#ffe9a8'; ctx.beginPath(); ctx.moveTo(3,-6); ctx.quadraticCurveTo(7,-9.4,9.4,-5); ctx.quadraticCurveTo(7,-2.6,3,-4); ctx.closePath(); ctx.fill();
  ctx.fillStyle='#8a6b2f'; ctx.fillRect(5.6,-3.4,1,2);
  ctx.fillStyle='rgba(24,30,48,0.9)'; ctx.beginPath(); ctx.arc(-3,-2,0.9,0,6.2832); ctx.arc(1.4,-2,0.9,0,6.2832); ctx.fill();
  ctx.fillStyle=hexA(color,0.9); ctx.fillRect(-5.4,3,3,2); ctx.fillRect(2.2,3,3,2);
  ctx.restore();
}
function drawInkWeaver(x,y,sc,k,color){
  const t=T*1.1+k*1.4;
  ctx.save(); ctx.translate(x,y+Math.sin(t)*2.2); ctx.scale(sc,sc);
  ctx.fillStyle='rgba(20,16,36,0.92)';
  ctx.beginPath(); ctx.ellipse(0,0,6.4,5.2,-0.2,0,6.2832); ctx.fill();
  ctx.fillStyle=hexA(color,0.9);
  ctx.save(); ctx.rotate(Math.sin(t*1.6)*0.5);
  ctx.beginPath(); ctx.moveTo(1,-2); ctx.quadraticCurveTo(9,-9,13,-2); ctx.quadraticCurveTo(8,0,1,0); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(-1,-2); ctx.quadraticCurveTo(-9,-9,-13,-2); ctx.quadraticCurveTo(-8,0,-1,0); ctx.closePath(); ctx.fill();
  ctx.restore();
  ctx.fillStyle='#ffe6f6'; ctx.beginPath(); ctx.arc(-1.6,-1,0.8,0,6.2832); ctx.arc(1.6,-1,0.8,0,6.2832); ctx.fill();
  ctx.strokeStyle=hexA(color,0.85); ctx.lineWidth=0.7;
  ctx.beginPath(); ctx.moveTo(-3,4); ctx.lineTo(-4.6,8); ctx.moveTo(3,4); ctx.lineTo(4.6,8); ctx.stroke();
  ctx.restore();
}
function drawStarPath(x,y,sc,k,color){
  const t=T*1.5+k;
  ctx.save(); ctx.translate(x,y+Math.sin(t*0.8)*1.5); ctx.scale(sc,sc);
  ctx.globalCompositeOperation='lighter';
  const g=ctx.createRadialGradient(0,0,1,0,0,16);
  g.addColorStop(0,hexA(color,0.34)); g.addColorStop(1,hexA(color,0));
  ctx.fillStyle=g; ctx.beginPath(); ctx.arc(0,0,16,0,6.2832); ctx.fill();
  ctx.globalCompositeOperation='source-over';
  ctx.fillStyle=hexA(color,0.9);
  ctx.beginPath(); ctx.moveTo(7,-6); ctx.quadraticCurveTo(2,-3,-5,-4); ctx.quadraticCurveTo(-9,-1,-6,2); ctx.quadraticCurveTo(-2,5,3,3); ctx.quadraticCurveTo(7,4,9,0); ctx.closePath(); ctx.fill();
  for(let s=0;s<4;s++){ ctx.fillRect(-6+s*4,3.4,2.4,2.4); }
  ctx.fillStyle='#fff8d8'; ecoStar(ctx,5,-3,2.6,1,4); ctx.fill();
  ctx.restore();
}
function drawHarborCrab(x,y,sc,k,color){
  const t=T*1.2+k;
  ctx.save(); ctx.translate(x,y+Math.sin(t)*0.8); ctx.scale(sc,sc);
  ctx.fillStyle=hexA(color,0.95);
  ctx.beginPath(); ctx.ellipse(0,0,7,5,0,0,6.2832); ctx.fill();
  ctx.strokeStyle=hexA(color,0.9); ctx.lineWidth=1.2;
  for(const sgn of [-1,1]){
    ctx.beginPath(); ctx.moveTo(sgn*5,-2); ctx.lineTo(sgn*10,-7+Math.sin(t*2)*1.4); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(sgn*5,1); ctx.lineTo(sgn*9,6); ctx.stroke();
  }
  ctx.fillStyle='rgba(30,22,18,0.9)'; ctx.beginPath(); ctx.arc(-2,-1,0.9,0,6.2832); ctx.arc(2,-1,0.9,0,6.2832); ctx.fill();
  ctx.globalCompositeOperation='lighter';
  ctx.fillStyle=hexA('#ffe9b0',0.5+0.3*Math.abs(Math.sin(t)));
  ecoStar(ctx,0,-8,3.4,1.4,5); ctx.fill();
  ctx.globalCompositeOperation='source-over';
  ctx.restore();
}
function drawGlimmerDrifter(x,y,sc,k,color){
  const t=T*1.2+k*1.6;
  ctx.save(); ctx.translate(x,y+Math.sin(t)*3.2); ctx.scale(sc,sc);
  ctx.globalCompositeOperation='lighter';
  const g=ctx.createRadialGradient(0,0,1,0,0,15);
  g.addColorStop(0,hexA(color,0.42)); g.addColorStop(1,hexA(color,0));
  ctx.fillStyle=g; ctx.beginPath(); ctx.arc(0,0,15,0,6.2832); ctx.fill();
  ctx.globalCompositeOperation='source-over';
  ctx.fillStyle=hexA(color,0.75);
  ctx.beginPath(); ctx.arc(0,0,5.4+Math.sin(t)*0.5,0,6.2832); ctx.fill();
  ctx.fillStyle='rgba(255,255,255,0.85)'; ctx.beginPath(); ctx.arc(-1.4,-1.2,2.1,0,6.2832); ctx.fill();
  ctx.fillStyle='rgba(28,34,58,0.85)'; ctx.beginPath(); ctx.arc(-2,0.4,0.7,0,6.2832); ctx.arc(2,0.4,0.7,0,6.2832); ctx.fill();
  ctx.strokeStyle=hexA(color,0.7); ctx.lineWidth=0.8;
  ctx.beginPath(); ctx.moveTo(4,3); ctx.quadraticCurveTo(10,7,12,3); ctx.stroke();
  ctx.restore();
}
function drawEcology(now,vx0,vx1,vy0,vy1){
  for(const i of ISLANDS){
    const eco=i.ecology; if(!eco||!eco.count) continue;
    if(i.x+i.r<vx0-140||i.x-i.r>vx1+140||i.y+i.r<vy0-140||i.y-i.r>vy1+140) continue;
    const sc=clamp(Math.max(0.72,Math.min(1.5,i.r/30)),0.6,1.6);
    for(const sp of eco.lineup){
      const p=ecologySpot(i,sp.index,eco);
      if(p.x<vx0-90||p.x>vx1+90||p.y<vy0-90||p.y>vy1+90) continue;
      if(i.id==='music') drawToneTide(p.x,p.y,sc,sp.index,sp.color,sp.key==='musicAlt');
      else if(i.id==='knowledge') drawPageLantern(p.x,p.y,sc,sp.index,sp.color);
      else if(i.id==='memory') drawMossBell(p.x,p.y,sc,sp.index,sp.color);
      else if(i.id==='creation') drawInkWeaver(p.x,p.y,sc,sp.index,sp.color);
      else if(i.id==='future') drawStarPath(p.x,p.y,sc,sp.index,sp.color);
      else if(i.id==='harbor') drawHarborCrab(p.x,p.y,sc,sp.index,sp.color);
      else drawGlimmerDrifter(p.x,p.y,sc,sp.index,sp.color);
    }
  }
}

/* ============================================================
   12c. 与你有关：新碎片自动寻找「来源完全不同」的旧碎片
   ============================================================ */
const RELATION_STOP={'一个':1,'我们':1,'他们':1,'这个':1,'那个':1,'自己':1,'什么':1,'因为':1,'所以':1,'已经':1,'还是':1,'就是':1,'可以':1,'没有':1,'一起':1,'今天':1,'明天':1,'昨天':1,'时候':1,'地方':1,'感觉':1,'真的':1,'然后':1,'the':1,'and':1,'for':1,'that':1,'this':1,'with':1};
const READ_HINT=/书|读|阅|诗集|小说|散文|文章|作者|章节|笔记|课程|学习|知识|图书馆|杂志|论文/;
const PLACE_RE=/[\u4e00-\u9fa5]{2,10}(路|街|巷|公园|广场|海边|海滩|湖|山|岛|城|馆|店|学校|校园|车站|机场|医院|桥|河|湾|港|村|镇|区|大道|胡同)/g;
function relationTokens(text){
  const s=String(text||'');
  const out={};
  (s.match(/《[^》]{1,24}》/g)||[]).forEach(function(q){
    const k=q.replace(/[《》]/g,'');
    if(k) out[k]=(out[k]||0)+4;
  });
  (s.toLowerCase().match(/[a-z0-9]{3,}/g)||[]).forEach(function(w){
    if(!RELATION_STOP[w]) out[w]=(out[w]||0)+1;
  });
  (s.match(/[\u4e00-\u9fa5]+/g)||[]).forEach(function(run){
    for(let i=0;i<run.length-1;i++){
      const g=run.slice(i,i+2);
      if(!RELATION_STOP[g]) out[g]=(out[g]||0)+1;
    }
  });
  return out;
}
function relationOverlap(a,b){
  let score=0; const shared=[];
  for(const k in a){
    if(!b[k]) continue;
    const w=Math.min(3,Math.min(a[k],b[k]));
    score+=w*(k.length>=3?1.5:1);
    shared.push(k);
  }
  shared.sort(function(x,y){return y.length-x.length||x.localeCompare(y);});
  return {score:score,shared:shared};
}
function relationPlaces(text){
  const m=String(text||'').match(PLACE_RE)||[];
  m.sort(function(a,b){return b.length-a.length;});
  return m.slice(0,4);
}
function relationSameMonthDay(a,b){
  return a.getMonth()===b.getMonth()&&a.getDate()===b.getDate();
}
function relationBookPair(a,b,days){
  const at=[a.title,a.text].join(' '), bt=[b.title,b.text].join(' ');
  const aq=at.match(/《[^》]{1,24}》/g)||[], bq=bt.match(/《[^》]{1,24}》/g)||[];
  for(const q of aq){ if(bt.indexOf(q)>=0&&days>=7) return '这里提到的 '+q+'，在另一段时间里真的留下了痕迹'; }
  for(const q of bq){ if(at.indexOf(q)>=0&&days>=7) return '隔着时间，你们提到了同一本 '+q; }
  if(READ_HINT.test(at)&&READ_HINT.test(bt)&&days>=30) return '都和读书、学习有关，隔了一段时间再次出现';
  return '';
}
function findRelatedEntries(entry,islandId,limit){
  const rows=archiveAllEntries();
  const baseText=[entry.title,entry.text].join(' ');
  const baseTokens=relationTokens(baseText);
  const basePlaces=relationPlaces(baseText);
  const baseDate=archiveDate(entry);
  const bk=entry.kind||'memory';
  const eImages=(entry.images||[]).length;
  const out=[];
  rows.forEach(function(row){
    const cand=row.entry;
    if(!cand||cand.id===entry.id) return;
    const cd=archiveDate(cand), days=Math.abs(cd.getTime()-baseDate.getTime())/86400000;
    const ck=cand.kind||'memory', cImages=(cand.images||[]).length;
    let score=0; const reasons=[];
    if(row.island.id!==islandId) score+=14;
    if(ck!==bk) score+=6;
    if(days<0.6){ score+=34; reasons.push('同一天留下的另一段'); }
    else if(days<=7){ score+=19; reasons.push('相隔不到一周'); }
    else if(days<=31){ score+=8; }
    else if(days>=300&&relationSameMonthDay(baseDate,cd)){ score+=24; reasons.push('不同年份的同一个日子'); }
    if(bk!=='music'&&ck==='music'&&eImages&&days<0.6){ score+=48; reasons.push('这张照片留下的时候，你在听这首歌'); }
    if(bk==='music'&&ck!=='music'&&cImages&&days<0.6){ score+=48; reasons.push('这首歌响起的那天，也留下了照片'); }
    const ov=relationOverlap(baseTokens,relationTokens([cand.title,cand.text].join(' ')));
    if(ov.score>0){ score+=Math.min(34,Math.round(ov.score*4)); if(ov.shared.length) reasons.push('都提到了「'+ov.shared.slice(0,2).join('、')+'」'); }
    const book=relationBookPair(entry,cand,days);
    if(book){ score+=32; reasons.push(book); }
    const cp=relationPlaces([cand.title,cand.text].join(' '));
    let place='';
    for(const p of basePlaces){ for(const q of cp){ if(q===p||q.indexOf(p)>=0||p.indexOf(q)>=0){ place=q.length>p.length?q:p; break; } } if(place) break; }
    if(place&&eImages&&cImages&&days>=300){ score+=38; reasons.push('同一个地点「'+place+'」，相隔 '+Math.max(1,Math.round(days/365))+' 年'); }
    if(score<26) return;
    out.push({entryId:cand.id,islandId:row.island.id,islandName:regionName(row.island),
      islandColor:row.island.color||'#8f7cff',score:score,reason:(reasons[0]||'与你有关'),
      reasons:reasons,date:cand.date,kind:ck,title:cand.title});
  });
  out.sort(function(a,b){return b.score-a.score;});
  return out.slice(0,limit||3);
}
function getRelationsFor(entryId){
  const stored=state.relations&&state.relations[entryId];
  if(Array.isArray(stored)&&stored.length) return stored;
  return [];
}
function attachRelations(items){
  if(!state.relations) state.relations={};
  let found=0;
  (items||[]).forEach(function(item){
    if(!item||!item.entry) return;
    const matches=findRelatedEntries(item.entry,item.islandId,3);
    if(!matches.length) return;
    state.relations[item.entry.id]=matches;
    const selfIsland=ISL[item.islandId]||{};
    matches.forEach(function(m){
      const back=state.relations[m.entryId]||[];
      if(!back.some(function(x){return x.entryId===item.entry.id;})){
        back.unshift({entryId:item.entry.id,islandId:item.islandId,islandName:regionName(selfIsland),
          islandColor:selfIsland.color||'#8f7cff',score:m.score,reason:'后来出现的一段碎片，和它有关',
          reasons:['后来出现的一段碎片，和它有关'],date:item.entry.date,kind:item.entry.kind,title:item.entry.title});
        state.relations[m.entryId]=back.slice(0,4);
      }
    });
    found+=matches.length;
  });
  return found;
}
function relateCardFor(m,entryId){
  const found=findEntry(m.entryId);
  const title=(found&&found.entry.title)||m.title||'(未命名)';
  const date=fmtDate((found&&found.entry.date)||m.date);
  const island=(found&&regionName(found.island))||m.islandName||'';
  return '<div class="relateCard" data-relate-open="'+esc(m.entryId)+'" data-relate-island="'+esc(m.islandId)+'" style="--ac:'+esc(m.islandColor||'#8f7cff')+'">'
    +'<div class="relateReason">✦ '+esc(m.reason||'与你有关')+'</div>'
    +'<h4>'+esc(title)+'</h4><time>'+esc(date)+' · '+esc(island)+'</time></div>';
}
function renderRelatedBlock(islandId,entry){
  let matches=getRelationsFor(entry.id);
  if(!matches.length) matches=findRelatedEntries(entry,islandId,3);
  if(!matches.length) return null;
  const sec=document.createElement('section');
  sec.className='relateBlock';
  let html='<div class="relateHead"><div><div class="relateKicker">与你有关</div><h3>它和这些旧碎片，来自完全不同的地方</h3></div><span class="relateCount">'+matches.length+' 段</span></div>';
  html+='<div class="relateGrid"><div class="relateSelf" style="--ac:'+esc((ISL[islandId]||{}).color||'#8f7cff')+'"><div class="relateReason">刚刚放进世界的碎片</div><h4>'+esc(entry.title||'(未命名)')+'</h4><time>'+esc(fmtDate(entry.date))+' · '+esc(regionName(ISL[islandId]||{name:''}))+'</time></div>';
  matches.forEach(function(m){ html+=relateCardFor(m,entry.id); });
  html+='</div>';
  sec.innerHTML=html;
  sec.querySelectorAll('[data-relate-open]').forEach(function(card){
    card.onclick=function(){
      const rid=card.dataset.relateIsland, eid=card.dataset.relateOpen;
      closeDetail();
      setTimeout(function(){ openDetail(rid,eid); },90);
    };
  });
  return sec;
}

/* ============================================================
   12d. 世界编年史：按年 / 按岛自动生成，可导出长图 / PDF
   ============================================================ */
var chronicleState={mode:'year'};
function chronicleRows(rows){
  var list=(rows||[]).slice();
  if(archiveState.islandId&&archiveState.islandId!=='all') list=list.filter(function(r){return r.island.id===archiveState.islandId;});
  return list;
}
function chronicleModel(rows){
  var list=chronicleRows(rows), mode=chronicleState.mode||'year', groups=[];
  if(!list.length) return groups;
  if(mode==='year'){
    var byYear={};
    list.forEach(function(row){
      var y=archiveDate(row.entry).getFullYear();
      if(!byYear[y]) byYear[y]={key:String(y),title:y+' 年',rows:[],islands:{}};
      byYear[y].rows.push(row); byYear[y].islands[row.island.id]=1;
    });
    Object.keys(byYear).map(Number).sort(function(a,b){return b-a;}).forEach(function(y){
      var g=byYear[y];
      g.rows.sort(function(a,b){return a.ts-b.ts;});
      g.subtitle=Object.keys(g.islands).length+' 座岛屿 · '+g.rows.length+' 条记忆';
      g.color='#8f7cff';
      groups.push(g);
    });
  }else{
    ISLANDS.forEach(function(island){
      var rs=list.filter(function(row){return row.island.id===island.id;});
      if(!rs.length) return;
      rs.sort(function(a,b){return a.ts-b.ts;});
      groups.push({key:island.id,title:(island.emoji||'')+' '+regionName(island),subtitle:rs.length+' 条记忆 · 从最早到现在',color:island.color,rows:rs});
    });
  }
  return groups;
}
function chronicleCnNumber(n){
  n=Math.max(0,Math.floor(Number(n)||0));
  const d=['零','一','二','三','四','五','六','七','八','九'];
  if(n<10) return d[n];
  if(n<20) return '十'+(n%10?d[n%10]:'');
  if(n<100) return d[Math.floor(n/10)]+'十'+(n%10?d[n%10]:'');
  return String(n);
}
function chronicleChineseDate(date){
  const d=date||new Date();
  return chronicleCnNumber(d.getMonth()+1)+'月'+chronicleCnNumber(d.getDate())+'日';
}
function chronicleDocHtml(groups,total){
  var parts=[];
  parts.push('<div class="chronicleDoc" id="chronicleDoc"><div class="chronicleCover"><div class="ccKicker">CHRONICLE OF MY WORLD</div><h1>我的世界编年史</h1><p>'+esc(state.name||'我的世界')+' · '+total+' 条记忆 · 生成于 '+esc(fmtDate(new Date().toISOString()))+'</p><div class="ccMeta">按'+(chronicleState.mode==='island'?'岛屿':'年份')+'编排 · 只收进已经写下的部分</div></div>');
  groups.forEach(function(g){
    parts.push('<section class="chronicleChapter" style="--ac:'+esc(g.color||'#8f7cff')+'"><div class="ccHead"><h3>'+esc(g.title)+'</h3><span>'+esc(g.subtitle||'')+'</span></div>');
    g.rows.forEach(function(row){
      var kd=archiveKind(row.entry), text=archiveText(row.entry), imgs=(row.entry.images||[]).slice(0,2);
      parts.push('<article class="chronicleEntry" data-open-entry="'+esc(row.entry.id)+'" data-entry-island="'+esc(row.island.id)+'"><div class="ceWhen">'+esc(chronicleChineseDate(archiveDate(row.entry)))+'</div><div class="ceMain"><h4>'+esc(kd.icon)+' '+esc(archiveTitle(row.entry))+'</h4>'+(text?'<p>'+esc(text)+'</p>':'')+'<div class="ceMeta">'+esc(fmtDate(row.entry.date))+' · '+esc(regionName(row.island))+'</div></div>'+(imgs.length?'<div class="ceShots">'+imgs.map(function(src){return '<img src="'+src+'" alt="">';}).join('')+'</div>':'')+'</article>');
    });
    parts.push('</section>');
  });
  parts.push('</div>');
  return parts.join('');
}
function archiveChronicle(rows){
  var groups=chronicleModel(rows), total=groups.reduce(function(s,g){return s+g.rows.length;},0);
  var parts=[];
  parts.push('<div class="chronicleBar"><div class="chronicleModes"><span class="chronicleLabel">分组</span><button type="button" data-chronicle-mode="year" class="'+(chronicleState.mode!=='island'?'on':'')+'">按年</button><button type="button" data-chronicle-mode="island" class="'+(chronicleState.mode==='island'?'on':'')+'">按岛</button></div><div class="chronicleActions"><button type="button" data-chronicle-export="image">导出长图</button><button type="button" data-chronicle-export="pdf">导出 PDF</button></div></div>');
  if(!total){ parts.push('<div class="archiveBlank">还没有可以编成编年史的记忆。<br>先写下第一段，世界就会从这一年开始。</div>'); return parts.join(''); }
  parts.push(chronicleDocHtml(groups,total));
  return parts.join('');
}
function chronicleFileName(){
  var d=new Date(), pad=function(n){return String(n).padStart(2,'0');};
  return (state.name||'我的世界')+'-编年史-'+d.getFullYear()+pad(d.getMonth()+1)+pad(d.getDate());
}
function chronicleLoadImage(src){
  return new Promise(function(resolve){
    if(!src) return resolve(null);
    var im=new Image(), done=false;
    var finish=function(v){ if(!done){done=true;resolve(v);} };
    im.onload=function(){finish(im);};
    im.onerror=function(){finish(null);};
    setTimeout(function(){finish(null);},4000);
    im.src=src;
  });
}
function chronicleDownload(blob,name){
  var a=document.createElement('a'), url=URL.createObjectURL(blob);
  a.href=url; a.download=name;
  document.body.appendChild(a); a.click();
  setTimeout(function(){ URL.revokeObjectURL(url); if(a.parentNode) a.parentNode.removeChild(a); },1600);
}
function dataUrlToBytes(url){
  var base64=String(url).split(',')[1]||'', bin=atob(base64), out=new Uint8Array(bin.length);
  for(var i=0;i<bin.length;i++) out[i]=bin.charCodeAt(i);
  return out;
}
async function chronicleBuildCanvas(rows){
  var groups=chronicleModel(rows);
  var MAX=90, picked=[], used=0, allRows=0;
  groups.forEach(function(g){ allRows+=g.rows.length; });
  groups.forEach(function(g){
    var keep=[];
    g.rows.forEach(function(r){ if(used<MAX){ keep.push(r); used++; } });
    if(keep.length) picked.push({title:g.title,subtitle:g.subtitle,color:g.color,rows:keep});
  });
  var truncated=used<allRows;
  var W=1240, PAD=76, CW=W-PAD*2;
  var FONT='"PingFang SC","Microsoft YaHei","Hiragino Sans GB",system-ui,-apple-system,sans-serif';
  var mc=C(8,8), mg=GC(mc);
  function setFont(g2,size,weight){ g2.font=(weight||'')+' '+size+'px '+FONT; }
  function wrap(g2,text,size,weight,maxW,maxLines){
    setFont(g2,size,weight);
    var s=String(text||'').replace(/\s+/g,' ').trim();
    if(!s) return [];
    var lines=[], cur='';
    for(var i=0;i<s.length;i++){
      var ch=s.charAt(i);
      if(cur&&g2.measureText(cur+ch).width>maxW){ lines.push(cur); cur=ch; }
      else cur+=ch;
    }
    if(cur) lines.push(cur);
    if(maxLines&&lines.length>maxLines){ lines=lines.slice(0,maxLines); lines[maxLines-1]=lines[maxLines-1].slice(0,-1)+'…'; }
    return lines;
  }
  var chapters=[];
  for(var gi=0;gi<picked.length;gi++){
    var g=picked[gi], ents=[];
    for(var ri=0;ri<g.rows.length;ri++){
      var row=g.rows[ri], imgs=[], srcs=(row.entry.images||[]).slice(0,2);
      for(var si=0;si<srcs.length;si++){ var im=await chronicleLoadImage(srcs[si]); if(im) imgs.push(im); }
      var ent={row:row,imgs:imgs,kind:archiveKind(row.entry),
        titleLines:wrap(mg,archiveTitle(row.entry),30,'700',CW-200,2),
        textLines:wrap(mg,archiveText(row.entry),23,'',CW-40,4)};
      ents.push(ent);
    }
    g.ents=ents;
  }
  var coverH=300, headH=104, footH=64, totalH=coverH;
  picked.forEach(function(g){
    totalH+=headH;
    g.ents.forEach(function(en){
      var h=34+en.titleLines.length*40;
      if(en.textLines.length) h+=10+en.textLines.length*34;
      if(en.imgs.length) h+=186;
      h+=28; en.h=h; totalH+=h;
    });
    totalH+=26;
  });
  totalH+=footH;
  var cv=C(W,Math.min(32000,Math.ceil(totalH))), g2=GC(cv);
  var bg=g2.createLinearGradient(0,0,0,cv.height);
  bg.addColorStop(0,'#0a0e24'); bg.addColorStop(0.45,'#101534'); bg.addColorStop(1,'#171232');
  g2.fillStyle=bg; g2.fillRect(0,0,W,cv.height);
  for(var s=0;s<Math.min(520,Math.floor(cv.height/8));s++){
    var rx=(s*97.13)%W, ry=(s*53.71)%cv.height;
    g2.fillStyle='rgba(200,215,255,'+(0.05+((s*37)%40)/240).toFixed(3)+')';
    g2.fillRect(rx,ry,1.4,1.4);
  }
  g2.textAlign='left'; g2.textBaseline='top';
  setFont(g2,15,'700'); g2.fillStyle='rgba(160,180,255,0.85)';
  g2.fillText('CHRONICLE OF MY WORLD',PAD,86);
  setFont(g2,58,'700'); g2.fillStyle='#f2f3fa';
  g2.fillText('我的世界编年史',PAD,120);
  setFont(g2,22,''); g2.fillStyle='#a9adc7';
  g2.fillText(String(state.name||'我的世界')+' · '+used+' 条记忆 · 生成于 '+fmtDate(new Date().toISOString()),PAD,196);
  setFont(g2,16,''); g2.fillStyle='#7f86ad';
  g2.fillText('按'+(chronicleState.mode==='island'?'岛屿':'年份')+'编排'+(truncated?(' · 长图收录最近 '+used+' 条'):'') ,PAD,232);
  g2.strokeStyle='rgba(143,124,255,0.5)'; g2.lineWidth=2;
  g2.beginPath(); g2.moveTo(PAD,268); g2.lineTo(W-PAD,268); g2.stroke();
  var y=coverH;
  picked.forEach(function(ch){
    g2.fillStyle=hexA(ch.color||'#8f7cff',0.18);
    g2.fillRect(PAD,y,W-PAD*2,72);
    setFont(g2,34,'700'); g2.fillStyle='#f2f3fa';
    g2.fillText(ch.title,PAD+22,y+16);
    setFont(g2,16,''); g2.fillStyle='#a9adc7';
    g2.fillText(ch.subtitle||'',PAD+22,y+58-4);
    y+=headH;
    ch.ents.forEach(function(en){
      var top=y;
      var d=archiveDate(en.row.entry);
      setFont(g2,22,'700'); g2.fillStyle=hexA(ch.color||'#8f7cff',0.95);
      g2.fillText(chronicleChineseDate(d),PAD,top+2);
      var tx=PAD+92, ty=top;
      setFont(g2,30,'700'); g2.fillStyle='#f2f3fa';
      en.titleLines.forEach(function(l,i){ g2.fillText(en.kind.icon+' '+l,tx,ty+i*40); });
      ty+=en.titleLines.length*40+8;
      if(en.textLines.length){
        setFont(g2,23,''); g2.fillStyle='#cfd2e6';
        en.textLines.forEach(function(l,i){ g2.fillText(l,tx,ty+i*34); });
        ty+=en.textLines.length*34+10;
      }
      if(en.imgs.length){
        var iw=(CW-92-18)/2, ih=168;
        en.imgs.forEach(function(im,i){
          var x0=tx+i*(iw+18), ratio=im.width/Math.max(1,im.height);
          var dw=iw, dh=dw/ratio;
          if(dh>ih){ dh=ih; dw=dh*ratio; }
          try{ g2.drawImage(im,x0,ty,dw,dh); }catch(err){}
        });
        ty+=186;
      }
      setFont(g2,15,''); g2.fillStyle='#8d91ad';
      g2.fillText(fmtDate(en.row.entry.date)+' · '+regionName(en.row.island),tx,ty-18);
      g2.strokeStyle='rgba(255,255,255,0.08)'; g2.lineWidth=1;
      g2.beginPath(); g2.moveTo(PAD,top+en.h-10); g2.lineTo(W-PAD,top+en.h-10); g2.stroke();
      y+=en.h;
    });
    y+=26;
  });
  setFont(g2,15,''); g2.fillStyle='#7f86ad';
  g2.fillText('Life as a World · 把生活变成一个世界'+((truncated)?(' · 已收录 '+used+' / '+allRows+' 条'):''),PAD,cv.height-42);
  return cv;
}
function chronicleSlice(cv){
  var pageH=Math.round(cv.width*841.89/595.276), pages=[];
  for(var y=0;y<cv.height;y+=pageH){
    var h=Math.min(pageH,cv.height-y);
    var page=C(cv.width,pageH), pg=GC(page);
    pg.fillStyle='#0a0e24'; pg.fillRect(0,0,page.width,page.height);
    pg.drawImage(cv,0,y,cv.width,h,0,0,cv.width,h);
    pages.push(page);
  }
  return pages;
}
function chroniclePdfFromJpegs(pages){
  var enc=function(str){ var out=new Uint8Array(str.length); for(var i=0;i<str.length;i++) out[i]=str.charCodeAt(i)&0xff; return out; };
  var chunks=[], offsets=[], length=0;
  function push(part){ var b=(part instanceof Uint8Array)?part:enc(part); chunks.push(b); length+=b.length; }
  function obj(n,body){ offsets[n]=length; push(n+' 0 obj\n'+body+'\nendobj\n'); }
  push('%PDF-1.4\n');
  push(new Uint8Array([0x25,0xe2,0xe3,0xcf,0xd3,0x0a]));
  var pageCount=pages.length, kids=[];
  for(var i=0;i<pageCount;i++) kids.push((3+i*3)+' 0 R');
  obj(1,'<< /Type /Catalog /Pages 2 0 R >>');
  obj(2,'<< /Type /Pages /Kids ['+kids.join(' ')+'] /Count '+pageCount+' >>');
  var PW=595.276, PH=841.89;
  pages.forEach(function(pg,idx){
    var pno=3+idx*3, cno=pno+1, ino=pno+2;
    var scale=Math.min(PW/pg.width,PH/pg.height), w=pg.width*scale, h=pg.height*scale;
    var x=(PW-w)/2, y=(PH-h)/2;
    var content='q\n'+w.toFixed(2)+' 0 0 '+h.toFixed(2)+' '+x.toFixed(2)+' '+y.toFixed(2)+' cm\n/Im0 Do\nQ\n';
    obj(pno,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+PW.toFixed(2)+' '+PH.toFixed(2)+'] /Resources << /XObject << /Im0 '+ino+' 0 R >> >> /Contents '+cno+' 0 R >>');
    obj(cno,'<< /Length '+content.length+' >>\nstream\n'+content+'endstream');
    offsets[ino]=length;
    push(ino+' 0 obj\n<< /Type /XObject /Subtype /Image /Width '+pg.width+' /Height '+pg.height+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+pg.data.length+' >>\nstream\n');
    push(pg.data);
    push('\nendstream\nendobj\n');
  });
  var xrefOffset=length, maxObj=3+pageCount*3;
  var xref='xref\n0 '+(maxObj+1)+'\n0000000000 65535 f \n';
  for(var n=1;n<=maxObj;n++) xref+=String(offsets[n]||0).padStart(10,'0')+' 00000 n \n';
  push(xref);
  push('trailer\n<< /Size '+(maxObj+1)+' /Root 1 0 R >>\nstartxref\n'+xrefOffset+'\n%%EOF\n');
  var total=0; chunks.forEach(function(c){total+=c.length;});
  var out=new Uint8Array(total), pos=0;
  chunks.forEach(function(c){out.set(c,pos);pos+=c.length;});
  return out;
}
async function chronicleExport(kind){
  var rows=archiveAllEntries();
  if(!chronicleRows(rows).length){ toast('还没有可以编成编年史的记忆'); return; }
  toast(kind==='pdf'?'正在生成 PDF 编年史…':'正在生成编年史长图…');
  try{
    var cv=await chronicleBuildCanvas(rows);
    if(kind==='pdf'){
      var pages=chronicleSlice(cv), jpegs=[];
      for(var i=0;i<pages.length;i++){
        var url=pages[i].toDataURL('image/jpeg',0.86);
        jpegs.push({data:dataUrlToBytes(url),width:pages[i].width,height:pages[i].height});
      }
      var bytes=chroniclePdfFromJpegs(jpegs);
      chronicleDownload(new Blob([bytes],{type:'application/pdf'}),chronicleFileName()+'.pdf');
      toast('PDF 已生成（'+pages.length+' 页）');
    }else{
      cv.toBlob(function(blob){
        if(!blob){ toast('长图生成失败，请重试'); return; }
        chronicleDownload(blob,chronicleFileName()+'.png');
        toast('编年史长图已生成');
      },'image/png');
    }
  }catch(e){ toast('导出失败：'+((e&&e.message)||'请重试')); }
}

boot();
